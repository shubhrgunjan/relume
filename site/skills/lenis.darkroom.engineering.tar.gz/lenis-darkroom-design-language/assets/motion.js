// Motion runtime measured from https://lenis.darkroom.engineering by relume. Import once on every page.
// Scroll reveals start when an element's top crosses the measured fraction of the viewport height.
const ENTRY = {"reveal-tint-12":0.85,"reveal-translate-13":0.91,"reveal-fade-out-14":0.34,"reveal-fade-out-15":0.69,"reveal-scale-16":0.7,"reveal-tint-17":0.76,"reveal-fade-18":0.82,"reveal-scale-19":0.49,"reveal-tint-20":0.85,"reveal-fade-21":0.92,"reveal-fill-22":0.85};
const DEFAULT_ENTRY = 0.74;

export function initReveals(root = document) {
  const els = [...root.querySelectorAll('[data-reveal]')];
  const byEntry = new Map();
  for (const el of els) {
    const e = ENTRY[el.dataset.reveal] ?? DEFAULT_ENTRY;
    if (!byEntry.has(e)) byEntry.set(e, []);
    byEntry.get(e).push(el);
  }
  for (const [entry, list] of byEntry) {
    const io = new IntersectionObserver((records) => {
      for (const r of records) if (r.isIntersecting) { r.target.classList.add('is-in'); io.unobserve(r.target); }
    }, { rootMargin: `0px 0px ${-Math.round((1 - entry) * 100)}% 0px` });
    list.forEach((el) => io.observe(el));
  }
}

// Scroll-linked motion: property change per px scrolled, as measured.
const PARALLAX = {"parallax-scale-23":0.039,"parallax-down-24":0.133,"parallax-up-25":-0.14,"parallax-scale-26":0.039,"parallax-slide-27":-0.683,"parallax-scale-28":0.039,"parallax-scale-29":0.039,"parallax-scale-30":0.47,"parallax-scale-31":0.651,"parallax-scale-32":0.751};
export function initParallax() {
  const els = [...document.querySelectorAll('[data-parallax]')];
  const tick = () => { for (const el of els) { const k = PARALLAX[el.dataset.parallax] ?? 0; const r = el.getBoundingClientRect(); el.style.transform = `translate3d(0, ${(r.top + r.height / 2 - innerHeight / 2) * k}px, 0)`; } requestAnimationFrame(tick); };
  requestAnimationFrame(tick);
}


// Smooth scrolling as measured: one wheel notch moves 100px and settles in ~519ms
// (exponential approach, lerp ≈ 0.14 per frame).
// npm i lenis
import Lenis from 'lenis';
export function initSmoothScroll() {
  const lenis = new Lenis({ lerp: 0.14, wheelMultiplier: 1, smoothWheel: true });
  const raf = (t) => { lenis.raf(t); requestAnimationFrame(raf); };
  requestAnimationFrame(raf);
  return lenis;
}

export function initMotion() {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) { document.querySelectorAll('[data-reveal]').forEach((el) => el.classList.add('is-in')); return; }
  initSmoothScroll();
  initReveals();
  initParallax();
}

if (typeof window !== 'undefined') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initMotion); else initMotion();
}
