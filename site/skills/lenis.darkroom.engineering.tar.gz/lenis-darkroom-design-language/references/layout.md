# Layout

## Containers
| viewport | content widths (most used first) | gutter |
|---|---|---|
| desktop | 1360px, 1376px, 437px | 40px |
| tablet | 788px, 797px, 253px | 23px |
| mobile | 357px | 17px |

## Breakpoints (from the stylesheets)
- min-width 800px (×28)
- max-width 800px (×1)

## Grids
- 12 cols, gap 24px (×16)
- 13 cols, gap 24px (×4)
- 10 equal flex columns, gap normal (×1)
- 2 cols, gap 8px (×1)

## Section rhythm
| viewport | section padding-y (common) | median | gap between sections |
|---|---|---|---|
| desktop | 20px, 60px, 40px, 56px, 320px | 56px | 320px |
| tablet | 34.75px, 23.1667px, 32.4333px, 185.333px | 34.75px | 185px |
| mobile | 20.8px, 66.56px, 74.88px, 16.64px, 58.24px | 66.56px | 167px |

## Density
- First screen: 18 words, text covers 6.3% of it.
- Home page is 41.6 screens tall at desktop.
