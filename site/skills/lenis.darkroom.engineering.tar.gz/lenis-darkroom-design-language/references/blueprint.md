# Blueprint

Every section of the measured pages, top to bottom. Build the same kinds of sections in the same order for your product. "Made of" is what fills the section; recreate each block in kind (your content, the source's grammar). Crops are in `assets/reference/sections/`.

## home — 37462px, 11 sections, visuals 3%, 2 elements/screen

### 01 · hero
![hero](../assets/reference/sections/home-00.jpg)
- layout: **hero**; 900px tall; visuals cover 0%; 0 painted elements; background rgb(255, 152, 162)
- made of: text only (0 characters)

### 02 · content
![content](../assets/reference/sections/home-01.jpg)
- layout: **stacked**; 900px tall; visuals cover 0%; 0 painted elements
- made of: text only (0 characters)

### 03 · data visualisation
![data visualisation](../assets/reference/sections/home-02.jpg)
- layout: **stacked**; 900px tall; visuals cover 100%; 0 painted elements
- made of: **dataviz** (canvas 1440×900, at 0/0/1440/900)

### 04 · call to action
![call to action](../assets/reference/sections/home-03.jpg)
- layout: **stacked**; 900px tall; visuals cover 0%; 14 painted elements
- heading: “Smooth Scroll” — 52px / 700, at x 617, 783px wide
- made of: text only (97 characters)

### 05 · content
![content](../assets/reference/sections/home-04.jpg)
- layout: **stacked**; 2759px tall; visuals cover 0%; 13 painted elements
- heading: “Why” — 96px / 400, at x 303, 160px wide
- made of: text only (1127 characters)

### 06 · statement
![statement](../assets/reference/sections/home-05.jpg)
- layout: **stacked**; 376px tall; visuals cover 0%; 3 painted elements
- heading: “Lenis runs” — 96px / 400, at x 303, 402px wide
- made of: text only (235 characters)

### 07 · content
![content](../assets/reference/sections/home-06.jpg)
- layout: **stacked**; 6480px tall; visuals cover 6%; 27 painted elements
- made of: **video** (video 480×360, at -2931/5514/480/360); **video** (video 480×360, at -2427/5514/480/360); **video** (video 480×360, at -1923/5514/480/360); **video** (video 480×360, at -1419/5514/480/360); **video** (video 480×360, at -915/5514/480/360); **video** (video 480×360, at -411/5514/480/360); **video** (video 480×360, at 93/5514/480/360); **video** (video 480×360, at 597/5514/480/360); **image** (480×360, at 1101/5514/480/360)

### 08 · statement
![statement](../assets/reference/sections/home-07.jpg)
- layout: **stacked**; 9000px tall; visuals cover 0%; 3 painted elements
- heading: “so we built” — 141.176px / 400, at x 40, 1360px wide
- made of: text only (39 characters)

### 09 · call to action
![call to action](../assets/reference/sections/home-08.jpg)
- layout: **stacked**; 408px tall; visuals cover 0%; 7 painted elements
- heading: “Lenis is a free, that turns native scroll into a silky, controllable experience ” — 64px / 500, at x 40, 1360px wide
- made of: text only (291 characters)

### 10 · statement
![statement](../assets/reference/sections/home-09.jpg)
- layout: **stacked**; 14400px tall; visuals cover 0%; 2 painted elements
- heading: “Lenis brings” — 52px / 700, at x 858, 542px wide
- made of: text only (20 characters)

### 11 · footer
![footer](../assets/reference/sections/home-10.jpg)
- layout: **stacked**; 900px tall; visuals cover 0%; 12 painted elements
- heading: “Lenis is” — 141.176px / 400, at x 40, 1360px wide
- made of: **tabs** (6 sub-feature links, at 0/37426/1440/36)

## showcase — 3965px, 7 sections, visuals 46%, 14 elements/screen

### 01 · hero
![hero](../assets/reference/sections/showcase-00.jpg)
- layout: **hero**; 900px tall; visuals cover 0%; 0 painted elements
- made of: text only (0 characters)

### 02 · data visualisation
![data visualisation](../assets/reference/sections/showcase-01.jpg)
- layout: **stacked**; 900px tall; visuals cover 100%; 0 painted elements; background rgb(0, 0, 0)
- made of: **dataviz** (canvas 1440×900, at 0/0/1440/900)

### 03 · content
![content](../assets/reference/sections/showcase-02.jpg)
- layout: **centered**; 585px tall; visuals cover 0%; 5 painted elements
- heading: “Lenis Showcase” — 160px / 400, at x 223, 995px wide
- made of: **form** (inputs, at 40/56/1360/585)

### 04 · content
![content](../assets/reference/sections/showcase-03.jpg)
- layout: **stacked**; 2048px tall; visuals cover 79%; 42 painted elements
- heading: “Michelangelus” — 24px / 500, at x 40, 158px wide
- made of: **video** (video 668×501, at 40/705/668/501); **video** (video 668×501, at 732/705/668/501); **video** (video 437×328, at 501/1319/437/328); **video** (video 437×328, at 963/1319/437/328); **video** (video 322×242, at 40/1748/322/242); **video** (video 322×242, at 386/1748/322/242); **video** (video 322×242, at 732/1748/322/242); **video** (video 322×242, at 1078/1748/322/242); **video** (video 322×242, at 40/2091/322/242); **video** (video 322×242, at 386/2091/322/242); **video** (video 322×242, at 732/2091/322/242); **video** (video 322×242, at 1078/2091/322/242); **video** (video 322×242, at 40/2434/322/242); **video** (video 322×242, at 386/2434/322/242); **video** (video 322×242, at 732/2434/322/242); **video** (video 322×242, at 1078/2434/322/242); **image** (437×328, at 40/1319/437/328)

### 05 · content
![content](../assets/reference/sections/showcase-04.jpg)
- layout: **stacked**; 80px tall; visuals cover 0%; 0 painted elements
- made of: text only (0 characters)

### 06 · content
![content](../assets/reference/sections/showcase-05.jpg)
- layout: **stacked**; 48px tall; visuals cover 0%; 1 painted elements
- made of: text only (9 characters)

### 07 · footer
![footer](../assets/reference/sections/showcase-06.jpg)
- layout: **stacked**; 900px tall; visuals cover 0%; 12 painted elements
- heading: “Lenis is” — 141.176px / 400, at x 40, 1360px wide
- made of: **tabs** (6 sub-feature links, at 0/3929/1440/36)

## templates — 3112px, 3 sections, visuals 53%, 16 elements/screen

### 01 · hero
![hero](../assets/reference/sections/templates-00.jpg)
- layout: **hero**; 900px tall; visuals cover 0%; 0 painted elements
- made of: text only (0 characters)

### 02 · product UI showcase
![product UI showcase](../assets/reference/sections/templates-01.jpg)
- layout: **stacked**; 2156px tall; visuals cover 97%; 44 painted elements
- made of: **dataviz** (canvas 1440×900, at 0/0/1440/900); **video** (video 322×242, at 40/705/322/242); **video** (video 322×242, at 386/705/322/242); **video** (video 322×242, at 1078/705/322/242); **video** (video 322×242, at 40/1048/322/242); **video** (video 322×242, at 386/1048/322/242); **video** (video 322×242, at 732/1048/322/242); **video** (video 322×242, at 1078/1048/322/242); **video** (video 322×242, at 40/1390/322/242); **video** (video 322×242, at 386/1390/322/242); **video** (video 322×242, at 732/1390/322/242); **video** (video 322×242, at 1078/1390/322/242); **video** (video 322×242, at 40/1733/322/242); **image** (322×242, at 732/705/322/242); **ui-mock** (11 UI labels (panel), at 0/56/1440/2076); **form** (inputs, at 0/56/1440/2156)

### 03 · footer
![footer](../assets/reference/sections/templates-02.jpg)
- layout: **stacked**; 900px tall; visuals cover 0%; 12 painted elements
- heading: “Lenis is” — 141.176px / 400, at x 40, 1360px wide
- made of: **tabs** (6 sub-feature links, at 0/3076/1440/36)

## showcase-submit — 2815px, 3 sections, visuals 47%, 17 elements/screen

### 01 · hero
![hero](../assets/reference/sections/showcase-submit-00.jpg)
- layout: **hero**; 900px tall; visuals cover 0%; 0 painted elements
- made of: text only (0 characters)

### 02 · product UI showcase
![product UI showcase](../assets/reference/sections/showcase-submit-01.jpg)
- layout: **stacked**; 1859px tall; visuals cover 92%; 40 painted elements
- made of: **dataviz** (canvas 1440×900, at 0/0/1440/900); **ui-mock** (13 UI labels (panel), at 386/641/668/1114); **ui-mock** (13 UI labels (panel), at 0/56/1440/1699); **form** (inputs, at 0/56/1440/1859)

### 03 · footer
![footer](../assets/reference/sections/showcase-submit-02.jpg)
- layout: **stacked**; 900px tall; visuals cover 0%; 12 painted elements
- heading: “Lenis is” — 141.176px / 400, at x 40, 1360px wide
- made of: **tabs** (6 sub-feature links, at 0/2779/1440/36)
