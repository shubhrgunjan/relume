# Components

Each variant is the clustered style of every element that looked the same across the crawled pages. Classes of the same name are in `assets/tokens.css`. Crops are in `assets/reference/`.

## link (link, ×38)
![link](../assets/reference/link.jpg)
Examples: “Unseen Studio®”, “OFF+BRAND”, “darkroom.engineering”, “Rockstar Games”

| property | value |
|---|---|
| background | `transparent` |
| color | `#8c8c8c` |
| font | `400 16px/21.28px` |
| family | `Roboto` |
| padding | `0px 0px 0px 0px` |
| transition | `color 0.6s cubic-bezier(0.19, 1, 0.22, 1), background-color 0.6s cubic-bezier(0.19, 1, 0.22, 1), border-color 0.6s cubic-bezier(0.19, 1, 0.22, 1), outline-color 0.6s cubic-bezier(0.19, 1, 0.22, 1), text-decoration-color 0.6s cubic-bezier(0.19, 1, 0.22, 1), fill 0.6s cubic-bezier(0.19, 1, 0.22, 1), stroke 0.6s cubic-bezier(0.19, 1, 0.22, 1), --tw-gradient-from 0.6s cubic-bezier(0.19, 1, 0.22, 1), --tw-gradient-via 0.6s cubic-bezier(0.19, 1, 0.22, 1), --tw-gradient-to 0.6s cubic-bezier(0.19, 1, 0.22, 1)` |
| cursor | `pointer` |
Size: 21px tall, from 29px wide, padding 0px × 0px.

**Hover**
| property | rest | hover |
|---|---|---|
| color | `rgb(140, 140, 140)` | `rgb(255, 152, 162)` |
| borderTopColor | `rgb(140, 140, 140)` | `rgb(255, 152, 162)` |
| outlineColor | `rgb(140, 140, 140)` | `rgb(255, 152, 162)` |
Transitions: color 600ms cubic-bezier(0.19, 1, 0.22, 1)
Inside it: div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1); a.dr-rounded-8.relative 480×360 — opacity 600ms cubic-bezier(0.19, 1, 0.22, 1); div.dr-bottom-16.dr-right-16 32×32 — opacity 600ms cubic-bezier(0.19, 1, 0.22, 1); svg.icon.w-[33%] 3×3 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1); a.dr-text-18.inline-block “Careers at Netflix” 138×24 — color 600ms cubic-bezier(0.19, 1, 0.22, 1)

**Focus-visible**: outline `1px auto rgb(140, 140, 140)`, offset 1px

## link-2 (link, ×37)
![link-2](../assets/reference/link-2.jpg)
Examples: “Careers at Netflix”, “Lando Norris”, “Lenis Framer Starter Kit”, “Grand Theft Auto VI”

| property | value |
|---|---|
| background | `transparent` |
| color | `#efefef` |
| font | `500 18px/23.94px` |
| family | `Roboto` |
| padding | `0px 0px 0px 0px` |
| transition | `color 0.6s cubic-bezier(0.19, 1, 0.22, 1), background-color 0.6s cubic-bezier(0.19, 1, 0.22, 1), border-color 0.6s cubic-bezier(0.19, 1, 0.22, 1), outline-color 0.6s cubic-bezier(0.19, 1, 0.22, 1), text-decoration-color 0.6s cubic-bezier(0.19, 1, 0.22, 1), fill 0.6s cubic-bezier(0.19, 1, 0.22, 1), stroke 0.6s cubic-bezier(0.19, 1, 0.22, 1), --tw-gradient-from 0.6s cubic-bezier(0.19, 1, 0.22, 1), --tw-gradient-via 0.6s cubic-bezier(0.19, 1, 0.22, 1), --tw-gradient-to 0.6s cubic-bezier(0.19, 1, 0.22, 1)` |
| cursor | `pointer` |
Size: 24px tall, from 33px wide, padding 0px × 0px.

**Hover**
| property | rest | hover |
|---|---|---|
| color | `rgb(239, 239, 239)` | `rgb(255, 152, 162)` |
| borderTopColor | `rgb(239, 239, 239)` | `rgb(255, 152, 162)` |
| outlineColor | `rgb(239, 239, 239)` | `rgb(255, 152, 162)` |
Transitions: color 600ms cubic-bezier(0.19, 1, 0.22, 1)
Inside it: div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1); a.dr-rounded-8.relative 480×360 — opacity 600ms cubic-bezier(0.19, 1, 0.22, 1); div.dr-bottom-16.dr-right-16 32×32 — opacity 600ms cubic-bezier(0.19, 1, 0.22, 1); svg.icon.w-[33%] 3×3 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1)

**Focus-visible**: outline `1px auto rgb(239, 239, 239)`, offset 1px

## link-3 (link, ×24)
![link-3](../assets/reference/link-3.jpg)
Examples: “GitHub”, “X”, “LinkedIn”, “Mail”

| property | value |
|---|---|
| background | `transparent` |
| color | `#efefef` |
| font | `900 12px/13.56px` |
| family | `Roboto` |
| textTransform | `uppercase` |
| padding | `0px 0px 0px 0px` |
| cursor | `pointer` |
| ::after | `{"content":"\"\"","backgroundColor":"rgb(239, 239, 239)","width":"47px","height":"1px","position":"absolute","transform":"matrix(0, 0, 0, 1, 0, 0)","transitionProperty":"transform","transitionDuration":"0.6s","transitionTimingFunction":"cubic-bezier(0.19, 1, 0.22, 1)","borderRadius":"0px","opacity":` |
Size: 14px tall, from 8px wide, padding 0px × 0px.

**Hover**
| property | rest | hover |
|---|---|---|
| ::after.transform | `matrix(0, 0, 0, 1, 0, 0)` | `none` |
Transitions: transform 600ms cubic-bezier(0.19, 1, 0.22, 1)
Inside it: div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1)

**Focus-visible**: outline `1px auto rgb(16, 16, 16)`, offset 1px

## link-4 (link, ×20)
![link-4](../assets/reference/link-4.jpg)
Examples: “Showcase”, “Templates”, “Submit”, “Documentation”

| property | value |
|---|---|
| background | `transparent` |
| color | `#efefef` |
| font | `900 14px/15.82px` |
| family | `Roboto` |
| textTransform | `uppercase` |
| padding | `0px 0px 0px 0px` |
| transition | `opacity 0.6s cubic-bezier(0.19, 1, 0.22, 1)` |
| cursor | `pointer` |
| ::after | `{"content":"\"\"","backgroundColor":"rgb(239, 239, 239)","width":"81px","height":"1px","position":"absolute","transform":"matrix(0, 0, 0, 1, 0, 0)","transitionProperty":"transform","transitionDuration":"0.6s","transitionTimingFunction":"cubic-bezier(0.19, 1, 0.22, 1)","borderRadius":"0px","opacity":` |
Size: 16px tall, from 56px wide, padding 0px × 0px.

**Hover**
| property | rest | hover |
|---|---|---|
| ::after.transform | `matrix(0, 0, 0, 1, 0, 0)` | `none` |
Transitions: transform 600ms cubic-bezier(0.19, 1, 0.22, 1)
Inside it: div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1)

**Focus-visible**: outline `1px auto rgb(16, 16, 16)`, offset 1px

## button-secondary (button, ×11)
![button-secondary](../assets/reference/button-secondary.jpg)
Examples: “Agency”, “Portfolio”, “Event”, “AI”

| property | value |
|---|---|
| background | `rgb(0 0 0 / 0.5)` |
| color | `#efefef` |
| border | `1px solid #8c8c8c` |
| radius | `32px` |
| font | `400 12px/normal` |
| family | `Roboto` |
| padding | `0px 14px 0px 14px` |
| gap | `8px` |
| transition | `background-color 0.3s cubic-bezier(0.19, 1, 0.22, 1), color 0.3s cubic-bezier(0.19, 1, 0.22, 1), border-color 0.3s cubic-bezier(0.19, 1, 0.22, 1)` |
| backdrop | `blur(10px)` |
| cursor | `pointer` |
Size: 32px tall, from 41px wide, padding 0px × 14px.

**Hover**
| property | rest | hover |
|---|---|---|
| borderTopColor | `rgb(140, 140, 140)` | `rgb(239, 239, 239)` |
Transitions: borderBottomColor 300ms cubic-bezier(0.19, 1, 0.22, 1); borderLeftColor 300ms cubic-bezier(0.19, 1, 0.22, 1); borderRightColor 300ms cubic-bezier(0.19, 1, 0.22, 1); borderTopColor 300ms cubic-bezier(0.19, 1, 0.22, 1)
Inside it: div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1); div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1)

**Focus-visible**: outline `1px auto rgb(16, 16, 16)`, offset 0px

## button-secondary-2 (button, ×8)
![button-secondary-2](../assets/reference/button-secondary-2.jpg)

| property | value |
|---|---|
| background | `#000000` |
| color | `#000000` |
| border | `1px solid #ff98a2` |
| radius | `12px` |
| font | `900 14px/28px` |
| family | `Roboto` |
| textTransform | `uppercase` |
| padding | `12px 12px 12px 12px` |
| transition | `border-color 0.6s cubic-bezier(0.19, 1, 0.22, 1)` |
| cursor | `pointer` |
Size: 50px tall, from 48px wide, padding 12px × 12px.

**Hover**
| property | rest | hover |
|---|---|---|
| borderTopColor | `rgb(255, 152, 162)` | `rgb(239, 239, 239)` |
Transitions: borderBottomColor 600ms cubic-bezier(0.19, 1, 0.22, 1); borderLeftColor 600ms cubic-bezier(0.19, 1, 0.22, 1); borderRightColor 600ms cubic-bezier(0.19, 1, 0.22, 1); borderTopColor 600ms cubic-bezier(0.19, 1, 0.22, 1)
Inside it: a.group.dr-rounded-12 322×50 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1); span.flex.h-full “documentation” 274×28 — opacity 600ms cubic-bezier(0.19, 1, 0.22, 1); span.flex.h-full “documentation” 274×28 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1); span.flex.h-full “documentation” — opacity 400ms cubic-bezier(0.19, 1, 0.22, 1); span.flex.h-full “documentation” — scale 600ms cubic-bezier(0.19, 1, 0.22, 1); div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1)

## button-primary (button, ×8)
![button-primary](../assets/reference/button-primary.jpg)
Examples: “Featured”

| property | value |
|---|---|
| background | `#ff98a2` |
| color | `#000000` |
| radius | `4px` |
| font | `400 12px/13.56px` |
| family | `Roboto` |
| textTransform | `uppercase` |
| padding | `4px 8px 4px 8px` |
| cursor | `pointer` |
Size: 22px tall, from 74px wide, padding 4px × 8px.

**Hover**
| property | rest | hover |
|---|---|---|

Inside it: div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1); a.dr-rounded-8.relative 480×360 — opacity 600ms cubic-bezier(0.19, 1, 0.22, 1); div.dr-bottom-16.dr-right-16 32×32 — opacity 600ms cubic-bezier(0.19, 1, 0.22, 1); svg.icon.w-[33%] 3×3 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1); a.dr-text-18.inline-block “Lando Norris” 101×24 — color 600ms cubic-bezier(0.19, 1, 0.22, 1); a.dr-rounded-8.relative 480×360 — opacity 246ms cubic-bezier(0.19, 1, 0.22, 1)

## button-secondary-3 (button, ×4)
![button-secondary-3](../assets/reference/button-secondary-3.jpg)
Examples: “home”

| property | value |
|---|---|
| background | `#ff98a2` |
| color | `#efefef` |
| radius | `4px` |
| font | `400 16px/normal` |
| family | `Anton` |
| padding | `6px 6px 6px 6px` |
| cursor | `pointer` |
Size: 40px tall, from 40px wide, padding 6px × 6px.

**Hover**
| property | rest | hover |
|---|---|---|

Inside it: div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1)

**Focus-visible**: outline `1px auto rgb(16, 16, 16)`, offset 1px

## button-secondary-4 (button, ×2)
![button-secondary-4](../assets/reference/button-secondary-4.jpg)

| property | value |
|---|---|
| background | `#ff98a2` |
| color | `#000000` |
| font | `900 14px/28px` |
| family | `Roboto` |
| textTransform | `uppercase` |
| padding | `0px 24px 0px 24px` |
| cursor | `pointer` |
| ::after | `{"content":"\"\"","backgroundColor":"rgb(239, 239, 239)","width":"128px","height":"48px","position":"absolute","transform":"none","transitionProperty":"transform, translate, scale, rotate","transitionDuration":"0.6s","transitionTimingFunction":"cubic-bezier(0.19, 1, 0.22, 1)","borderRadius":"0px","o` |
Size: 48px tall, from 128px wide, padding 0px × 24px.

**Hover**
| property | rest | hover |
|---|---|---|

Transitions: scale 600ms cubic-bezier(0.19, 1, 0.22, 1)
Inside it: span.relative.flex “Subscribe” 80×48 — opacity 600ms cubic-bezier(0.19, 1, 0.22, 1); span.relative.flex “Subscribe” 80×48 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1); span.absolute.top-0 “Subscribe” — opacity 400ms cubic-bezier(0.19, 1, 0.22, 1); span.absolute.top-0 “Subscribe” — scale 600ms cubic-bezier(0.19, 1, 0.22, 1); div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1)

**Focus-visible**: outline `1px auto rgb(16, 16, 16)`, offset 0px

## button-secondary-5 (button, ×2)
![button-secondary-5](../assets/reference/button-secondary-5.jpg)
Examples: “All”

| property | value |
|---|---|
| background | `#ff98a2` |
| color | `#000000` |
| border | `1px solid #ff98a2` |
| radius | `32px` |
| font | `400 12px/normal` |
| family | `Roboto` |
| padding | `0px 14px 0px 14px` |
| gap | `4px` |
| transition | `background-color 0.3s cubic-bezier(0.19, 1, 0.22, 1), color 0.3s cubic-bezier(0.19, 1, 0.22, 1), border-color 0.3s cubic-bezier(0.19, 1, 0.22, 1)` |
| backdrop | `blur(10px)` |
| cursor | `pointer` |
Size: 32px tall, from 44px wide, padding 0px × 14px.

**Hover**
| property | rest | hover |
|---|---|---|

Inside it: div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1); div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1)

**Focus-visible**: outline `1px auto rgb(16, 16, 16)`, offset 0px

## input (input, ×9)
![input](../assets/reference/input.jpg)
Examples: “Credit 1 name”, “Credit 1 website”, “Credit 1 twitter”, “Credit 1 linkedin”

| property | value |
|---|---|
| background | `#efefef` |
| color | `#000000` |
| border | `1px solid #ff98a2` |
| radius | `16px` |
| font | `400 14px/normal` |
| family | `Roboto` |
| padding | `0px 16px 0px 16px` |
| cursor | `pointer` |
Size: 48px tall, from 249px wide, padding 0px × 16px.

**Hover**
| property | rest | hover |
|---|---|---|

Inside it: div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1)

**Focus-visible**: outline `1px none rgb(16, 16, 16)`, offset 0px

## input-2 (input, ×3)
![input-2](../assets/reference/input-2.jpg)

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#efefef` |
| font | `400 14px/normal` |
| family | `Roboto` |
| padding | `0px 0px 0px 0px` |
| cursor | `pointer` |
Size: 1px tall, from 1px wide, padding 0px × 0px.

## input-3 (input, ×2)
![input-3](../assets/reference/input-3.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#efefef` |
| font | `400 16px/21.28px` |
| family | `Roboto` |
| padding | `0px 24px 0px 24px` |
| cursor | `pointer` |
Size: 48px tall, from 309px wide, padding 0px × 24px.

**Hover**
| property | rest | hover |
|---|---|---|

Inside it: div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1)

**Focus-visible**: outline `1px none rgb(16, 16, 16)`, offset 0px

## input-4 (input, ×2)
![input-4](../assets/reference/input-4.jpg)

| property | value |
|---|---|
| background | `rgb(0 0 0 / 0.5)` |
| color | `#efefef` |
| border | `1px solid #8c8c8c` |
| radius | `32px` |
| font | `400 14px/normal` |
| family | `Roboto` |
| padding | `0px 16px 0px 16px` |
| transition | `color 0.3s cubic-bezier(0.19, 1, 0.22, 1), background-color 0.3s cubic-bezier(0.19, 1, 0.22, 1), border-color 0.3s cubic-bezier(0.19, 1, 0.22, 1), outline-color 0.3s cubic-bezier(0.19, 1, 0.22, 1), text-decoration-color 0.3s cubic-bezier(0.19, 1, 0.22, 1), fill 0.3s cubic-bezier(0.19, 1, 0.22, 1), stroke 0.3s cubic-bezier(0.19, 1, 0.22, 1), --tw-gradient-from 0.3s cubic-bezier(0.19, 1, 0.22, 1), --tw-gradient-via 0.3s cubic-bezier(0.19, 1, 0.22, 1), --tw-gradient-to 0.3s cubic-bezier(0.19, 1, 0.22, 1)` |
| backdrop | `blur(10px)` |
| cursor | `pointer` |
Size: 32px tall, from 207px wide, padding 0px × 16px.

**Hover**
| property | rest | hover |
|---|---|---|

Inside it: div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1)

**Focus-visible**: outline `1px none rgb(239, 239, 239)`, offset 0px

## card (card, ×7)
![card](../assets/reference/card.jpg)

| property | value |
|---|---|
| background | `rgb(239 239 239 / 0.8)` |
| color | `#000000` |
| border | `1px solid #000000` |
| font | `400 16px/normal` |
| family | `Anton` |
| padding | `24px 24px 24px 24px` |
| backdrop | `blur(5px)` |
Size: 437px tall, from 437px wide, padding 24px × 24px.

**Hover**
| property | rest | hover |
|---|---|---|

Transitions: borderBottomColor 400ms cubic-bezier(0.19, 1, 0.22, 1); borderLeftColor 400ms cubic-bezier(0.19, 1, 0.22, 1); borderRightColor 400ms cubic-bezier(0.19, 1, 0.22, 1); borderTopColor 400ms cubic-bezier(0.19, 1, 0.22, 1); translate 400ms cubic-bezier(0.19, 1, 0.22, 1)
Inside it: div.dr-border-2.absolute 40×40 — scale 600ms cubic-bezier(0.19, 1, 0.22, 1); div.cursor-pointer.transition-[translate,border-color] 437×437 — borderBottomColor 400ms cubic-bezier(0.19, 1, 0.22, 1); div.cursor-pointer.transition-[translate,border-color] 437×437 — borderLeftColor 400ms cubic-bezier(0.19, 1, 0.22, 1); div.cursor-pointer.transition-[translate,border-color] 437×437 — borderRightColor 400ms cubic-bezier(0.19, 1, 0.22, 1); div.cursor-pointer.transition-[translate,border-color] 437×437 — borderTopColor 400ms cubic-bezier(0.19, 1, 0.22, 1); div.cursor-pointer.transition-[translate,border-color] 437×437 — translate 400ms cubic-bezier(0.19, 1, 0.22, 1)

## navbar (navbar, ×4)
![navbar](../assets/reference/navbar.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#efefef` |
| font | `400 16px/normal` |
| family | `Anton` |
| padding | `0px 40px 0px 40px` |
| gap | `24px` |
| transition | `color 0.6s cubic-bezier(0.19, 1, 0.22, 1)` |
Size: 56px tall, from 1440px wide, padding 0px × 40px.

## footer (footer, ×4)
![footer](../assets/reference/footer.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#efefef` |
| font | `400 16px/normal` |
| family | `Anton` |
| padding | `60px 0px 20px 0px` |
Size: 900px tall, from 1440px wide, padding 60px × 0px.
