# Tokens

## Colour (dark scheme)
Ordered by painted weight (area × use). `aliases` are the source's own custom properties holding the same value.

| token | value | role | share | used for | dark | source aliases |
|---|---|---|---|---|---|---|
| background | `#000000` | background | 91.6% | bg | — | --color-secondary --color-black |
| text | `#efefef` | text | 3% | text, accent-fill | — | --color-white --color-primary |
| text-secondary | `#ff98a2` | text-secondary | 2% | bg, text | — | --color-contrast --color-pink |
| surface | `#101010` | surface | 1.2% | accent-fill | — | — |
| surface-2 | `rgb(239 239 239 / 0.8)` | surface-2 | 1.1% | bg | — | — |
| surface-3 | `rgb(0 0 0 / 0.2)` | surface-3 | 0.6% | bg | — | — |
| surface-4 | `rgb(0 0 0 / 0.5)` | surface-4 | 0.3% | bg, accent-fill | — | — |
| gray-600 | `#8c8c8c` | palette | 0.3% | text, accent-fill | — | — |
| white-1000 | `#ffffff` | palette | 0% | accent-fill | — | --leva-colors-highlight3 --leva-colors-folderTextColor --leva-colors-toolTipBackground |

## Typography
| family | share | weights | source | licence | substitute |
|---|---|---|---|---|---|
| Roboto | 82.3% | 400 500 900 | self-hosted | open (Google Fonts) — load it from Google Fonts or self-host | — |
| Panchang | 9.9% | 700 | self-hosted | free (ITF Free Font License, Fontshare) — check terms | Inter |
| Anton | 7.4% | 400 | self-hosted | open (Google Fonts) — load it from Google Fonts or self-host | — |

| style | family | size | weight | line-height | tracking | case | share | responsive | sample |
|---|---|---|---|---|---|---|---|---|---|
| h1 | Anton | 160px | 400 | 152px (0.95) | 0em | uppercase | 0.6% | — | Lenis Templates |
| display | Anton | 141.2px | 400 | 134.1px (0.95) | 0em | uppercase | 5% | 58.2→174.4→141.2px | open to features and sponsors |
| display-regular | Anton | 96px | 400 | 86.4px (0.9) | 0em | uppercase | 1.4% | — | Submit website |
| display-medium | Roboto | 64px | 500 | 64px (1) | 0em | none | 5.2% | 33.3→37.1→64px | Lenis is a free, that turns native scrol |
| display-bold | Panchang | 52px | 700 | 46.8px (0.9) | 0em | uppercase | 0.7% | 20.8→30.1→52px | Smooth Scroll |
| title | Panchang | 28px | 700 | 28px (1) | 0em | uppercase | 9.2% | 20.8→16.2→28px | share scroll experiences with the commun |
| title-medium | Roboto | 24px | 500 | 31.9px (1.329) | 0em | none | 0.4% | — | Michelangelus |
| title-regular | Anton | 24px | 400 | 24px (1) | 0em | uppercase | 0.4% | — | to explore |
| label | Roboto | 19px | 400 | 25.3px (1.332) | 0em | none | 0.9% | — | Fabio Ottaviani |
| body | Roboto | 18px | 500 | 23.9px (1.328) | 0em | none | 42% | 18.7→10.4→18px | Smooth scroll used to be a hard sell — h |
| small | Roboto | 16px | 400 | 21.3px (1.331) | 0em | none | 10.6% | 14.6→9.3→16px | Shader Development Studio |
| overline | Roboto | 14px | 900 | 15.8px (1.129) | 0em | uppercase | 7.9% | 20.8→8.1→14px | The smooth scroll library |
| caption | Roboto | 14px | 400 | normal | 0em | none | 1.1% | — | Select technologies |
| micro | Roboto | 12px | 900 | 13.6px (1.133) | 0em | uppercase | 4.1% | 12.5→7→12px | darkroom.engineering |
| micro-regular | Roboto | 12px | 400 | 13.6px (1.133) | 0em | uppercase | 1.7% | 12.5→7→12px | + Add credit |
| micro-regular-2 | Roboto | 12px | 400 | normal | 0em | none | 8.4% | — | Subscribe to the Lenis newsletter. Get t |

Scale: ratio 1.073 (minor second), base 18px, fit 0.82. Sizes in use: 12, 14, 16, 18, 19, 24, 28, 52, 64, 96, 141.2, 160.

## Spacing
Grid 4px (88.7% of measured paddings, margins and gaps sit on it; common off-grid values: 14, 6).

| value | share |
|---|---|
| 16px | 24.9% |
| 24px | 24.2% |
| 12px | 12.7% |
| 8px | 8.9% |
| 14px | 5.8% |
| 6px | 4.9% |
| 40px | 4.4% |
| 4px | 4.4% |
| 64px | 2% |
| 20px | 1.3% |
| 32px | 1.1% |
| 60px | 0.9% |
| 48px | 0.9% |
| 30px | 0.7% |
| 96px | 0.7% |
| 320px | 0.4% |

## Radii
| radius | count | on |
|---|---|---|
| 9999px | 21 | surface, small, button |
| 16px | 13 | surface, button |
| 4px | 12 | button, small |
| 12px | 8 | surface |

## Borders
| border | count |
|---|---|
| `1px solid #ff98a2` | 92 |
| `1px solid #8c8c8c` | 52 |
| `1px solid #000000` | 28 |
| `2px solid #ff98a2` | 16 |
| `1px solid rgb(255 152 162 / 0.3)` | 4 |
| `1px dashed rgb(255 152 162 / 0.5)` | 4 |

## Shadows
None.

## Backdrop
- `blur(10px)` (×19)
- `blur(5px)` (×7)
- `blur(2px)` (×1)
