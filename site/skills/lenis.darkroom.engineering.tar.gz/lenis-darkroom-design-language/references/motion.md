# Motion

## Scroll feel
Smoothed scrolling (lenis). One notch moves 100px, reaches 90% in 239ms and settles in 519ms — an exponential approach with time constant 117ms (lerp ≈ 0.14/frame at 60fps), or as a duration curve 710ms cubic-bezier(0.19,0.99,0.46,0.96).

## Tokens
| duration | uses |
|---|---|
| 600ms | 1100 |
| 400ms | 76 |
| 1200ms | 67 |
| 300ms | 40 |
| 170ms | 12 |
| 1500ms | 9 |
| 2050ms | 7 |
| 246ms | 4 |
| 1850ms | 2 |
| 9ms | 2 |

| curve | uses | kind |
|---|---|---|
| `cubic-bezier(0.19, 1, 0.22, 1)` | 1306 | bezier |
| `cubic-bezier(0.455, 0.03, 0.515, 0.955)` | 12 | bezier |
| `linear` | 12 | bezier |
| `ease-out` | 6 | bezier |
| `steps(1, end)` | 1 | bezier |
| `cubic-bezier(0,2.3,1,-1.18)` | 1 | bezier |
| `ease-in` | 1 | bezier |
| `cubic-bezier(0.28,2.47,1,-1.5)` | 1 | bezier |
| `cubic-bezier(0,2.12,0,-0.04)` | 1 | bezier |
| `cubic-bezier(0,1.85,0,0.02)` | 1 | bezier |

Libraries detected: lenis, three, canvas, next, tailwindLike.

## Intro choreography (ms after load)
- -26ms — div.w-full.dt:dr-w-480 480×437 (intro-slide-11)
- 1193ms — path.translate-y-0.transition-transform (intro-translate-7)
- 1268ms — path.translate-y-0.transition-transform (intro-translate-6)
- 1343ms — path.translate-y-0.transition-transform (intro-translate-8)
- 1418ms — path.translate-y-0.transition-transform (intro-translate-10)
- 1493ms — path.translate-y-0.transition-transform (intro-translate-9)
- 2618ms — div.fixed.top-0 1440×900 (intro-translate-2)
- 2618ms — div.dr-py-30.dr-px-32 1440×900 (intro-translate-5)
- 2786ms — svg.dt:-translate-y-full.dt:transition-transform 1376×340 (intro-translate-2)
- 2786ms — svg.dt:-translate-y-full.dt:transition-transform 1360×336 (intro-translate-2)
- 2787ms — a.group.dr-rounded-12 322×50 (intro-fade-3)
- 2787ms — a.group.dr-rounded-12 322×50 (intro-translate-4)
- 3237ms — h2.dr-mb-8.dt:dr-mb-12 “Smooth Scroll” 783×47 (intro-translate-1)
- 3237ms — p “scroll” 191×24 (intro-translate-1)
- 3237ms — p “to explore” 191×24 (intro-translate-1)
- 3237ms — p “The smooth scroll librar” 322×16 (intro-translate-1)
- 3237ms — p “by” 322×16 (intro-translate-1)

## Load / intro
Plays once when the page loads. Use `data-intro="<name>"` with motion.css; set `--i` for stagger order.

### intro-translate-1 — ×5
Seen on: h2.dr-mb-8.dt:dr-mb-12 “Smooth Scroll” 783×47; p “scroll” 191×24; p “to explore” 191×24; p “The smooth scroll librar” 322×16
- from `translate: 0px 200%;` to `translate: 0px;`
- 2050ms, `cubic-bezier(0.19, 1, 0.22, 1)`, delay 450ms — source: css-transition
```css
@keyframes intro-translate-1 {
  from { translate: 0px 200%; }
  to { translate: 0px; }
}
```
### intro-translate-2 — ×3
Seen on: div.fixed.top-0 1440×900; svg.dt:-translate-y-full.dt:transition-transform 1376×340; svg.dt:-translate-y-full.dt:transition-transform 1360×336
- from `translate: none;` to `translate: 0px -100%;`
- 1500ms, `cubic-bezier(0.19, 1, 0.22, 1)`, delay 1500ms — source: css-transition
```css
@keyframes intro-translate-2 {
  from { translate: none; }
  to { translate: 0px -100%; }
}
```
### intro-fade-3 — ×2
Seen on: a.group.dr-rounded-12 322×50
- from `opacity: 0.5;` to `opacity: 1;`
- 2050ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
@keyframes intro-fade-3 {
  from { opacity: 0.5; }
  to { opacity: 1; }
}
```
### intro-translate-4 — ×2
Seen on: a.group.dr-rounded-12 322×50
- from `translate: 0px 100%;` to `translate: 0px;`
- 1850ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
@keyframes intro-translate-4 {
  from { translate: 0px 100%; }
  to { translate: 0px; }
}
```
### intro-translate-5 — ×1
Seen on: div.dr-py-30.dr-px-32 1440×900
- from `translate: none;` to `translate: 0px 937.5px;`
- 1500ms, `cubic-bezier(0.19, 1, 0.22, 1)`, delay 1500ms — source: css-transition
```css
@keyframes intro-translate-5 {
  from { translate: none; }
  to { translate: 0px 937.5px; }
}
```
### intro-translate-6 — ×1
Seen on: path.translate-y-0.transition-transform
- from `translate: 0px 110%;` to `translate: 0px;`
- 1500ms, `cubic-bezier(0.19, 1, 0.22, 1)`, delay 150ms — source: css-transition
```css
@keyframes intro-translate-6 {
  from { translate: 0px 110%; }
  to { translate: 0px; }
}
```
### intro-translate-7 — ×1
Seen on: path.translate-y-0.transition-transform
- from `translate: 0px 105%;` to `translate: 0px;`
- 1500ms, `cubic-bezier(0.19, 1, 0.22, 1)`, delay 75ms — source: css-transition
```css
@keyframes intro-translate-7 {
  from { translate: 0px 105%; }
  to { translate: 0px; }
}
```
### intro-translate-8 — ×1
Seen on: path.translate-y-0.transition-transform
- from `translate: 0px 115%;` to `translate: 0px;`
- 1500ms, `cubic-bezier(0.19, 1, 0.22, 1)`, delay 225ms — source: css-transition
```css
@keyframes intro-translate-8 {
  from { translate: 0px 115%; }
  to { translate: 0px; }
}
```
### intro-translate-9 — ×1
Seen on: path.translate-y-0.transition-transform
- from `translate: 0px 125%;` to `translate: 0px;`
- 1500ms, `cubic-bezier(0.19, 1, 0.22, 1)`, delay 375ms — source: css-transition
```css
@keyframes intro-translate-9 {
  from { translate: 0px 125%; }
  to { translate: 0px; }
}
```
### intro-translate-10 — ×1
Seen on: path.translate-y-0.transition-transform
- from `translate: 0px 120%;` to `translate: 0px;`
- 1500ms, `cubic-bezier(0.19, 1, 0.22, 1)`, delay 300ms — source: css-transition
```css
@keyframes intro-translate-10 {
  from { translate: 0px 120%; }
  to { translate: 0px; }
}
```
### intro-slide-11 — ×1
Seen on: div.w-full.dt:dr-w-480 480×437
- from `transform: translate(1440px, 0px);` to `transform: translate(0px, 0px);`
- 0ms, `steps(1, end)` — source: js
```css
@keyframes intro-slide-11 {
  from { transform: translate(1440px, 0px); }
  to { transform: translate(0px, 0px); }
}
```

## Scroll reveals
Triggered as elements enter the viewport. Use `data-reveal="<name>"`; motion.js observes them at the measured entry point.

### reveal-tint-12 — ×23
Seen on: header.dr-layout-grid-inner.sticky 1440×56; svg 22×24; svg.icon 22×24; div.flex.flex-col 480×437
- from `color: rgb(239, 239, 239);` to `color: rgb(0, 0, 0);`
- 600ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
[data-reveal="reveal-tint-12"] { color: rgb(239, 239, 239); transition: color 600ms cubic-bezier(0.19, 1, 0.22, 1); }
[data-reveal="reveal-tint-12"].is-in { color: rgb(0, 0, 0); }
```
### reveal-translate-13 — ×7
Seen on: span.inline-block.translate-y-full “Why” 160×86; span.inline-block.translate-y-full “smooth” 296×86; span.inline-block.translate-y-full “scroll?” 306×86; span.inline-block.translate-y-full “Lenis runs” 402×86
- from `translate: 0px 100%;` to `translate: 0px;`
- 1200ms, `cubic-bezier(0.19, 1, 0.22, 1)`, starts at 91% viewport — source: css-transition
```css
[data-reveal="reveal-translate-13"] { translate: 0px 100%; transition: translate 1200ms cubic-bezier(0.19, 1, 0.22, 1); }
[data-reveal="reveal-translate-13"].is-in { translate: 0px; }
```
### reveal-fade-out-14 — ×7
Seen on: a.dr-rounded-8.relative 480×360
- from `opacity: 0.33;` to `opacity: 0;`
- 600ms, `cubic-bezier(0.19, 1, 0.22, 1)`, starts at 34% viewport — source: css-transition
```css
[data-reveal="reveal-fade-out-14"] { opacity: 0.33; transition: opacity 600ms cubic-bezier(0.19, 1, 0.22, 1); }
[data-reveal="reveal-fade-out-14"].is-in { opacity: 0; }
```
### reveal-fade-out-15 — ×7
Seen on: div.dr-bottom-16.dr-right-16 32×32
- from `opacity: 1;` to `opacity: 0;`
- 600ms, `cubic-bezier(0.19, 1, 0.22, 1)`, starts at 69% viewport — source: css-transition
```css
[data-reveal="reveal-fade-out-15"] { opacity: 1; transition: opacity 600ms cubic-bezier(0.19, 1, 0.22, 1); }
[data-reveal="reveal-fade-out-15"].is-in { opacity: 0; }
```
### reveal-scale-16 — ×7
Seen on: svg.icon.w-[33%] 3×3
- from `transform: scale(1);` to `transform: scale(0.33);`
- 600ms, `cubic-bezier(0.19, 1, 0.22, 1)`, starts at 70% viewport — source: css-transition
```css
[data-reveal="reveal-scale-16"] { transform: scale(1); transition: transform 600ms cubic-bezier(0.19, 1, 0.22, 1); }
[data-reveal="reveal-scale-16"].is-in { transform: scale(0.33); }
```
### reveal-tint-17 — ×7
Seen on: a.dr-text-18.inline-block “Lenis Framer Starter Kit” 186×24; a.dr-text-18.inline-block “Grand Theft Auto VI” 156×24; a.dr-text-18.inline-block “Google Cloud x Team USA” 205×24; a.dr-text-18.inline-block “Annnimate — Motion compo” 269×24
- from `color: rgb(255, 152, 162);` to `color: rgb(239, 239, 239);`
- 600ms, `cubic-bezier(0.19, 1, 0.22, 1)`, starts at 76% viewport — source: css-transition
```css
[data-reveal="reveal-tint-17"] { color: rgb(255, 152, 162); transition: color 600ms cubic-bezier(0.19, 1, 0.22, 1); }
[data-reveal="reveal-tint-17"].is-in { color: rgb(239, 239, 239); }
```
### reveal-fade-18 — ×7
Seen on: div.absolute.transition-[opacity,translate] 437×437
- from `opacity: 0; translate: 100% 100%;` to `opacity: 1; translate: none;`
- 1200ms, `cubic-bezier(0.19, 1, 0.22, 1)`, starts at 82% viewport — source: css-transition
```css
[data-reveal="reveal-fade-18"] { opacity: 0; translate: 100% 100%; transition: opacity 1200ms cubic-bezier(0.19, 1, 0.22, 1),
    translate 1200ms cubic-bezier(0.19, 1, 0.22, 1); }
[data-reveal="reveal-fade-18"].is-in { opacity: 1; translate: none; }
```
### reveal-scale-19 — ×4
Seen on: div.dr-border-2.absolute 40×40
- from `transform: scale(none);` to `transform: scale(0.5);`
- 600ms, `cubic-bezier(0.19, 1, 0.22, 1)`, starts at 49% viewport — source: css-transition
```css
[data-reveal="reveal-scale-19"] { transform: scale(none); transition: transform 600ms cubic-bezier(0.19, 1, 0.22, 1); }
[data-reveal="reveal-scale-19"].is-in { transform: scale(0.5); }
```
### reveal-tint-20 — ×4
Seen on: svg 22×24; svg.icon 22×24
- from `background-color: rgb(0, 0, 0);` to `background-color: rgb(239, 239, 239);`
- 600ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
[data-reveal="reveal-tint-20"] { background-color: rgb(0, 0, 0); transition: background-color 600ms cubic-bezier(0.19, 1, 0.22, 1); }
[data-reveal="reveal-tint-20"].is-in { background-color: rgb(239, 239, 239); }
```
### reveal-fade-21 — ×2
Seen on: div.desktop-only.relative 207×50
- from `opacity: 0; translate: 0px 20%;` to `opacity: 1; translate: none;`
- 600ms, `cubic-bezier(0.455, 0.03, 0.515, 0.955)`, starts at 92% viewport — source: css-transition
```css
[data-reveal="reveal-fade-21"] { opacity: 0; translate: 0px 20%; transition: opacity 600ms cubic-bezier(0.455, 0.03, 0.515, 0.955),
    translate 600ms cubic-bezier(0.455, 0.03, 0.515, 0.955); }
[data-reveal="reveal-fade-21"].is-in { opacity: 1; translate: none; }
```
### reveal-fill-22 — ×1
Seen on: path
- from `fill: rgb(0, 0, 0);` to `fill: rgb(239, 239, 239);`
- 600ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
[data-reveal="reveal-fill-22"] { fill: rgb(0, 0, 0); transition: fill 600ms cubic-bezier(0.19, 1, 0.22, 1); }
[data-reveal="reveal-fill-22"].is-in { fill: rgb(239, 239, 239); }
```

## Scroll-linked
Follows the scroll position continuously (parallax/scrub). Use `data-parallax="<name>"`.

### parallax-scale-23 — ×1
Seen on: div.dr-h-4.relative
- from `transform: scale(0); width: 1.5px;` to `transform: scale(0); width: 0px;`
- 4704ms, `linear`, moves 0.039px per px scrolled — source: js
```css
transition: transform 4704ms linear,
    width 4704ms linear;
```
### parallax-down-24 — ×1
Seen on: div 405×180
- from `transform: translate(0px, -71.07px);` to `transform: translate(0px, 72px);`
- 2384ms, `linear`, moves 0.133px per px scrolled — source: js
```css
transition: transform 2384ms linear;
```
### parallax-up-25 — ×1
Seen on: div 437×120
- from `transform: translate(0px, 69.46px);` to `transform: translate(0px, -72px);`
- 2327ms, `linear`, moves -0.14px per px scrolled — source: js
```css
transition: transform 2327ms linear;
```
### parallax-scale-26 — ×1
Seen on: div.dr-h-4.relative
- from `transform: scale(0); width: 0.9px;` to `transform: scale(0.33); width: 471px;`
- 26655ms, `linear`, moves 0.039px per px scrolled — source: js
```css
transition: transform 26655ms linear,
    width 26655ms linear;
```
### parallax-slide-27 — ×1
Seen on: div.w-full.dt:dr-w-480 480×437
- from `transform: translate(-10.61px, 0px);` to `transform: translate(-5040px, 0px);`
- 17447ms, `linear`, moves -0.683px per px scrolled — source: js
```css
transition: transform 17447ms linear;
```
### parallax-scale-28 — ×1
Seen on: div.dr-h-4.relative
- from `transform: scale(0.33); width: 471.7px;` to `transform: scale(0.64); width: 915.8px;`
- 17783ms, `linear`, moves 0.039px per px scrolled — source: js
```css
transition: transform 17783ms linear,
    width 17783ms linear;
```
### parallax-scale-29 — ×1
Seen on: div.dr-h-4.relative
- from `transform: scale(0.64); width: 916.2px;` to `transform: scale(0); width: 0px;`
- 27288ms, `linear`, moves 0.039px per px scrolled — source: js
```css
transition: transform 27288ms linear,
    width 27288ms linear;
```
### parallax-scale-30 — ×1
Seen on: div.dr-h-4.relative
- from `transform: scale(0.01); width: 14.7px;` to `transform: scale(1); width: 1440px;`
- 6568ms, `linear`, moves 0.47px per px scrolled — source: js
```css
transition: transform 6568ms linear,
    width 6568ms linear;
```
### parallax-scale-31 — ×1
Seen on: div.dr-h-4.relative
- from `transform: scale(0.01); width: 14.3px;` to `transform: scale(1); width: 1440px;`
- 4744ms, `linear`, moves 0.651px per px scrolled — source: js
```css
transition: transform 4744ms linear,
    width 4744ms linear;
```
### parallax-scale-32 — ×1
Seen on: div.dr-h-4.relative
- from `transform: scale(0.01); width: 16.6px;` to `transform: scale(1); width: 1440px;`
- 4443ms, `linear`, moves 0.751px per px scrolled — source: js
```css
transition: transform 4443ms linear,
    width 4443ms linear;
```

## Hover
Measured by hovering every distinct interactive element.

### hover-scale-33 — ×220
Seen on: div.dr-border-2.absolute 40×40; a.group.dr-rounded-12 322×50; span.flex.h-full “documentation” 274×28; span.flex.h-full “documentation”
- from `transform: scale(none);` to `transform: scale(0.5);`
- 600ms, `cubic-bezier(0.19, 1, 0.22, 1)`, stagger 94ms between siblings — source: css-transition
```css
transition: transform 600ms cubic-bezier(0.19, 1, 0.22, 1);
```
### hover-fade-out-34 — ×85
Seen on: span.flex.h-full “documentation” 274×28; a.dr-rounded-8.relative 480×360; div.dr-bottom-16.dr-right-16 32×32; span.flex.h-full “explore the showcase” 292×28
- from `opacity: 1;` to `opacity: 0;`
- 600ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
transition: opacity 600ms cubic-bezier(0.19, 1, 0.22, 1);
```
### hover-tint-35 — ×35
Seen on: a.dr-text-18.inline-block “Careers at Netflix” 138×24; a “Unseen Studio®” 115×21; a.dr-text-18.inline-block “Velox Themes — Templates” 222×24; a.dr-text-18.inline-block “Lando Norris” 101×24
- from `color: rgb(239, 239, 239);` to `color: rgb(255, 152, 162);`
- 600ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
transition: color 600ms cubic-bezier(0.19, 1, 0.22, 1);
```
### hover-fade-36 — ×29
Seen on: span.flex.h-full “documentation”; span.flex.h-full “explore the showcase”; span.absolute.top-0 “Subscribe”; span.flex.h-full “Load more”
- from `opacity: 0;` to `opacity: 1;`
- 400ms, `cubic-bezier(0.19, 1, 0.22, 1)`, stagger 340ms between siblings — source: css-transition
```css
transition: opacity 400ms cubic-bezier(0.19, 1, 0.22, 1);
```
### hover-tint-37 — ×24
Seen on: span.dr-rounded-12.z-10 48×50; button.dr-h-40.dr-text-12 “+ Add credit” 540×40
- from `border-bottom-color: rgb(255, 152, 162); border-left-color: rgb(255, 152, 162); border-right-color: rgb(255, 152, 162); border-color: rgb(255, 152, 162);` to `border-bottom-color: rgb(239, 239, 239); border-left-color: rgb(239, 239, 239); border-right-color: rgb(239, 239, 239); border-color: rgb(239, 239, 239);`
- 600ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
transition: border-bottom-color 600ms cubic-bezier(0.19, 1, 0.22, 1),
    border-left-color 600ms cubic-bezier(0.19, 1, 0.22, 1),
    border-right-color 600ms cubic-bezier(0.19, 1, 0.22, 1),
    border-color 600ms cubic-bezier(0.19, 1, 0.22, 1);
```
### hover-scale-38 — ×8
Seen on: a.link.justify-self-start “Showcase” 81×16; a.link.p-xs “GitHub” 47×14
- from `transform: scaleX(0);` to `—`
- 600ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
transition: transform 600ms cubic-bezier(0.19, 1, 0.22, 1);
```
### hover-fade-out-39 — ×6
Seen on: a.dr-rounded-8.relative 668×501; div.dr-bottom-16.dr-right-16 32×32; a.dr-rounded-8.relative 322×242
- from `opacity: 0.09;` to `opacity: 0;`
- 170ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
transition: opacity 170ms cubic-bezier(0.19, 1, 0.22, 1);
```
### hover-tint-40 — ×5
Seen on: button.dr-px-14.dr-h-32 104×32; a.dr-px-14.dr-h-32 110×32; button.dr-px-14.dr-h-32 “Agency” 72×32
- from `border-bottom-color: rgb(140, 140, 140); border-left-color: rgb(140, 140, 140); border-right-color: rgb(140, 140, 140); border-color: rgb(140, 140, 140);` to `border-bottom-color: rgb(239, 239, 239); border-left-color: rgb(239, 239, 239); border-right-color: rgb(239, 239, 239); border-color: rgb(239, 239, 239);`
- 300ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
transition: border-bottom-color 300ms cubic-bezier(0.19, 1, 0.22, 1),
    border-left-color 300ms cubic-bezier(0.19, 1, 0.22, 1),
    border-right-color 300ms cubic-bezier(0.19, 1, 0.22, 1),
    border-color 300ms cubic-bezier(0.19, 1, 0.22, 1);
```
### hover-scale-41 — ×3
Seen on: svg.icon.w-[33%] 3×3
- from `transform: scale(0.519408);` to `transform: scale(0.33);`
- 170ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
transition: transform 170ms cubic-bezier(0.19, 1, 0.22, 1);
```
### hover-tint-42 — ×3
Seen on: a.dr-text-18.inline-block “Michelangelus” 158×32; a.dr-text-18.inline-block “Gaspar” 56×24
- from `color: rgb(244, 214, 217);` to `color: rgb(239, 239, 239);`
- 170ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
transition: color 170ms cubic-bezier(0.19, 1, 0.22, 1);
```
### hover-fade-out-43 — ×2
Seen on: a.dr-rounded-8.relative 480×360; div.dr-bottom-16.dr-right-16 32×32
- from `opacity: 0.14;` to `opacity: 0;`
- 246ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
transition: opacity 246ms cubic-bezier(0.19, 1, 0.22, 1);
```
### hover-tint-44 — ×2
Seen on: div.cursor-pointer.transition-[translate,border-color] 437×437
- from `border-bottom-color: rgb(0, 0, 0); border-left-color: rgb(0, 0, 0); border-right-color: rgb(0, 0, 0); border-color: rgb(0, 0, 0); translate: none;` to `border-bottom-color: rgb(255, 152, 162); border-left-color: rgb(255, 152, 162); border-right-color: rgb(255, 152, 162); border-color: rgb(255, 152, 162); translate: 0px -8px;`
- 400ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
transition: border-bottom-color 400ms cubic-bezier(0.19, 1, 0.22, 1),
    border-left-color 400ms cubic-bezier(0.19, 1, 0.22, 1),
    border-right-color 400ms cubic-bezier(0.19, 1, 0.22, 1),
    border-color 400ms cubic-bezier(0.19, 1, 0.22, 1),
    translate 400ms cubic-bezier(0.19, 1, 0.22, 1);
```
### hover-scale-45 — ×1
Seen on: svg.icon.w-[33%] 3×3
- from `transform: scale(0.604967);` to `transform: scale(0.33);`
- 246ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
transition: transform 246ms cubic-bezier(0.19, 1, 0.22, 1);
```
### hover-tint-46 — ×1
Seen on: a.dr-text-18.inline-block “Lando Norris” 101×24
- from `color: rgb(246, 203, 207);` to `color: rgb(239, 239, 239);`
- 246ms, `cubic-bezier(0.19, 1, 0.22, 1)` — source: css-transition
```css
transition: color 246ms cubic-bezier(0.19, 1, 0.22, 1);
```

## Loops
Ambient, infinite animations.

### loop-opacity-54 — ×13
Seen on: div.dr-h-48.w-[40%]; div.aspect-[4/3].animate-[pulse_2s_ease-in-out_infinite]
- from `opacity: 1;` to `opacity: 1;`
- 2000ms, `ease-in-out`, loops forever — source: css-animation
```css
@keyframes loop-opacity-54 { 50%{opacity:.5} }
```
### loop-scale-55 — ×4
Seen on: div.desktop-only.relative 207×50
- from `transform: scale(0);` to `transform: scale(0);`
- 4000ms, `ease`, loops forever — source: css-animation
```css
@keyframes loop-scale-55 { 50%{transform:scaleY(1.5)} }
```
