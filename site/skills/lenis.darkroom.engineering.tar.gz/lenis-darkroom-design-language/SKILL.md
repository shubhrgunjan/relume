---
name: lenis-darkroom-design-language
description: "Build UI in the design language measured from lenis.darkroom.engineering: Dark interface, almost entirely neutral — colour is rationed (chromatic share 2%). Use whenever creating or restyling pages, sections or components that should look and move like lenis.darkroom.engineering — colours, type, spacing, components and motion come from measurement, not guesswork."
---

# lenis.darkroom.engineering design language

Measured from https://lenis.darkroom.engineering (4 pages at desktop, tablet, mobile, desktop-dark) on 2026-10-28 by relume. Every value here was read from the live site — computed styles, stylesheets, animations and a frame-by-frame motion recording — so treat them as facts, not suggestions.

## The feel
- Dark interface, almost entirely neutral — colour is rationed (chromatic share 2%).
- Maximum-contrast text (18.3:1).
- Headlines 160px / 400; body 18px at 1.328 leading.
- Crisp, near-square geometry (0px).
- Depth comes from hairline borders, not shadows.
- Translucent, blurred (glass) layers are part of the language.
- Generous vertical rhythm: sections breathe with ~56px padding on desktop.
- Entrances run ~843ms; scrolling is smoothed (lenis, lerp 0.14).

## Build to the blueprint first
This language is not only its tokens. Its home page is 42 screens of 11 sections; 3% of it is covered by visuals (1 dataviz, 8 video, 1 image, 1 tabs), at ~2 painted elements per screen. Read `references/blueprint.md` before anything else: it lists every section of the source in order, with a crop, its layout, and what it is made of. A new page must have the same kinds of sections in the same order, filled with the same kinds of things for your product: product UI built in real HTML with the measured UI grammar, illustrations in the source's style, data visualisations, logo rows, testimonial cards. Headings over empty boxes are not this language, and the checker fails them.

## Setup
1. Copy `assets/tokens.css` (plain CSS variables, text styles, component classes, `.container` and `.section` with the measured width, gutters and rhythm — use them, don't re-derive) into the project; with Tailwind v4 also import `assets/tailwind.css` after `@import "tailwindcss"`.
2. Add `assets/motion.css` and `assets/motion.js` (scroll reveals, intro choreography, stagger and scroll feel, all with measured timings).
3. Fonts: **Roboto** for display-medium, title-medium, label, body — `var(--font-sans)`; **Panchang** (use **Inter** unless you hold a licence) for display-bold, title — `var(--font-panchang)`; **Anton** for h1, display, display-regular, title-regular — `var(--font-anton)`.
   Load the open ones: `<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;900&family=Inter:wght@700&family=Anton:wght@400&display=swap" rel="stylesheet">`

## Core tokens
- Background #000000, text #efefef / #ff98a2 / —, accent —, surface #101010, border —.
- Type scale ≈1.073 (minor second) from 18px: h1 160/400, display 141.2/400, display-regular 96/400, display-medium 64/500, display-bold 52/700, title 28/700, title-medium 24/500, title-regular 24/400.
- Radii 9999px, 16px, 4px, 12px. Spacing grid 4px. Container 1360px, gutters 40 / 23 / 17px (desktop / tablet / mobile).
- Motion: 600ms, 400ms, 1200ms, 300ms, 170ms; curves `cubic-bezier(0.19, 1, 0.22, 1)`, `cubic-bezier(0.455, 0.03, 0.515, 0.955)`, `linear`. Scroll: smoothed (lenis, lerp 0.14, settles in 519ms).
- Primary action: #ff98a2 / #000000, radius 4px, 400 12px/13.56px; on hover .

## Do
- Use only the colour tokens in `assets/tokens.css`; the accent (—) covers ≤3% of any screen.
- Set text with the named styles (`.text-body`, `.text-h1` …); never invent sizes between them.
- Space on the 4px grid (16, 24, 12, 8, 14, 6 are the workhorses); sections get ~56px vertical padding on desktop.
- Floating chrome (nav, popovers) uses the measured backdrop blur over a translucent fill.
- Install the measured smooth scroll (lenis, lerp 0.14) via `assets/motion.js`.

## Don't
- Do not use drop shadows for depth; separate surfaces with the hairline border tokens.
- Do not use radii outside 9999px, 16px, 4px, 12px.
- Do not use durations or curves that are not in the motion tokens (600ms, 400ms, 1200ms, 300ms, 170ms).
- Do not copy the source’s logo, product names, photography, illustrations or copy; describe your own product in this language.

## Motion signature
- **intro-translate-1** (load, ×5): translate: 0px 200%; → translate: 0px; over 2050ms `cubic-bezier(0.19, 1, 0.22, 1)`, delay 450ms.
- **intro-translate-2** (load, ×3): translate: none; → translate: 0px -100%; over 1500ms `cubic-bezier(0.19, 1, 0.22, 1)`, delay 1500ms.
- **intro-fade-3** (load, ×2): opacity: 0.5; → opacity: 1; over 2050ms `cubic-bezier(0.19, 1, 0.22, 1)`.
- **intro-translate-4** (load, ×2): translate: 0px 100%; → translate: 0px; over 1850ms `cubic-bezier(0.19, 1, 0.22, 1)`.
- **intro-translate-5** (load): translate: none; → translate: 0px 937.5px; over 1500ms `cubic-bezier(0.19, 1, 0.22, 1)`, delay 1500ms.
- **intro-translate-6** (load): translate: 0px 110%; → translate: 0px; over 1500ms `cubic-bezier(0.19, 1, 0.22, 1)`, delay 150ms.

## Workflow
1. Read `references/tokens.md` and `references/components.md` before writing UI; open the images in `assets/reference/` to see the look.
2. Build with the component classes and text styles; take motion from `references/motion.md` (exact CSS per pattern).
3. Run `node scripts/lint.mjs <your files…>` and fix every off-system colour, size, radius, duration and curve it reports.
4. If the relume MCP server is connected, call `check_style` with your page's URL: it re-measures your page and compares its DNA (composition, tokens and motion) with this one. Fix what it reports until it passes.

## References
- `references/blueprint.md` — the page, section by section: order, layout, contents, density, crops, and the UI grammar of the product mock-ups.
- `references/tokens.md` — every colour (with dark values and the source’s own variable names), text style (with fluid sizes), spacing, radius, border, shadow, gradient.
- `references/components.md` — buttons, links, inputs, cards, badges, navigation, footer: resting style, hover/focus states and transitions.
- `references/motion.md` — scroll feel, intro choreography, scroll reveals, hover motion, loops; exact CSS.
- `references/layout.md` — containers, gutters, grids, breakpoints, section rhythm, density.
- `assets/DESIGN.md` — the same system in Google's DESIGN.md format, for other tools.
