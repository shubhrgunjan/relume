# Tokens

## Colour (light scheme)
Ordered by painted weight (area × use). `aliases` are the source's own custom properties holding the same value.

| token | value | role | share | used for | dark | source aliases |
|---|---|---|---|---|---|---|
| background | `#ffffff` | background | 69.9% | bg | — | --light-background-cell --background-color-primary --color-white |
| surface | `#f7f5f3` | surface | 11.5% | bg | — | --color-paper --background-color-paper --color-background-paper |
| border | `rgb(13 13 13 / 0.12)` | border | 3.2% | border | — | — |
| surface-2 | `rgb(0 0 0 / 0.05)` | surface-2 | 2.7% | bg | — | — |
| surface-3 | `rgb(0 0 0 / 0.2)` | surface-3 | 2.1% | bg | — | — |
| text | `#0d0d0d` | text | 1.1% | accent-fill, text | — | --light-border-active --ring-color-active --border-color-active |
| surface-4 | `rgb(13 13 13 / 0.4)` | surface-4 | 1% | bg | — | — |
| text-secondary | `#6e6a69` | text-secondary | 0.8% | text | — | --color-text-secondary --color-warm-gray-light-600 --text-color-secondary |
| black-a40 | `rgb(0 0 0 / 0.4)` | palette | 0.5% | gradient | — | — |
| black-a10 | `rgb(0 0 0 / 0.1)` | palette | 0.4% | accent-fill | — | — |
| black-50 | `#000000` | palette | 0.3% | bg | — | --color-black --color-arena |
| gray-800 | `#c7c6c5` | palette | 0.2% | bg | — | — |
| gray-800-2 | `#d0cdcd` | palette | 0.2% | text | — | --color-gray-300 --color-text-quaternary --text-color-disabled |
| text-tertiary | `#9a9796` | text-tertiary | 0.1% | text, accent-fill | — | --color-text-tertiary --light-text-tertiary --text-color-tertiary |
| gray-900 | `#dad7d3` | palette | 0.1% | bg | — | — |
| gray-900-2 | `#ededed` | palette | 0.1% | bg | — | — |
| gray-800-3 | `#c2bebc` | palette | 0.1% | bg | — | — |
| gray-900-3 | `#dfdcd9` | palette | 0.1% | bg | — | — |
| white-a92 | `rgb(247 245 243 / 0.92)` | palette | 0.1% | gradient, bg | — | — |
| amber-600 | `#ac8778` | palette | 0.1% | bg | — | — |
| gray-500 | `#7c7b75` | palette | 0.1% | bg | — | — |
| white-a78 | `rgb(247 245 243 / 0.78)` | palette | 0.1% | gradient | — | — |
| white-a60 | `rgb(247 245 243 / 0.6)` | palette | 0.1% | gradient | — | — |
| white-a42 | `rgb(247 245 243 / 0.42)` | palette | 0.1% | gradient | — | — |
| white-a26 | `rgb(247 245 243 / 0.26)` | palette | 0.1% | gradient | — | — |
| white-a13 | `rgb(247 245 243 / 0.13)` | palette | 0.1% | gradient | — | --dark-border-primary |
| white-a5 | `rgb(247 245 243 / 0.05)` | palette | 0.1% | gradient | — | — |
| accent | `#a88e6c` | accent | 0.1% | bg, accent-fill | — | — |
| orange-300 | `#82110a` | palette | 0.1% | bg | — | — |
| amber-300 | `#473b32` | palette | 0.1% | bg | — | — |
| gray-100 | `#181818` | palette | 0.1% | bg | — | --dark-hover-tertiary |
| amber-300-2 | `#733f1a` | palette | 0.1% | bg | — | — |
| amber-200 | `#382208` | palette | 0.1% | bg | — | — |
| amber-200-2 | `#443527` | palette | 0.1% | bg | — | — |
| yellow-600 | `#96856a` | palette | 0.1% | bg | — | — |
| yellow-500 | `#776c50` | palette | 0.1% | bg | — | — |
| yellow-400 | `#785f43` | palette | 0.1% | bg | — | — |
| yellow-500-2 | `#7e684a` | palette | 0.1% | bg | — | — |
| gray-900-4 | `#d4d5d0` | palette | 0.1% | bg | — | — |
| yellow-700 | `#bda88c` | palette | 0.1% | bg | — | — |

### Gradients
- `linear-gradient(rgba(0, 0, 0, 0) 0%, rgb(0 0 0 / 0.4) 100%)`
- `linear-gradient(rgba(0, 0, 0, 0) 0%, #f7f5f3 72%)`
- `linear-gradient(#f7f5f3 0%, #f7f5f3 15%, rgb(247 245 243 / 0.92) 26%, rgb(247 245 243 / 0.78) 36%, rgb(247 245 243 / 0.6) 46%, rgb(247 245 243 / 0.42) 55%, rgb(247 245 243 / 0.26) 64%, rgb(247 245 243 / 0.13) 73%, color(srgb 0`
- `linear-gradient(90deg, rgba(0, 0, 0, 0) calc(50% - 54px), #0d0d0d, rgba(0, 0, 0, 0) calc(50% + 54px)), linear-gradient(#9a9796, #9a9796)`
- `linear-gradient(90deg, rgba(0, 0, 0, 0) calc(50% - 28px), #0d0d0d, rgba(0, 0, 0, 0) calc(50% + 28px)), linear-gradient(#9a9796, #9a9796)`

## Typography
| family | share | weights | source | licence | substitute |
|---|---|---|---|---|---|
| cosmosOracle | 99.4% | 400 500 700 | self-hosted | likely commercial — do not copy the font files; license it or use the substitute | Inter |

| style | family | size | weight | line-height | tracking | case | share | responsive | sample |
|---|---|---|---|---|---|---|---|---|---|
| h1 | cosmosOracle | 88px | 700 | 132px (1.5) | -0.05em | uppercase | 0.1% | — | Sequence |
| display | cosmosOracle | 72px | 700 | 72px (1) | 0em | none | 1% | 48→48→72px | Tortoise General Store |
| h2 | cosmosOracle | 48px | 500 | 48px (1) | -0.04em | none | 1% | 32→48→48px | Sequence is read by creatives every week |
| h2-regular | cosmosOracle | 48px | 400 | 48px (1) | 0em | none | 0.1% | — | Adriana Roslin |
| h2-medium | cosmosOracle | 32px | 500 | 35.2px (1.1) | 0em | none | 0.5% | — | This week in Sequence |
| h2-medium-2 | cosmosOracle | 26px | 500 | 29.9px (1.15) | 0em | none | 2.4% | — | Does this make my brain look big? |
| title | cosmosOracle | 20px | 500 | 23px (1.15) | 0em | none | 2.7% | — | Used by the world’s leading creative tea |
| h2-regular-2 | cosmosOracle | 20px | 400 | 23px (1.15) | 0em | none | 2.1% | 16→16→20px | For the thoughtful host |
| body-medium | cosmosOracle | 16px | 500 | 22.4px (1.4) | 0em | none | 17.9% | 48→48→16px | Would you tattoo your hair? |
| body | cosmosOracle | 16px | 400 | 22.4px (1.4) | 0em | none | 65% | — | A castaway in 1866 sewed her own sealski |
| body-medium-2 | cosmosOracle | 15px | 500 | 22px (1.467) | -0.02em | none | 0.7% | — | Sequence |
| small | cosmosOracle | 14px | 500 | 20px (1.429) | -0.021em | none | 1.8% | 20→20→14px | Graphic Design |
| small-regular | cosmosOracle | 14px | 400 | 19.6px (1.4) | 0em | none | 4.1% | — | Sign up to keep exploring similar elemen |

Scale: ratio 1.071 (minor second), base 16px, fit 0.87. Sizes in use: 14, 15, 16, 20, 26, 32, 48, 72, 88.

## Spacing
Grid 4px (94.2% of measured paddings, margins and gaps sit on it; common off-grid values: 3).

| value | share |
|---|---|
| 16px | 44% |
| 4px | 25.4% |
| 12px | 7% |
| 32px | 4.5% |
| 20px | 3.7% |
| 8px | 3.7% |
| 24px | 3.3% |
| 3px | 2.1% |
| 2px | 1.6% |
| 10px | 1.3% |
| 40px | 1.2% |
| 6px | 0.4% |
| 80px | 0.3% |
| 72px | 0.3% |
| 28px | 0.2% |
| 3.5px | 0.2% |

## Radii
| radius | count | on |
|---|---|---|
| 9999px | 470 | small, surface, button, media |
| 4px | 313 | surface, button |
| 3px | 74 | media, surface |
| 12px | 42 | surface, media, button |
| 16px | 32 | surface, button, media |
| 20px | 12 | button |

## Borders
| border | count |
|---|---|
| `1px solid rgb(13 13 13 / 0.12)` | 2772 |
| `4px solid #ffffff` | 72 |
| `1px solid #f7f5f3` | 8 |

## Shadows
| shadow | count | on |
|---|---|---|
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.02) 0px 2px 12px 0px, rgba(0, 0, 0, 0.1) 0px 4px 16px 0px` | 22 | div, a |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 1px 8px 0px` | 20 | div |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 3px 12px 0px` | 15 | button |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(13 13 13 / 0.12) 0px 0px 0px 0.5px, rgba(0, 0, 0, 0) 0px 0px 0px 0px` | 6 | div |
| `rgba(255, 255, 255, 0.7) 0px 1px 1.5px 0px inset, rgba(0, 0, 0, 0.03) 0px -1px 1.5px 0px inset, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px` | 3 | div |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(13 13 13 / 0.12) 0px 0px 0px 0.5px, rgba(0, 0, 0, 0.02) 0px 2px 12px 0px, rgba(0, 0, 0, 0.1) 0px 4px 16px 0px` | 3 | div |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(13 13 13 / 0.12) 0px 0px 0px 0.5px, rgba(0, 0, 0, 0.05) 0px 1px 8px 0px` | 1 | div |

## Backdrop
- `blur(40px)` (×16)
- `blur(8px)` (×8)
- `blur(16px)` (×3)
- `blur(4px)` (×1)
