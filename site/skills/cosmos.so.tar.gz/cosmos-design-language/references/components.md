# Components

Each variant is the clustered style of every element that looked the same across the crawled pages. Classes of the same name are in `assets/tokens.css`. Crops are in `assets/reference/`.

## card (card, ×313)
![card](../assets/reference/card.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#0d0d0d` |
| border | `1px solid rgb(13 13 13 / 0.12)` |
| radius | `4px` |
| font | `400 16px/24px` |
| family | `cosmosOracle` |
| padding | `0px 0px 0px 0px` |
Size: 330px tall, from 248px wide, padding 0px × 0px.

**Hover**
| property | rest | hover |
|---|---|---|

Inside it: div.relative.shrink-0 — opacity 900ms cubic-bezier(0.4, 0, 0.2, 1); div.relative.shrink-0 — filter 900ms cubic-bezier(0.4, 0, 0.2, 1); div.relative.shrink-0 — opacity 900ms cubic-bezier(0.4, 0, 0.2, 1); div.relative.shrink-0 — filter 900ms cubic-bezier(0.4, 0, 0.2, 1); div.relative.shrink-0 — opacity 900ms cubic-bezier(0.4, 0, 0.2, 1); div.relative.shrink-0 — filter 900ms cubic-bezier(0.4, 0, 0.2, 1)

**Focus-visible**: outline `3px none #0d0d0d`, offset 1px

## card-2 (card, ×70)
![card-2](../assets/reference/card-2.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#0d0d0d` |
| border | `1px solid rgb(13 13 13 / 0.12)` |
| radius | `3px` |
| font | `400 16px/24px` |
| family | `cosmosOracle` |
| padding | `0px 0px 0px 0px` |
Size: 347px tall, from 248px wide, padding 0px × 0px.

## card-3 (card, ×60)
![card-3](../assets/reference/card-3.jpg)

| property | value |
|---|---|
| background | `rgb(0 0 0 / 0.05)` |
| color | `#0d0d0d` |
| font | `400 16px/24px` |
| family | `cosmosOracle` |
| padding | `0px 0px 0px 0px` |
Size: 246px tall, from 246px wide, padding 0px × 0px.

## card-4 (card, ×60)
![card-4](../assets/reference/card-4.jpg)

| property | value |
|---|---|
| background | `linear-gradient(rgba(0, 0, 0, 0) 0%, rgb(0 0 0 / 0.4) 100%)` |
| color | `#0d0d0d` |
| font | `400 16px/24px` |
| family | `cosmosOracle` |
| padding | `16px 16px 16px 16px` |
Size: 172px tall, from 246px wide, padding 16px × 16px.

## card-5 (card, ×18)
![card-5](../assets/reference/card-5.jpg)

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#0d0d0d` |
| border | `1px solid rgb(13 13 13 / 0.12)` |
| radius | `16px` |
| shadow | `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 1px 8px 0px` |
| font | `400 16px/24px` |
| family | `cosmosOracle` |
| padding | `0px 0px 0px 0px` |
Size: 272px tall, from 224px wide, padding 0px × 0px.

## card-6 (card, ×18)
![card-6](../assets/reference/card-6.jpg)

| property | value |
|---|---|
| background | `#f2f1f0` |
| color | `#0d0d0d` |
| font | `400 16px/24px` |
| family | `cosmosOracle` |
| padding | `0px 0px 0px 0px` |
| gap | `2px` |
| cursor | `pointer` |
Size: 111px tall, from 222px wide, padding 0px × 0px.

**Hover**
| property | rest | hover |
|---|---|---|

Inside it: a.group/brand.relative 717×72 — color 200ms cubic-bezier(0.4, 0, 0.2, 1); a.group/brand.relative 717×72 — color 200ms cubic-bezier(0.4, 0, 0.2, 1); span.pointer-events-none.block — marginRight 400ms cubic-bezier(0.4, 0, 0.2, 1); span.pointer-events-none.block — width 400ms cubic-bezier(0.4, 0, 0.2, 1); span.pointer-events-none.block — marginRight 400ms cubic-bezier(0.4, 0, 0.2, 1); span.pointer-events-none.block — width 400ms cubic-bezier(0.4, 0, 0.2, 1)

**Focus-visible**: outline `3px none #0d0d0d`, offset 1px

## card-7 (card, ×13)
![card-7](../assets/reference/card-7.jpg)
Examples: “Dr Martens”, “Missoma”, “Ralph Lauren”, “6397”

| property | value |
|---|---|
| background | `transparent` |
| color | `#0d0d0d` |
| radius | `12px` |
| shadow | `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(13 13 13 / 0.12) 0px 0px 0px 0.5px, rgba(0, 0, 0, 0.02) 0px 2px 12px 0px, rgba(0, 0, 0, 0.1) 0px 4px 16px 0px` |
| font | `400 16px/24px` |
| family | `cosmosOracle` |
| padding | `0px 0px 0px 0px` |
| transition | `transform 0.3s cubic-bezier(0, 0, 0.2, 1), translate 0.3s cubic-bezier(0, 0, 0.2, 1), scale 0.3s cubic-bezier(0, 0, 0.2, 1), rotate 0.3s cubic-bezier(0, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 187px tall, from 187px wide, padding 0px × 0px.

**Hover**
| property | rest | hover |
|---|---|---|
| scale | `none` | `1.08` |
Transitions: scale 300ms cubic-bezier(0, 0, 0.2, 1)
Inside it: a.group.grid 671×530 — backgroundColor 300ms cubic-bezier(0.4, 0, 0.2, 1); img.size-full.rounded-xl 281×462 — scale 300ms cubic-bezier(0.4, 0, 0.2, 1); a.group.grid 671×530 — backgroundColor 10ms cubic-bezier(0.4, 0, 0.2, 1); img.size-full.rounded-xl 281×462 — scale 10ms cubic-bezier(0.4, 0, 0.2, 1); a.group/card.flex 439×457 — backgroundColor 300ms cubic-bezier(0.4, 0, 0.2, 1); div.backface-hidden.aspect-square 134×134 — translate 300ms cubic-bezier(0, 0, 0.2, 1)

## card-8 (card, ×11)
![card-8](../assets/reference/card-8.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#0d0d0d` |
| border | `1px solid rgb(13 13 13 / 0.12)` |
| radius | `20px` |
| font | `400 16px/24px` |
| family | `cosmosOracle` |
| padding | `32px 32px 32px 32px` |
| gap | `24px` |
| transition | `color 0.3s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.3s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.3s cubic-bezier(0.4, 0, 0.2, 1), outline-color 0.3s cubic-bezier(0.4, 0, 0.2, 1), text-decoration-color 0.3s cubic-bezier(0.4, 0, 0.2, 1), fill 0.3s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.3s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-from 0.3s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-via 0.3s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-to 0.3s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 538px tall, from 324px wide, padding 32px × 32px.

**Hover**
| property | rest | hover |
|---|---|---|
| backgroundColor | `rgba(0, 0, 0, 0)` | `#fcfbfa` |
Transitions: backgroundColor 300ms cubic-bezier(0.4, 0, 0.2, 1)
Inside it: button.relative.inline-flex 160×56 — backgroundColor 150ms cubic-bezier(0.4, 0, 0.2, 1); img.size-full.rounded-xl 284×474 — scale 300ms cubic-bezier(0.4, 0, 0.2, 1); img.size-full.rounded-xl 256×383 — scale 300ms cubic-bezier(0.4, 0, 0.2, 1)

**Focus-visible**: outline `3px none #0d0d0d`, offset 1px

## button-secondary (button, ×243)
![button-secondary](../assets/reference/button-secondary.jpg)

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#0d0d0d` |
| border | `1px solid rgb(13 13 13 / 0.12)` |
| radius | `9999px` |
| font | `500 14px/20.02px` |
| family | `cosmosOracle` |
| letterSpacing | `-0.28px` |
| padding | `16px 16px 16px 16px` |
| gap | `4px` |
| transition | `all 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 34px tall, from 68px wide, padding 16px × 16px.

**Hover**
| property | rest | hover |
|---|---|---|

Inside it: span.truncate.Yd-VhW_searchPlaceholder “'leather totes'” — backgroundPositionX, backgroundPositionY 3000ms linear

**Focus-visible**: outline `3px none #0d0d0d`, offset 0px

## button-secondary-2 (button, ×70)
![button-secondary-2](../assets/reference/button-secondary-2.jpg)

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#0d0d0d` |
| border | `1px solid transparent` |
| radius | `9999px` |
| font | `500 14px/20.02px` |
| family | `cosmosOracle` |
| letterSpacing | `-0.28px` |
| padding | `16px 16px 16px 16px` |
| gap | `4px` |
| transition | `all 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 34px tall, from 68px wide, padding 16px × 16px.

**Hover**
| property | rest | hover |
|---|---|---|
| backgroundColor | `#ffffff` | `#e8e6e4` |
Transitions: backgroundColor 150ms cubic-bezier(0.4, 0, 0.2, 1)
Inside it: img.transform-gpu.object-cover 365×456 — scale 400ms cubic-bezier(0, 0, 0.2, 1); img.transform-gpu.object-cover 365×456 — scale 60ms cubic-bezier(0, 0, 0.2, 1); div.absolute.inset-0 246×345 — opacity 150ms cubic-bezier(0.4, 0, 0.2, 1); span.truncate.Yd-VhW_searchPlaceholder “'celestial maps'” — backgroundPositionX, backgroundPositionY 3000ms linear

**Focus-visible**: outline `3px none #0d0d0d`, offset 0px

## button-primary (button, ×19)
![button-primary](../assets/reference/button-primary.jpg)

| property | value |
|---|---|
| background | `#0d0d0d` |
| color | `#ffffff` |
| border | `1px solid transparent` |
| radius | `9999px` |
| font | `500 14px/20.02px` |
| family | `cosmosOracle` |
| letterSpacing | `-0.28px` |
| padding | `16px 20px 16px 20px` |
| gap | `4px` |
| transition | `all 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 40px tall, from 190px wide, padding 16px × 20px.

**Hover**
| property | rest | hover |
|---|---|---|
| backgroundColor | `#0d0d0d` | `#232323` |
Transitions: backgroundColor 150ms cubic-bezier(0.4, 0, 0.2, 1)
Inside it: img.size-full.transform-gpu 55×111 — scale 400ms cubic-bezier(0, 0, 0.2, 1); img.size-full.transform-gpu 109×111 — scale 400ms cubic-bezier(0, 0, 0.2, 1); img.size-full.transform-gpu 55×111 — scale 400ms cubic-bezier(0, 0, 0.2, 1)

**Focus-visible**: outline `3px none #ffffff`, offset 0px

## button-secondary-3 (button, ×17)
![button-secondary-3](../assets/reference/button-secondary-3.jpg)

| property | value |
|---|---|
| background | `#f2f1f0` |
| color | `#0d0d0d` |
| border | `1px solid transparent` |
| radius | `9999px` |
| font | `500 14px/20.02px` |
| family | `cosmosOracle` |
| letterSpacing | `-0.28px` |
| padding | `16px 20px 16px 20px` |
| gap | `4px` |
| transition | `all 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 40px tall, from 88px wide, padding 16px × 20px.

**Hover**
| property | rest | hover |
|---|---|---|
| backgroundColor | `#f2f1f0` | `#e8e6e4` |
Transitions: backgroundColor 150ms cubic-bezier(0.4, 0, 0.2, 1)
Inside it: div.absolute.overflow-hidden — opacity 540ms cubic-bezier(0.4, 0, 1, 1); div.absolute.overflow-hidden — filter 540ms cubic-bezier(0.4, 0, 1, 1); div.absolute.overflow-hidden — opacity 540ms cubic-bezier(0.4, 0, 1, 1); div.absolute.overflow-hidden — filter 540ms cubic-bezier(0.4, 0, 1, 1); div.absolute.overflow-hidden — opacity 540ms cubic-bezier(0.4, 0, 1, 1); div.absolute.overflow-hidden — filter 540ms cubic-bezier(0.4, 0, 1, 1)

**Focus-visible**: outline `3px none #0d0d0d`, offset 0px

## button-secondary-4 (button, ×10)
![button-secondary-4](../assets/reference/button-secondary-4.jpg)

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#0d0d0d` |
| border | `1px solid transparent` |
| radius | `9999px` |
| font | `500 15px/18px` |
| family | `cosmosOracle` |
| letterSpacing | `-0.3px` |
| padding | `16px 24px 16px 24px` |
| gap | `4px` |
| transition | `all 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 48px tall, from 86px wide, padding 16px × 24px.

## button-outline (button, ×4)
![button-outline](../assets/reference/button-outline.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#6e6a69` |
| border | `1px solid transparent` |
| radius | `9999px` |
| font | `500 15px/22px` |
| family | `cosmosOracle` |
| letterSpacing | `-0.28125px` |
| padding | `16px 24px 16px 24px` |
| gap | `4px` |
| transition | `all 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 48px tall, from 91px wide, padding 16px × 24px.

**Hover**
| property | rest | hover |
|---|---|---|
| color | `#6e6a69` | `#0d0d0d` |
| outlineColor | `#6e6a69` | `#0d0d0d` |
Transitions: color 150ms cubic-bezier(0.4, 0, 0.2, 1)

**Focus-visible**: outline `3px none #6e6a69`, offset 0px

## link (link, ×27)
![link](../assets/reference/link.jpg)
Examples: “Fashion”, “Interiors”, “Graphic Design”, “Art”

| property | value |
|---|---|
| background | `transparent` |
| color | `#9a9796` |
| radius | `9999px` |
| font | `500 14px/20.02px` |
| family | `cosmosOracle` |
| letterSpacing | `-0.28px` |
| padding | `10px 20px 10px 20px` |
| gap | `4px` |
| cursor | `pointer` |
Size: 40px tall, from 9px wide, padding 10px × 20px.

**Hover**
| property | rest | hover |
|---|---|---|
| color | `#9a9796` | `#0d0d0d` |
| borderTopColor | `#9a9796` | `#0d0d0d` |
| outlineColor | `#9a9796` | `#0d0d0d` |

**Focus-visible**: outline `3px none #9a9796`, offset 1px

## link-2 (link, ×9)
![link-2](../assets/reference/link-2.jpg)
Examples: “Sequence”, “Instagram”, “TikTok”, “X”

| property | value |
|---|---|
| background | `transparent` |
| color | `#0d0d0d` |
| font | `500 20px/23px` |
| family | `cosmosOracle` |
| letterSpacing | `-2%` |
| padding | `0px 0px 0px 0px` |
| cursor | `pointer` |
Size: 23px tall, from 13px wide, padding 0px × 0px.

**Hover**
| property | rest | hover |
|---|---|---|
| color | `#0d0d0d` | `#6e6a69` |
| borderTopColor | `#0d0d0d` | `#6e6a69` |
| outlineColor | `#0d0d0d` | `#6e6a69` |
Inside it: img.size-full.transform-gpu 55×111 — scale 400ms cubic-bezier(0, 0, 0.2, 1); img.size-full.transform-gpu 109×111 — scale 400ms cubic-bezier(0, 0, 0.2, 1); img.size-full.transform-gpu 55×111 — scale 400ms cubic-bezier(0, 0, 0.2, 1)

**Focus-visible**: outline `3px none #0d0d0d`, offset 1px

## link-3 (link, ×7)
![link-3](../assets/reference/link-3.jpg)
Examples: “Instagram”, “TikTok”, “X”, “Substack”

| property | value |
|---|---|
| background | `transparent` |
| color | `#9a9796` |
| font | `500 16px/24px` |
| family | `cosmosOracle` |
| letterSpacing | `-0.32px` |
| padding | `0px 0px 0px 0px` |
| transition | `color 0.15s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), outline-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), text-decoration-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), fill 0.15s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-from 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-via 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-to 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 24px tall, from 10px wide, padding 0px × 0px.

## navbar (navbar, ×6)
![navbar](../assets/reference/navbar.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#0d0d0d` |
| font | `400 16px/24px` |
| family | `cosmosOracle` |
| padding | `24px 32px 24px 32px` |
| gap | `72px` |
Size: 92px tall, from 1398px wide, padding 24px × 32px.

## badge (badge, ×3)
![badge](../assets/reference/badge.jpg)
Examples: “AI”

| property | value |
|---|---|
| background | `rgb(255 255 255 / 0.4)` |
| color | `#ffffff` |
| radius | `9999px` |
| font | `500 12px/14.04px` |
| family | `cosmosOracle` |
| letterSpacing | `-2%` |
| padding | `0px 0px 0px 0px` |
| backdrop | `blur(8px)` |
Size: 32px tall, from 32px wide, padding 0px × 0px.

## input (input, ×2)
![input](../assets/reference/input.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#0d0d0d` |
| font | `400 16px/24px` |
| family | `cosmosOracle` |
| padding | `0px 0px 0px 0px` |
| cursor | `text` |
Size: 1px tall, from 1px wide, padding 0px × 0px.

## input-2 (input, ×2)
![input-2](../assets/reference/input-2.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#0d0d0d` |
| font | `400 14px/20.02px` |
| family | `cosmosOracle` |
| letterSpacing | `-0.28px` |
| padding | `0px 0px 0px 0px` |
| transition | `color 0.15s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), outline-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), text-decoration-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), fill 0.15s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-from 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-via 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-to 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `text` |
Size: 17px tall, from 270px wide, padding 0px × 0px.

**Hover**
| property | rest | hover |
|---|---|---|

Inside it: span.truncate.Yd-VhW_searchPlaceholder “'archival fashion'” — backgroundPositionX, backgroundPositionY 3000ms linear; div.relative.-mr-[0.5px] 457×56 — backgroundColor 150ms cubic-bezier(0.4, 0, 0.2, 1); span.text-pretty.font-normal 189×20 — color 150ms ease

**Focus-visible**: outline `3px none #0d0d0d`, offset 0px

## input-3 (input, ×2)
![input-3](../assets/reference/input-3.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#0d0d0d` |
| font | `500 16px/24px` |
| family | `cosmosOracle` |
| letterSpacing | `-0.32px` |
| padding | `0px 0px 0px 0px` |
| cursor | `text` |
Size: 1px tall, from 1px wide, padding 0px × 0px.

## input-4 (input, ×1)
![input-4](../assets/reference/input-4.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#0d0d0d` |
| font | `400 20px/23px` |
| family | `cosmosOracle` |
| letterSpacing | `-2%` |
| padding | `0px 0px 0px 0px` |
| transition | `color 0.15s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), outline-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), text-decoration-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), fill 0.15s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-from 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-via 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-to 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `text` |
Size: 24px tall, from 476px wide, padding 0px × 0px.

**Focus-visible**: outline `3px none #0d0d0d`, offset 0px

## footer (footer, ×2)
![footer](../assets/reference/footer.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#0d0d0d` |
| font | `400 16px/24px` |
| family | `cosmosOracle` |
| padding | `0px 0px 0px 0px` |
Size: 276px tall, from 526px wide, padding 0px × 0px.

## footer-2 (footer, ×1)
![footer-2](../assets/reference/footer-2.jpg)

| property | value |
|---|---|
| background | `#f7f5f3` |
| color | `#0d0d0d` |
| font | `400 16px/24px` |
| family | `cosmosOracle` |
| padding | `80px 72px 80px 72px` |
Size: 438px tall, from 1430px wide, padding 80px × 72px.

## footer-3 (footer, ×1)
![footer-3](../assets/reference/footer-3.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#0d0d0d` |
| border | `1px solid transparent` |
| font | `400 16px/24px` |
| family | `cosmosOracle` |
| padding | `0px 0px 0px 0px` |
Size: 63px tall, from 1430px wide, padding 0px × 0px.
