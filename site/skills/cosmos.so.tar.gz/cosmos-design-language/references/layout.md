# Layout

## Containers
| viewport | content widths (most used first) | gutter |
|---|---|---|
| desktop | — | — |
| tablet | — | — |
| mobile | 374px, 358px, 366px, 336px | 16px |

## Breakpoints (from the stylesheets)
- min-width 768px (×5)
- min-width 1024px (×3)
- min-width 1280px (×3)
- min-width 640px (×2)
- min-width 1536px (×2)
- max-width 720px (×1)

## Grids
- 5 cols, gap 32px (×19)
- 18 equal flex columns, gap 32px (×11)
- 12 equal flex columns, gap 24px (×4)
- 12 cols, gap 40px (×3)
- 4 cols, gap 24px (×2)
- 3 cols, gap 24px (×2)
- 6 equal flex columns, gap 24px (×1)
- 2 cols, gap 8px (×1)

## Section rhythm
| viewport | section padding-y (common) | median | gap between sections |
|---|---|---|---|
| desktop | 80px, 48px, 124px | 80px | 52px |
| tablet | 80px, 48px, 124px | 80px | 52px |
| mobile | 64px, 124px | 64px | 53px |

## Density
- First screen: 18 words, text covers 9.6% of it.
- Home page is 4.1 screens tall at desktop.
