# Blueprint

Every section of the measured pages, top to bottom. Build the same kinds of sections in the same order for your product. "Made of" is what fills the section; recreate each block in kind (your content, the source's grammar). Crops are in `assets/reference/sections/`.

## home — 3683px, 5 sections, visuals 50%, 60 elements/screen

### 01 · hero
![hero](../assets/reference/sections/home-00.jpg)
- layout: **hero**; 900px tall; visuals cover 100%; 21 painted elements; background #f7f5f3
- heading: “Find your next” — 72px / 700, at x 115, 1200px wide
- made of: **canvas-art** (drawn canvas 1440×900 behind the content (see its behaviour: what it draws and how it moves), at 0/0/1440/900); **form** (signature search/input field: 552×64, radius 9999px, background #ffffff, border 1px rgb(13 13 13 / 0.12), text 20px, with an icon, placeholder “Search” / “Search for” / “bags” (several overlapping texts: an animated placeholder), at 404/504/552/64)
- see each block: [canvas-art](../assets/reference/sections/home-00-canvas-art-0.jpg) · [form](../assets/reference/sections/home-00-form-1.jpg)
- this section's pixels: #f7f6f4 77%, #eae9e7 3% (use these for painted or image art instead of inventing colours)

**Behaviour** — what this section does while you watch it ([filmstrip](../assets/reference/sections/home-behaviour-00.jpg), six moments of a still view):
- A canvas 1440×900 keeps changing on its own (an animated canvas: objects moving, drifting or morphing); recreate the motion, not a frame of it.
- The link travels between 5 positions (up to 540px).
- The text (“bags”) brings its items in one at a time, fading in (4 steps).
- A container brings its items in one at a time, fading in (4 steps).

### 02 · content
![content](../assets/reference/sections/home-01.jpg)
- layout: **stacked**; 567px tall; visuals cover 51%; 29 painted elements
- heading: “Build your world, your way” — 48px / 500, at x 32, 1366px wide
- made of: **video** (video 384×384, at 32/1108/384/384); **video** (video 288×288, at 488/1156/288/288); **video** (video 518×518, at 1189/1041/518/518); **video** (video 384×384, at 1664/1108/384/384); **video** (video 346×346, at 2091/1127/346/346); **image** (117×147, ×2 (carousel/loop), at 919/1259/117/147); **image** (117×147, ×2 (carousel/loop), at 919/1539/117/147)
- see each block: [video](../assets/reference/sections/home-01-video-0.jpg) · [video](../assets/reference/sections/home-01-video-1.jpg) · [video](../assets/reference/sections/home-01-video-2.jpg) · [image](../assets/reference/sections/home-01-image-3.jpg) · [image](../assets/reference/sections/home-01-image-4.jpg)
- video quality: 1280×720, 3.33× its on-screen width; flat illustration (limited palette, soft shading); looping. Match this fidelity and pixel density with your own asset.
- video quality: 960×960, 3.33× its on-screen width; flat illustration (limited palette, soft shading); looping. Match this fidelity and pixel density with your own asset.
- video quality: 1280×720, 2.47× its on-screen width; flat illustration (limited palette, soft shading); looping. Match this fidelity and pixel density with your own asset.
- image quality: 480×600 webp, 4.1× its on-screen width; photographic or 3D render (many smooth tones). Match this fidelity and pixel density with your own asset (a real 3D render or photograph, not a vector drawing).
- video pixels use: #f5f4f2 71%, #bb1306 2%
- video pixels use: #f5f5f3 73%, #e8e7e5 15%
- video pixels use: #f8f8f6 93%
- this section's pixels: #faf9f8 75%, #e9e9e8 3% (use these for painted or image art instead of inventing colours)

**Behaviour** — what this section does while you watch it ([filmstrip](../assets/reference/sections/home-behaviour-01.jpg), six moments of a still view):
- One of 8 is active at a time in a set of 8 images; the others are dimmed (opacity, level 0.14 vs 1); the active one changes every ~24022ms.
- One of 3 is active at a time in the text (“AI”); the others are dimmed (blur, level 0.14 vs 1).
- A span travels between 5 positions (up to 883px).
- An image stack (4 images 117×560) brings its items in one at a time, fading in (3 steps).
- The text (“AI”) brings its items in one at a time, fading in (3 steps).
- A container brings its items in one at a time, fading in (4 steps).
- A span 78×40 repeats every ~2600ms.

### 03 · content
![content](../assets/reference/sections/home-02.jpg)
- layout: **stacked**; 632px tall; visuals cover 30%; 10 painted elements
- heading: “Christofle” — 72px / 700, at x 32, 318px wide
- made of: **avatar** (64px, at 32/2127/64/64); **image** (257×264, at 1141/1803/257/264); **image** (206×560, at 877/1803/206/560); **image** (206×264, at 1167/2099/206/264)
- see each block: [image](../assets/reference/sections/home-02-image-0.jpg) · [image](../assets/reference/sections/home-02-image-1.jpg) · [image](../assets/reference/sections/home-02-image-2.jpg)
- image quality: 800×800, 3.11× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×800, 3.88× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1067, 3.88× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image pixels use: #fbfbfb 56%, #181719 22%, #262526 7%, #373735 2%, #090a0a 2%
- image pixels use: #fefefe 83%, #190304 6%
- image pixels use: #f3f4f6 64%, #eff0f2 9%, #edeef1 5%, #e6e7ea 5%
- this section's pixels: #fefefe 76%, #e8e7e6 7%, #dad9d8 4% (use these for painted or image art instead of inventing colours)

**Behaviour** — what this section does while you watch it ([filmstrip](../assets/reference/sections/home-behaviour-02.jpg), six moments of a still view):
- A span travels between 3 positions (up to 423px).
- An image stack (40 images 206×560) brings its items in one at a time, fading in (4 steps).
- 2× — An image stack (40 images 257×264) brings its items in one at a time, ~2969ms apart, fading in (6 steps).
- The text (“Tortoise General Store”) brings its items in one at a time, ~3024ms apart, fading in (6 steps).
- A container brings its items in one at a time, ~2983ms apart, fading in (4 steps).
- The text (“Sophie Lou Jacobsen Nordic Knots Dr Mart…”) fades out through a gradient mask (linear-gradient(rgba(0, 0, 0, 0) 0px, rgb(0, 0, 0) 0px, rgb(0, 0, 0) 1).

### 04 · content
![content](../assets/reference/sections/home-03.jpg)
- layout: **stacked**; 683px tall; visuals cover 34%; 167 painted elements
- heading: “Find what others are saving” — 48px / 500, at x 32, 340px wide
- made of: **avatar** (64px, at 112/2707/64/64); **avatar** (64px, at 360/2707/64/64); **avatar** (64px, at 608/2707/64/64); **avatar** (64px, at 856/2707/64/64); **avatar** (64px, at 1104/2707/64/64); **avatar** (64px, at 1352/2707/64/64); **avatar** (64px, at 1600/2707/64/64); **avatar** (64px, at 1848/2707/64/64); **avatar** (64px, at 2096/2707/64/64); **avatar** (64px, at 2344/2707/64/64); **avatar** (64px, at 2592/2707/64/64); **avatar** (64px, at 2840/2707/64/64); **avatar** (64px, at 3088/2707/64/64); **avatar** (64px, at 3336/2707/64/64); **avatar** (64px, at 3584/2707/64/64); **avatar** (64px, at 3832/2707/64/64); **avatar** (64px, at 4080/2707/64/64); **avatar** (64px, at 4328/2707/64/64); **logos** (18 marks in a row, at 112/2707/4280/64); **logos** (24 marks in a row, at -332/3040/5055/58); **logos** (24 marks in a row, at -2094/3104/5088/58); **logos** (14 marks in a row, at 49/2779/4406/23)
- this section's pixels: #fefefe 71%, #e8e7e7 4%, #dadad9 3%, #060606 2% (use these for painted or image art instead of inventing colours)

**Behaviour** — what this section does while you watch it ([filmstrip](../assets/reference/sections/home-behaviour-03.jpg), six moments of a still view):
- An image stack (24 images 5184×64) drifts right at ~46px/s, looping (10 copies).
- An image stack (24 images 5184×64) travels between 13 positions (up to 491px).
- A span travels between 3 positions (up to 426px).
- A container brings its items in one at a time, ~3016ms apart, fading in (4 steps).
- A row of 18 avatars fades out through a gradient mask (linear-gradient(rgba(0, 0, 0, 0) 0px, rgb(0, 0, 0) 0px, rgb(0, 0, 0) 1).
- An image stack (48 images 1366×128) fades out through a gradient mask (linear-gradient(rgba(0, 0, 0, 0) 0px, rgb(0, 0, 0) 0px, rgb(0, 0, 0) 1).

### 05 · footer
![footer](../assets/reference/sections/home-04.jpg)
- layout: **stacked**; 438px tall; visuals cover 0%; 19 painted elements; background #f7f5f3
- heading: “Discover what’s next” — 72px / 700, at x 72, 353px wide
- made of: text only (103 characters)
- this section's pixels: #f6f5f3 85%, #e9e8e6 3% (use these for painted or image art instead of inventing colours)

## explore — 4011px, 2 sections, visuals 0%, 34 elements/screen

### 01 · hero + visual
![hero + visual](../assets/reference/sections/explore-00.jpg)
- layout: **hero**; 244px tall; visuals cover 8%; 73 painted elements
- heading: “Sequence” — 32px / 800, at x 123, 184px wide
- made of: **image** (120×151, ×24 (carousel/loop), at 429/219/120/151)
- see each block: [image](../assets/reference/sections/explore-00-image-0.jpg)
- image quality: 400×400, 3.33× its on-screen width; photographic or 3D render (many smooth tones). Match this fidelity and pixel density with your own asset (a real 3D render or photograph, not a vector drawing).
- image pixels use: #dddad3 12%, #eae9e5 9%, #e2ddd6 6%, #d4c9b9 5%, #dbd5c9 5%, #e8e3d8 5%, #f7f4ea 4%, #fbfaf5 4%
- this section's pixels: #fdfdfd 37%, #e8e7e6 4%, #150b08 3%, #0b0a08 3% (use these for painted or image art instead of inventing colours)

### 02 · content
![content](../assets/reference/sections/explore-01.jpg)
- layout: **stacked**; 19307px tall; visuals cover 0%; 79 painted elements
- made of: text only (0 characters)
- this section's pixels: #fcfcfb 14%, #060605 4%, #d7d7d8 3%, #555554 3%, #e9e8e6 3%, #a8a7a7 3% (use these for painted or image art instead of inventing colours)

## sequence — 4163px, 4 sections, visuals 0%, 22 elements/screen

### 01 · hero
![hero](../assets/reference/sections/sequence-00.jpg)
- layout: **hero**; 168px tall; visuals cover 0%; 0 painted elements
- made of: text only (0 characters)
- this section's pixels: #f7f5f3 93% (use these for painted or image art instead of inventing colours)

### 02 · card row
![card row](../assets/reference/sections/sequence-01.jpg)
- layout: **columns**, 3 columns; 3520px tall; visuals cover 0%; 87 painted elements
- heading: “Sequence” — 88px / 700, at x 32, 453px wide
- made of: **cards** (3 × 165×213, at 595/178/675/223)
- this section's pixels: #f7f6f4 53%, #030302 11%, #e9e7e6 3% (use these for painted or image art instead of inventing colours)

### 03 · statement
![statement](../assets/reference/sections/sequence-02.jpg)
- layout: **centered**; 231px tall; visuals cover 0%; 4 painted elements
- heading: “Sequence is read by creatives every week” — 48px / 500, at x 315, 800px wide
- made of: text only (89 characters)
- this section's pixels: #f6f5f3 85% (use these for painted or image art instead of inventing colours)

### 04 · footer
![footer](../assets/reference/sections/sequence-03.jpg)
- layout: **stacked**; 63px tall; visuals cover 0%; 10 painted elements
- made of: text only (53 characters)
- this section's pixels: #f6f5f3 91% (use these for painted or image art instead of inventing colours)

## explore-shop — 28909px, 25 sections, visuals 11%, 42 elements/screen

### 01 · hero + visual
![hero + visual](../assets/reference/sections/explore-shop-00.jpg)
- layout: **hero**; 206px tall; visuals cover 23%; 34 painted elements
- made of: **image** (363×154, ×10 (carousel/loop), at 32/216/363/154)
- see each block: [image](../assets/reference/sections/explore-shop-00-image-0.jpg)
- image quality: 360×95, 0.99× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image pixels use: #3a2a24 18%, #46342b 15%, #4a3b34 11%, #574b45 11%, #54443b 9%, #665b55 6%, #5c524b 4%, #34241e 3%
- this section's pixels: #fefefe 35%, #9a9a99 10%, #8a8986 5%, #392b25 4%, #46352b 4%, #7b7874 3% (use these for painted or image art instead of inventing colours)

**Behaviour** — what this section does while you watch it:
- As you scroll ~0px, in the header appears in the header (1430×900 at y 0). A signature transition: build it, do not leave it static.

### 02 · content
![content](../assets/reference/sections/explore-shop-01.jpg)
- layout: **stacked**; 463px tall; visuals cover 0%; 78 painted elements
- made of: text only (761 characters)
- this section's pixels: #9b9b9b 34%, #fefefe 21%, #898988 7%, #777878 5%, #686869 2%, #dbdcda 2% (use these for painted or image art instead of inventing colours)

### 03 · content
![content](../assets/reference/sections/explore-shop-02.jpg)
- layout: **stacked**; 463px tall; visuals cover 0%; 76 painted elements
- made of: text only (740 characters)
- this section's pixels: #9a9999 33%, #fefefe 22%, #8b8a88 6%, #88837b 4%, #191818 3%, #837d74 3% (use these for painted or image art instead of inventing colours)

### 04 · content
![content](../assets/reference/sections/explore-shop-03.jpg)
- layout: **stacked**; 527px tall; visuals cover 59%; 22 painted elements
- made of: **image** (525×525, at 33/1453/525/525); **image** (246×246, ×3 (carousel/loop), at 592/1453/246/246); **image** (246×246, ×3 (carousel/loop), at 592/1732/246/246)
- see each block: [image](../assets/reference/sections/explore-shop-03-image-0.jpg) · [image](../assets/reference/sections/explore-shop-03-image-1.jpg) · [image](../assets/reference/sections/explore-shop-03-image-2.jpg)
- image quality: 576×576, 1.1× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×800, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1000, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image pixels use: #294658 18%, #999999 12%, #ffffff 8%, #324e5c 7%, #395462 5%, #35515e 5%, #243a48 4%, #455a66 3%
- image pixels use: #ffffff 56%, #0b0b0b 14%, #4b4338 5%, #453d33 2%, #3c342a 2%, #59534b 2%
- image pixels use: #9a9a98 27%, #241c17 18%, #2b2724 7%, #28221d 5%, #feffff 5%, #332c28 4%, #5b5754 4%, #3b3735 4%
- this section's pixels: #999999 16%, #ffffff 12%, #878888 7%, #2a4758 7%, #787878 6%, #686868 4% (use these for painted or image art instead of inventing colours)

### 05 · content
![content](../assets/reference/sections/explore-shop-04.jpg)
- layout: **stacked**; 527px tall; visuals cover 58%; 22 painted elements
- made of: **image** (525×525, at 872/2032/525/525); **image** (246×246, ×3 (carousel/loop), at 33/2032/246/246); **image** (246×246, ×3 (carousel/loop), at 33/2312/246/246)
- see each block: [image](../assets/reference/sections/explore-shop-04-image-0.jpg) · [image](../assets/reference/sections/explore-shop-04-image-1.jpg) · [image](../assets/reference/sections/explore-shop-04-image-2.jpg)
- image quality: 576×576, 1.1× its on-screen width; photographic or 3D render (many smooth tones). Match this fidelity and pixel density with your own asset (a real 3D render or photograph, not a vector drawing).
- image quality: 800×1067, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1067, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image pixels use: #ffffff 21%, #191b14 7%, #25271b 6%, #585857 5%, #282a24 5%, #363629 4%, #676766 4%, #393a34 4%
- image pixels use: #949494 18%, #878988 16%, #767978 15%, #666a69 13%, #7d8581 5%, #5d6562 5%, #555a5a 4%, #7a827e 4%
- image pixels use: #949494 16%, #888887 13%, #787877 13%, #6a6867 10%, #544b47 9%, #4b4644 7%, #5a5755 5%, #191918 4%
- this section's pixels: #fefefe 29%, #969696 9%, #898988 6%, #686967 5%, #787877 5%, #585857 3% (use these for painted or image art instead of inventing colours)

### 06 · content
![content](../assets/reference/sections/explore-shop-05.jpg)
- layout: **stacked**; 463px tall; visuals cover 0%; 76 painted elements
- made of: text only (618 characters)
- this section's pixels: #9a9a9a 29%, #fefefe 15%, #898888 8%, #797877 5%, #686767 4%, #595856 3% (use these for painted or image art instead of inventing colours)

### 07 · content
![content](../assets/reference/sections/explore-shop-06.jpg)
- layout: **stacked**; 463px tall; visuals cover 0%; 81 painted elements
- made of: text only (688 characters)
- this section's pixels: #999898 22%, #fefefe 21%, #8b8988 9%, #7a7977 4%, #454936 3%, #88827b 2% (use these for painted or image art instead of inventing colours)

### 08 · content
![content](../assets/reference/sections/explore-shop-07.jpg)
- layout: **stacked**; 527px tall; visuals cover 58%; 22 painted elements
- made of: **image** (525×525, at 33/3641/525/525); **image** (246×246, ×3 (carousel/loop), at 592/3641/246/246); **image** (246×246, ×3 (carousel/loop), at 592/3921/246/246)
- see each block: [image](../assets/reference/sections/explore-shop-07-image-0.jpg) · [image](../assets/reference/sections/explore-shop-07-image-1.jpg) · [image](../assets/reference/sections/explore-shop-07-image-2.jpg)
- image quality: 576×576, 1.1× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1067, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1067, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image pixels use: #66161c 32%, #ffffff 17%, #989797 6%, #6a2529 5%, #681d22 4%, #74363a 3%, #5c141a 3%, #56565c 3%
- image pixels use: #ffffff 49%, #989796 19%, #888886 11%, #797977 9%, #686b69 2%
- image pixels use: #fdfcfc 79%, #f2f1ee 6%, #f2eeeb 3%, #eae8e7 3%, #d9d7d5 2%
- this section's pixels: #fefefe 25%, #66161c 11%, #989897 11%, #898887 6%, #696765 4%, #797876 4% (use these for painted or image art instead of inventing colours)

### 09 · content
![content](../assets/reference/sections/explore-shop-08.jpg)
- layout: **stacked**; 527px tall; visuals cover 60%; 22 painted elements
- made of: **image** (525×525, at 872/4220/525/525); **image** (246×246, ×3 (carousel/loop), at 33/4220/246/246); **image** (246×246, ×3 (carousel/loop), at 33/4500/246/246)
- see each block: [image](../assets/reference/sections/explore-shop-08-image-0.jpg) · [image](../assets/reference/sections/explore-shop-08-image-1.jpg) · [image](../assets/reference/sections/explore-shop-08-image-2.jpg)
- image quality: 576×576, 1.1× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1067, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1200, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image pixels use: #6a6d64 30%, #9b9b9a 11%, #6e7168 9%, #ffffff 8%, #63665c 6%, #797a75 5%, #72746d 4%, #585a56 4%
- image pixels use: #544839 11%, #8a8984 10%, #7b7974 8%, #83827c 7%, #5c5349 7%, #76736c 6%, #69635b 6%, #6c6964 5%
- image pixels use: #999998 32%, #494745 10%, #5a5755 9%, #6a6765 8%, #3b3836 5%, #7a7775 5%, #8a8886 4%, #514e4b 3%
- this section's pixels: #999998 20%, #ffffff 14%, #6a6c64 13%, #898987 8%, #7a7975 6%, #5a5955 4% (use these for painted or image art instead of inventing colours)

### 10 · content
![content](../assets/reference/sections/explore-shop-09.jpg)
- layout: **stacked**; 463px tall; visuals cover 0%; 82 painted elements
- made of: text only (580 characters)
- this section's pixels: #999999 30%, #fefefe 28%, #8c8b8a 6%, #522e13 2% (use these for painted or image art instead of inventing colours)

### 11 · content
![content](../assets/reference/sections/explore-shop-10.jpg)
- layout: **stacked**; 463px tall; visuals cover 0%; 78 painted elements
- made of: text only (629 characters)
- this section's pixels: #9a9a99 42%, #fefefe 16%, #8b8987 9%, #88837b 3%, #93918e 3% (use these for painted or image art instead of inventing colours)

### 12 · content
![content](../assets/reference/sections/explore-shop-11.jpg)
- layout: **stacked**; 527px tall; visuals cover 59%; 22 painted elements
- made of: **image** (525×525, at 33/5829/525/525); **image** (246×246, ×3 (carousel/loop), at 592/5829/246/246); **image** (246×246, ×3 (carousel/loop), at 592/6109/246/246)
- see each block: [image](../assets/reference/sections/explore-shop-11-image-0.jpg) · [image](../assets/reference/sections/explore-shop-11-image-1.jpg) · [image](../assets/reference/sections/explore-shop-11-image-2.jpg)
- image quality: 576×301, 1.1× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1067, 3.25× its on-screen width; UI or text-heavy graphic. Match this fidelity and pixel density with your own asset.
- image quality: 800×1000, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image pixels use: #757579 28%, #69676a 14%, #ffffff 13%, #9a9a9a 9%, #6d6d72 5%, #595658 4%, #584a46 2%
- image pixels use: #fefefe 48%, #0c0c0c 14%, #e9e9e8 3%, #cac6b6 2%, #dbd9d6 2%
- image pixels use: #9a9a99 22%, #fefefe 11%, #656869 9%, #575865 7%, #55585b 7%, #767879 6%, #494956 5%, #3a3946 4%
- this section's pixels: #fefefe 17%, #767678 13%, #999999 13%, #696869 7%, #888887 6%, #595758 3% (use these for painted or image art instead of inventing colours)

### 13 · content
![content](../assets/reference/sections/explore-shop-12.jpg)
- layout: **stacked**; 527px tall; visuals cover 59%; 22 painted elements
- made of: **image** (525×525, at 872/6409/525/525); **image** (246×246, ×3 (carousel/loop), at 33/6409/246/246); **image** (246×246, ×3 (carousel/loop), at 33/6688/246/246)
- see each block: [image](../assets/reference/sections/explore-shop-12-image-0.jpg) · [image](../assets/reference/sections/explore-shop-12-image-1.jpg) · [image](../assets/reference/sections/explore-shop-12-image-2.jpg)
- image quality: 576×576, 1.1× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1067, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×800, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image pixels use: #ffffff 20%, #1a1714 14%, #0b0c09 9%, #2b2724 8%, #251b17 7%, #17120d 7%, #352b27 6%, #453b38 5%
- image pixels use: #898a88 14%, #767979 10%, #1a2c37 9%, #949492 7%, #66696a 6%, #273a45 5%, #6b7376 5%, #90918f 4%
- image pixels use: #8a8a88 20%, #797876 13%, #696866 12%, #949492 7%, #241c1a 7%, #91918f 5%, #595857 5%, #2a2725 4%
- this section's pixels: #fefefe 30%, #979795 7%, #8a8a89 7%, #191714 5%, #0a0b08 4%, #797977 4% (use these for painted or image art instead of inventing colours)

### 14 · content
![content](../assets/reference/sections/explore-shop-13.jpg)
- layout: **stacked**; 463px tall; visuals cover 0%; 80 painted elements
- made of: text only (724 characters)
- this section's pixels: #9a9a9a 47%, #ffffff 11%, #8b8a87 10%, #797977 3%, #87837c 2% (use these for painted or image art instead of inventing colours)

### 15 · content
![content](../assets/reference/sections/explore-shop-14.jpg)
- layout: **stacked**; 463px tall; visuals cover 0%; 80 painted elements
- made of: text only (684 characters)
- this section's pixels: #fefefe 28%, #9a9a99 28%, #8b8a88 5% (use these for painted or image art instead of inventing colours)

### 16 · content
![content](../assets/reference/sections/explore-shop-15.jpg)
- layout: **stacked**; 527px tall; visuals cover 57%; 22 painted elements
- made of: **image** (525×525, at 33/8018/525/525); **image** (246×246, ×3 (carousel/loop), at 592/8018/246/246); **image** (246×246, ×3 (carousel/loop), at 592/8297/246/246)
- see each block: [image](../assets/reference/sections/explore-shop-15-image-0.jpg) · [image](../assets/reference/sections/explore-shop-15-image-1.jpg) · [image](../assets/reference/sections/explore-shop-15-image-2.jpg)
- image quality: 576×576, 1.1× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1067, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1100, 3.25× its on-screen width; UI or text-heavy graphic. Match this fidelity and pixel density with your own asset.
- image pixels use: #999999 13%, #ffffff 12%, #77797a 8%, #392628 6%, #382b35 5%, #442829 4%, #483637 4%, #3a3743 3%
- image pixels use: #989898 41%, #777777 10%, #898988 10%, #696968 10%, #484847 8%, #585857 8%, #3a3937 5%, #2d2c2a 2%
- image pixels use: #fefefe 82%
- this section's pixels: #989898 20%, #fefefe 17%, #898888 8%, #787878 7%, #696767 4%, #595757 3% (use these for painted or image art instead of inventing colours)

### 17 · content
![content](../assets/reference/sections/explore-shop-16.jpg)
- layout: **stacked**; 527px tall; visuals cover 60%; 22 painted elements
- made of: **image** (525×525, at 872/8597/525/525); **image** (246×246, ×3 (carousel/loop), at 33/8597/246/246); **image** (246×246, ×3 (carousel/loop), at 33/8877/246/246)
- see each block: [image](../assets/reference/sections/explore-shop-16-image-0.jpg) · [image](../assets/reference/sections/explore-shop-16-image-1.jpg) · [image](../assets/reference/sections/explore-shop-16-image-2.jpg)
- image quality: 576×576, 1.1× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×800, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1198, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image pixels use: #9c9b9b 10%, #ffffff 10%, #555854 7%, #2b1a13 6%, #38221a 6%, #321d16 5%, #474a47 4%, #574a44 3%
- image pixels use: #686a68 28%, #575957 18%, #494b4a 17%, #777876 11%, #5b6563 4%, #3b494a 4%, #5a615e 3%, #4a5353 3%
- image pixels use: #989898 29%, #393936 14%, #474746 11%, #595856 9%, #686765 5%, #2b2725 4%, #8b8987 3%, #1b1815 3%
- this section's pixels: #9a9999 16%, #fefefe 14%, #888887 8%, #797878 7%, #686968 5%, #565855 5% (use these for painted or image art instead of inventing colours)

### 18 · content
![content](../assets/reference/sections/explore-shop-17.jpg)
- layout: **stacked**; 463px tall; visuals cover 0%; 94 painted elements
- made of: text only (820 characters)
- this section's pixels: #999999 35%, #fefefe 29%, #8c8b89 8%, #93928d 3% (use these for painted or image art instead of inventing colours)

### 19 · content
![content](../assets/reference/sections/explore-shop-18.jpg)
- layout: **stacked**; 463px tall; visuals cover 0%; 79 painted elements
- made of: text only (683 characters)
- this section's pixels: #999999 45%, #8a8988 12%, #ffffff 11%, #7b7976 4%, #837d78 2%, #696765 2% (use these for painted or image art instead of inventing colours)

### 20 · content
![content](../assets/reference/sections/explore-shop-19.jpg)
- layout: **stacked**; 527px tall; visuals cover 59%; 22 painted elements
- made of: **image** (525×525, at 33/10206/525/525); **image** (246×246, ×3 (carousel/loop), at 592/10206/246/246); **image** (246×246, ×3 (carousel/loop), at 592/10486/246/246)
- see each block: [image](../assets/reference/sections/explore-shop-19-image-0.jpg) · [image](../assets/reference/sections/explore-shop-19-image-1.jpg) · [image](../assets/reference/sections/explore-shop-19-image-2.jpg)
- image quality: 576×205, 1.1× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1200, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1066, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image pixels use: #ffffff 19%, #3a3735 10%, #2b2826 7%, #494439 6%, #4a4745 6%, #342c27 5%, #5a5755 5%, #39332b 5%
- image pixels use: #ffffff 92%
- image pixels use: #ffffff 48%, #141414 22%, #0c0c0c 10%, #272827 6%, #373737 4%, #474848 4%, #565656 3%
- this section's pixels: #ffffff 28%, #898888 8%, #696766 6%, #2b2824 6%, #797876 5%, #969696 5% (use these for painted or image art instead of inventing colours)

### 21 · content
![content](../assets/reference/sections/explore-shop-20.jpg)
- layout: **stacked**; 527px tall; visuals cover 58%; 22 painted elements
- made of: **image** (525×525, at 872/10785/525/525); **image** (246×246, ×3 (carousel/loop), at 33/10785/246/246); **image** (246×246, ×3 (carousel/loop), at 33/11065/246/246)
- see each block: [image](../assets/reference/sections/explore-shop-20-image-0.jpg) · [image](../assets/reference/sections/explore-shop-20-image-1.jpg) · [image](../assets/reference/sections/explore-shop-20-image-2.jpg)
- image quality: 576×199, 1.1× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1067, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 800×1108, 3.25× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image pixels use: #ffffff 15%, #1a140d 12%, #9b9b9b 11%, #1a1713 10%, #231b13 9%, #0c0c09 4%, #29221b 4%, #292825 3%
- image pixels use: #989898 36%, #686968 14%, #777877 12%, #888888 9%, #5a5856 4%, #2b2724 4%, #4a4745 3%, #3a3735 3%
- image pixels use: #888987 21%, #686866 19%, #787877 16%, #5a5856 6%, #939493 5%, #4a4846 4%, #292726 4%, #3a3836 3%
- this section's pixels: #fefefe 20%, #999999 19%, #898988 8%, #787877 5%, #696867 5%, #1a140d 5% (use these for painted or image art instead of inventing colours)

### 22 · content
![content](../assets/reference/sections/explore-shop-21.jpg)
- layout: **stacked**; 463px tall; visuals cover 0%; 76 painted elements
- made of: text only (566 characters)
- this section's pixels: #9b9b9a 29%, #ffffff 12%, #8a8886 5%, #4a423b 4%, #696867 3%, #453d35 3% (use these for painted or image art instead of inventing colours)

### 23 · content
![content](../assets/reference/sections/explore-shop-22.jpg)
- layout: **stacked**; 40px tall; visuals cover 0%; 1 painted elements
- made of: text only (15 characters)
- this section's pixels: #9c9c9c 55%, #ffffff 38%, #8e8e8e 3% (use these for painted or image art instead of inventing colours)

### 24 · content
![content](../assets/reference/sections/explore-shop-23.jpg)
- layout: **stacked**; 62px tall; visuals cover 0%; 10 painted elements
- made of: text only (24 characters)
- this section's pixels: #9a9a99 52%, #ffffff 36%, #94918e 2% (use these for painted or image art instead of inventing colours)

### 25 · content
![content](../assets/reference/sections/explore-shop-24.jpg)
- layout: **stacked**; 16833px tall; visuals cover 0%; 190 painted elements
- made of: text only (1809 characters)
- this section's pixels: #999999 37%, #fefefe 18%, #898989 9%, #797977 4%, #686867 3%, #e9e9e8 2% (use these for painted or image art instead of inventing colours)
