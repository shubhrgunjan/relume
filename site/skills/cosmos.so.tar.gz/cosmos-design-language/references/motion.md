# Motion

## Scroll feel
Native scrolling: one wheel notch moves 100px instantly. Do not add smoothing.

## Tokens
| duration | uses |
|---|---|
| 500ms | 798 |
| 900ms | 612 |
| 250ms | 487 |
| 540ms | 423 |
| 400ms | 260 |
| 150ms | 203 |
| 700ms | 126 |
| 200ms | 94 |
| 300ms | 72 |
| 800ms | 36 |

| curve | uses | kind |
|---|---|---|
| `cubic-bezier(0.4, 0, 0.2, 1)` | 1930 | bezier |
| `ease` | 494 | bezier |
| `cubic-bezier(0.4, 0, 1, 1)` | 423 | bezier |
| `linear(0 0%, 0.0039 1.12%, 0.0151 2.25%, 0.0325 3.37%, 0.0554 4.49%, 0.083 5.62%…` | 184 | spring (CSS linear()) |
| `cubic-bezier(0, 0, 0.2, 1)` | 119 | bezier |
| `cubic-bezier(0.66, 0, 0, 1)` | 36 | bezier |
| `ease-in-out` | 28 | bezier |
| `cubic-bezier(0.22, 1, 0.36, 1)` | 26 | bezier |
| `linear` | 7 | bezier |
| `ease-out` | 5 | bezier |

Spring curves, exact (paste as-is; supported in all evergreen browsers):
```css
linear(0 0%, 0.0039 1.12%, 0.0151 2.25%, 0.0325 3.37%, 0.0554 4.49%, 0.083 5.62%, 0.1145 6.74%, 0.1492 7.87%, 0.1864 8.99%, 0.2257 10.11%, 0.2665 11.24%, 0.3082 12.36%, 0.3505 13.48%, 0.393 14.61%, 0.4353 15.73%, 0.4771 16.85%, 0.5181 17.98%, 0.5582 19.1%, 0.5971 20.22%, 0.6346 21.35%, 0.6707 22.47%, 0.7052 23.6%, 0.738 24.72%, 0.7691 25.84%, 0.7984 26.97%, 0.8259 28.09%, 0.8516 29.21%, 0.8755 30.34%, 0.8977 31.46%, 0.9181 32.58%, 0.9368 33.71%, 0.9538 34.83%, 0.9692 35.96%, 0.9832 37.08%, 0.9956 38.2%, 1.0067 39.33%, 1.0165 40.45%, 1.025 41.57%, 1.0323 42.7%, 1.0386 43.82%, 1.0438 44.94%, 1.0481 46.07%, 1.0516 47.19%, 1.0542 48.31%, 1.0562 49.44%, 1.0575 50.56%, 1.0582 51.69%, 1.0583 52.81%, 1.058 53.93%, 1.0573 55.06%, 1.0562 56.18%, 1.0548 57.3%, 1.0532 58.43%, 1.0513 59.55%, 1.0493 60.67%, 1.0471 61.8%, 1.0448 62.92%, 1.0424 64.04%, 1.0399 65.17%, 1.0375 66.29%, 1.035 67.42%, 1.0325 68.54%, 1.0301 69.66%, 1.0277 70.79%, 1.0254 71.91%, 1.0231 73.03%, 1.021 74.16%, 1.0189 75.28%, 1.0169 76.4%, 1.015 77.53%, 1.0132 78.65%, 1.0115 79.78%, 1.0099 80.9%, 1.0084 82.02%, 1.007 83.15%, 1.0058 84.27%, 1.0046 85.39%, 1.0035 86.52%, 1.0025 87.64%, 1.0017 88.76%, 1.0009 89.89%, 1.0001 91.01%, 0.9995 92.13%, 0.999 93.26%, 0.9985 94.38%, 0.9981 95.51%, 0.9977 96.63%, 0.9974 97.75%, 0.9972 98.88%, 1 100%)
```

Libraries detected: canvas, next, tailwindLike.

## Intro choreography (ms after load)
- 0ms — h1.text-balance.font-bold 1200×160 (intro-width-16)
- 1ms — span.block.whitespace-nowrap “Find your next” 1200×72 (intro-width-17)
- 1ms — span.perspective-midrange.mx-auto 559×88 (intro-width-18)
- 1ms — span.text-balance.font-bold “lamp with character” (intro-width-19)
- 1ms — span.inline-flex.w-13.5 (intro-width-20)
- 1ms — span.block.size-9 (intro-spin-21)
- 1ms — span.block.size-9 (intro-spin-22)
- 1ms — div.flex.w-full 640×178 (intro-width-23)
- 1ms — div.w-full 640×82 (intro-width-24)
- 2ms — span.text-pretty.font-medium “Get the app” 141×22 (intro-width-12)
- 2ms — svg.size-5.shrink-0 20×20 (intro-width-7)
- 2ms — path (intro-width-13)
- 2ms — svg.shrink-0.text-primary 160×160 (intro-width-14)
- 2ms — path (intro-width-8)
- 2ms — path (intro-width-15)
- 177ms — div.relative.-mr-[0.5px] 640×82 (intro-width-25)
- 204ms — div.relative.z-10 1200×514 (intro-scale-9)
- 205ms — div.force-light.pointer-events-auto 176×204 (intro-fade-scale-6)
- 205ms — div.force-light.pointer-events-auto 209×242 (intro-fade-scale-6)
- 626ms — button.@container.group/button 32×32 (intro-fade-3)
- 633ms — span.truncate “lamps” (intro-fade-5)

## Load / intro
Plays once when the page loads. Use `data-intro="<name>"` with motion.css; set `--i` for stagger order.

### intro-fade-1 — ×83
Seen on: header.-mr-(--layout-padding-horizontal).mb-3 1398×48; div.animate-fade-in.motion-reduce:animate-none 1366×3835; div.group/tile.relative 248×347; div.group/tile.relative 248×162
- from `opacity: 0;` to `opacity: 1;`
- 250ms, `ease` — source: css-animation
```css
@keyframes intro-fade-1 { 0%{opacity:0} to{opacity:1} }
```
### intro-fade-blur-2 — ×10
Seen on: div.absolute.overflow-hidden
- from `opacity: 0; filter: blur(15px);` to `opacity: 1; filter: blur(0px);`
- 900ms, `cubic-bezier(0.4, 0, 0.2, 1)`, stagger 180ms between siblings — source: waapi
```css
@keyframes intro-fade-blur-2 {
  from { opacity: 0; filter: blur(15px); }
  to { opacity: 1; filter: blur(0px); }
}
```
### intro-fade-3 — ×4
Seen on: button.@container.group/button 32×32
- from `opacity: 0;` to `opacity: 1;`
- 200ms, `ease-out` — source: waapi
```css
@keyframes intro-fade-3 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-4 — ×4
Seen on: span.block.size-full
- from `opacity: 0;` to `opacity: 1;`
- 500ms, `cubic-bezier(0.22, 1, 0.36, 1)`, stagger 80ms between siblings — source: waapi
```css
@keyframes intro-fade-4 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-5 — ×4
Seen on: span.truncate “lamps”; span.truncate “outfits”
- from `opacity: 0;` to `opacity: 1;`
- 495ms, `ease-in-out` — source: js
```css
@keyframes intro-fade-5 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-scale-6 — ×2
Seen on: div.force-light.pointer-events-auto 176×204; div.force-light.pointer-events-auto 209×242
- from `transform: scale(0.95); opacity: 0;` to `transform: scale(1); opacity: 1;`
- 200ms, `ease` — source: css-animation
```css
@keyframes intro-fade-scale-6 { 0%{opacity:0;transform:scale(.95)} to{opacity:1;transform:scale(1)} }
```
### intro-width-7 — ×2
Seen on: svg.size-5.shrink-0 20×20
- from `width: 0px; height: 0px;` to `width: 20px; height: 20px;`
- 205ms, `cubic-bezier(0.02,1.21,0,0.85)` — source: js
```css
@keyframes intro-width-7 {
  from { width: 0px; height: 0px; }
  to { width: 20px; height: 20px; }
}
```
### intro-width-8 — ×2
Seen on: path
- from `width: 0px; height: 0px;` to `width: 128.8px; height: 128.8px;`
- 207ms, `cubic-bezier(0.04,1.21,0.04,0.85)` — source: js
```css
@keyframes intro-width-8 {
  from { width: 0px; height: 0px; }
  to { width: 128.8px; height: 128.8px; }
}
```
### intro-scale-9 — ×1
Seen on: div.relative.z-10 1200×514
- from `transform: scale(0.95);` to `—`
- 500ms, `ease` — source: css-animation
```css
@keyframes intro-scale-9 { 0%{transform:scale(.95)} }
```
### intro-fade-10 — ×1
Seen on: div.absolute.inset-0 1440×900
- from `opacity: 0;` to `opacity: 1;`
- 1250ms, `ease-out` — source: css-transition
```css
@keyframes intro-fade-10 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-blur-11 — ×1
Seen on: a.backface-hidden.col-start-1
- from `opacity: 0; filter: blur(10px);` to `opacity: 1; filter: blur(0px);`
- 900ms, `linear(0 0%, 0.0039 1.12%, 0.0151 2.25%, 0.0325 3.37%, 0.0554 4.49%, 0…` (bezier fallback `cubic-bezier(0.36,0.85,0.28,1.21)`) — source: waapi
```css
@keyframes intro-fade-blur-11 {
  from { opacity: 0; filter: blur(10px); }
  to { opacity: 1; filter: blur(0px); }
}
```
### intro-width-12 — ×1
Seen on: span.text-pretty.font-medium “Get the app” 141×22
- from `width: 0px; height: 0px;` to `width: 141.5px; height: 22.4px;`
- 207ms, `cubic-bezier(0,1.21,0.03,0.85)` — source: js
```css
@keyframes intro-width-12 {
  from { width: 0px; height: 0px; }
  to { width: 141.5px; height: 22.4px; }
}
```
### intro-width-13 — ×1
Seen on: path
- from `width: 0px; height: 0px;` to `width: 15px; height: 16.7px;`
- 208ms, `cubic-bezier(0.03,1.19,0.03,0.85)` — source: js
```css
@keyframes intro-width-13 {
  from { width: 0px; height: 0px; }
  to { width: 15px; height: 16.7px; }
}
```
### intro-width-14 — ×1
Seen on: svg.shrink-0.text-primary 160×160
- from `width: 0px; height: 0px;` to `width: 160px; height: 160px;`
- 206ms, `cubic-bezier(0,1.2,0,0.85)` — source: js
```css
@keyframes intro-width-14 {
  from { width: 0px; height: 0px; }
  to { width: 160px; height: 160px; }
}
```

## Scroll reveals
Triggered as elements enter the viewport. Use `data-reveal="<name>"`; motion.js observes them at the measured entry point.

### reveal-fade-36 — ×383
Seen on: div.group/tile.relative 248×308; div.group/tile.relative 248×164; div.group/tile.relative 248×346; div.group/tile.relative 248×294
- from `opacity: 0;` to `opacity: 1;`
- 250ms, `ease`, stagger 416ms between siblings, starts at 99% viewport — source: css-animation
```css
[data-reveal="reveal-fade-36"] { opacity: 0; transition: opacity 250ms ease; }
[data-reveal="reveal-fade-36"].is-in { opacity: 1; }
```
### reveal-fade-blur-37 — ×18
Seen on: div.absolute.overflow-hidden; div.relative.shrink-0
- from `opacity: 0; filter: blur(15px);` to `opacity: 1; filter: blur(0px);`
- 900ms, `cubic-bezier(0.4, 0, 0.2, 1)`, stagger 180ms between siblings — source: waapi
```css
[data-reveal="reveal-fade-blur-37"] { opacity: 0; filter: blur(15px); transition: opacity 900ms cubic-bezier(0.4, 0, 0.2, 1),
    filter 900ms cubic-bezier(0.4, 0, 0.2, 1); }
[data-reveal="reveal-fade-blur-37"].is-in { opacity: 1; filter: blur(0px); }
```
### reveal-fade-38 — ×4
Seen on: span.block.size-full
- from `opacity: 0;` to `opacity: 1;`
- 500ms, `cubic-bezier(0.22, 1, 0.36, 1)`, stagger 80ms between siblings — source: waapi
```css
[data-reveal="reveal-fade-38"] { opacity: 0; transition: opacity 500ms cubic-bezier(0.22, 1, 0.36, 1); }
[data-reveal="reveal-fade-38"].is-in { opacity: 1; }
```
### reveal-fade-blur-scale-39 — ×3
Seen on: img.absolute.inset-0 257×264; img.absolute.inset-0 206×560; img.absolute.inset-0 206×264
- from `transform: scale(0.98); filter: blur(12px); opacity: 0;` to `transform: scale(1); filter: none; opacity: 1;`
- 500ms, `cubic-bezier(0.4, 0, 0.2, 1)`, starts at 134% viewport — source: css-transition
```css
[data-reveal="reveal-fade-blur-scale-39"] { transform: scale(0.98); filter: blur(12px); opacity: 0; transition: transform 500ms cubic-bezier(0.4, 0, 0.2, 1),
    filter 500ms cubic-bezier(0.4, 0, 0.2, 1),
    opacity 500ms cubic-bezier(0.4, 0, 0.2, 1); }
[data-reveal="reveal-fade-blur-scale-39"].is-in { transform: scale(1); filter: none; opacity: 1; }
```
### reveal-fade-blur-40 — ×2
Seen on: a.backface-hidden.col-start-1
- from `opacity: 0; filter: blur(10px);` to `opacity: 1; filter: blur(0px);`
- 900ms, `linear(0 0%, 0.0039 1.12%, 0.0151 2.25%, 0.0325 3.37%, 0.0554 4.49%, 0…` (bezier fallback `cubic-bezier(0.36,0.85,0.28,1.21)`) — source: waapi
```css
[data-reveal="reveal-fade-blur-40"] { opacity: 0; filter: blur(10px); transition: opacity 900ms linear(0 0%, 0.0039 1.12%, 0.0151 2.25%, 0.0325 3.37%, 0.0554 4.49%, 0.083 5.62%, 0.1145 6.74%, 0.1492 7.87%, 0.1864 8.99%, 0.2257 10.11%, 0.2665 11.24%, 0.3082 12.36%, 0.3505 13.48%, 0.393 14.61%, 0.4353 15.73%, 0.4771 16.85%, 0.5181 17.98%, 0.5582 19.1%, 0.5971 20.22%, 0.6346 21.35%, 0.6707 22.47%, 0.7052 23.6%, 0.738 24.72%, 0.7691 25.84%, 0.7984 26.97%, 0.8259 28.09%, 0.8516 29.21%, 0.8755 30.34%, 0.8977 31.46%, 0.9181 32.58%, 0.9368 33.71%, 0.9538 34.83%, 0.9692 35.96%, 0.9832 37.08%, 0.9956 38.2%, 1.0067 39.33%, 1.0165 40.45%, 1.025 41.57%, 1.0323 42.7%, 1.0386 43.82%, 1.0438 44.94%, 1.0481 46.07%, 1.0516 47.19%, 1.0542 48.31%, 1.0562 49.44%, 1.0575 50.56%, 1.0582 51.69%, 1.0583 52.81%, 1.058 53.93%, 1.0573 55.06%, 1.0562 56.18%, 1.0548 57.3%, 1.0532 58.43%, 1.0513 59.55%, 1.0493 60.67%, 1.0471 61.8%, 1.0448 62.92%, 1.0424 64.04%, 1.0399 65.17%, 1.0375 66.29%, 1.035 67.42%, 1.0325 68.54%, 1.0301 69.66%, 1.0277 70.79%, 1.0254 71.91%, 1.0231 73.03%, 1.021 74.16%, 1.0189 75.28%, 1.0169 76.4%, 1.015 77.53%, 1.0132 78.65%, 1.0115 79.78%, 1.0099 80.9%, 1.0084 82.02%, 1.007 83.15%, 1.0058 84.27%, 1.0046 85.39%, 1.0035 86.52%, 1.0025 87.64%, 1.0017 88.76%, 1.0009 89.89%, 1.0001 91.01%, 0.9995 92.13%, 0.999 93.26%, 0.9985 94.38%, 0.9981 95.51%, 0.9977 96.63%, 0.9974 97.75%, 0.9972 98.88%, 1 100%),
    filter 900ms linear(0 0%, 0.0039 1.12%, 0.0151 2.25%, 0.0325 3.37%, 0.0554 4.49%, 0.083 5.62%, 0.1145 6.74%, 0.1492 7.87%, 0.1864 8.99%, 0.2257 10.11%, 0.2665 11.24%, 0.3082 12.36%, 0.3505 13.48%, 0.393 14.61%, 0.4353 15.73%, 0.4771 16.85%, 0.5181 17.98%, 0.5582 19.1%, 0.5971 20.22%, 0.6346 21.35%, 0.6707 22.47%, 0.7052 23.6%, 0.738 24.72%, 0.7691 25.84%, 0.7984 26.97%, 0.8259 28.09%, 0.8516 29.21%, 0.8755 30.34%, 0.8977 31.46%, 0.9181 32.58%, 0.9368 33.71%, 0.9538 34.83%, 0.9692 35.96%, 0.9832 37.08%, 0.9956 38.2%, 1.0067 39.33%, 1.0165 40.45%, 1.025 41.57%, 1.0323 42.7%, 1.0386 43.82%, 1.0438 44.94%, 1.0481 46.07%, 1.0516 47.19%, 1.0542 48.31%, 1.0562 49.44%, 1.0575 50.56%, 1.0582 51.69%, 1.0583 52.81%, 1.058 53.93%, 1.0573 55.06%, 1.0562 56.18%, 1.0548 57.3%, 1.0532 58.43%, 1.0513 59.55%, 1.0493 60.67%, 1.0471 61.8%, 1.0448 62.92%, 1.0424 64.04%, 1.0399 65.17%, 1.0375 66.29%, 1.035 67.42%, 1.0325 68.54%, 1.0301 69.66%, 1.0277 70.79%, 1.0254 71.91%, 1.0231 73.03%, 1.021 74.16%, 1.0189 75.28%, 1.0169 76.4%, 1.015 77.53%, 1.0132 78.65%, 1.0115 79.78%, 1.0099 80.9%, 1.0084 82.02%, 1.007 83.15%, 1.0058 84.27%, 1.0046 85.39%, 1.0035 86.52%, 1.0025 87.64%, 1.0017 88.76%, 1.0009 89.89%, 1.0001 91.01%, 0.9995 92.13%, 0.999 93.26%, 0.9985 94.38%, 0.9981 95.51%, 0.9977 96.63%, 0.9974 97.75%, 0.9972 98.88%, 1 100%); }
[data-reveal="reveal-fade-blur-40"].is-in { opacity: 1; filter: blur(0px); }
```
### reveal-fade-41 — ×2
Seen on: span.truncate “art”
- from `opacity: 0;` to `opacity: 1;`
- 531ms, `ease-in-out`, starts at -8% viewport — source: js
```css
[data-reveal="reveal-fade-41"] { opacity: 0; transition: opacity 531ms ease-in-out; }
[data-reveal="reveal-fade-41"].is-in { opacity: 1; }
```
### reveal-fade-42 — ×2
Seen on: span.truncate “chairs”
- from `opacity: 0;` to `opacity: 1;`
- 489ms, `ease-in-out` — source: js
```css
[data-reveal="reveal-fade-42"] { opacity: 0; transition: opacity 489ms ease-in-out; }
[data-reveal="reveal-fade-42"].is-in { opacity: 1; }
```
### reveal-width-43 — ×1
Seen on: img.size-full.object-cover
- from `width: 89.2px; height: 10.2px;` to `width: 68.1px; height: 68.1px;`
- 271ms, `cubic-bezier(0.58,0.16,0.1,0.47)`, starts at -11% viewport — source: js
```css
[data-reveal="reveal-width-43"] { width: 89.2px; height: 10.2px; transition: width 271ms cubic-bezier(0.58,0.16,0.1,0.47),
    height 271ms cubic-bezier(0.58,0.16,0.1,0.47); }
[data-reveal="reveal-width-43"].is-in { width: 68.1px; height: 68.1px; }
```
### reveal-width-44 — ×1
Seen on: img.size-full.object-cover
- from `width: 81.9px; height: 10.2px;` to `width: 68.1px; height: 68.1px;`
- 252ms, `cubic-bezier(0.64,0.15,0.13,0.55)`, starts at -11% viewport — source: js
```css
[data-reveal="reveal-width-44"] { width: 81.9px; height: 10.2px; transition: width 252ms cubic-bezier(0.64,0.15,0.13,0.55),
    height 252ms cubic-bezier(0.64,0.15,0.13,0.55); }
[data-reveal="reveal-width-44"].is-in { width: 68.1px; height: 68.1px; }
```
### reveal-width-45 — ×1
Seen on: img.size-full.object-cover
- from `width: 88.1px; height: 10.2px;` to `width: 68.1px; height: 68.1px;`
- 378ms, `cubic-bezier(0.45,0.82,0.37,1.04)`, starts at 0% viewport — source: js
```css
[data-reveal="reveal-width-45"] { width: 88.1px; height: 10.2px; transition: width 378ms cubic-bezier(0.45,0.82,0.37,1.04),
    height 378ms cubic-bezier(0.45,0.82,0.37,1.04); }
[data-reveal="reveal-width-45"].is-in { width: 68.1px; height: 68.1px; }
```
### reveal-width-46 — ×1
Seen on: img.size-full.object-cover
- from `width: 80.5px; height: 10.2px;` to `width: 68.1px; height: 68.1px;`
- 376ms, `cubic-bezier(0.4,0.75,0.3,1.09)`, starts at 0% viewport — source: js
```css
[data-reveal="reveal-width-46"] { width: 80.5px; height: 10.2px; transition: width 376ms cubic-bezier(0.4,0.75,0.3,1.09),
    height 376ms cubic-bezier(0.4,0.75,0.3,1.09); }
[data-reveal="reveal-width-46"].is-in { width: 68.1px; height: 68.1px; }
```
### reveal-width-47 — ×1
Seen on: img.absolute.inset-0
- from `width: 98.4px; height: 122.6px;` to `width: 115.8px; height: 144.2px;`
- 1649ms, `cubic-bezier(0.21,0.91,0.38,0.97)` — source: js
```css
[data-reveal="reveal-width-47"] { width: 98.4px; height: 122.6px; transition: width 1649ms cubic-bezier(0.21,0.91,0.38,0.97),
    height 1649ms cubic-bezier(0.21,0.91,0.38,0.97); }
[data-reveal="reveal-width-47"].is-in { width: 115.8px; height: 144.2px; }
```
### reveal-width-48 — ×1
Seen on: img.absolute.inset-0
- from `width: 100.6px; height: 123.3px;` to `width: 118.3px; height: 145px;`
- 1949ms, `cubic-bezier(0.17,0.85,0.25,1.01)` — source: js
```css
[data-reveal="reveal-width-48"] { width: 100.6px; height: 123.3px; transition: width 1949ms cubic-bezier(0.17,0.85,0.25,1.01),
    height 1949ms cubic-bezier(0.17,0.85,0.25,1.01); }
[data-reveal="reveal-width-48"].is-in { width: 118.3px; height: 145px; }
```
### reveal-width-49 — ×1
Seen on: img.absolute.inset-0
- from `width: 98.4px; height: 122.6px;` to `width: 115.8px; height: 144.2px;`
- 1811ms, `cubic-bezier(0.17,0.89,0.34,1)` — source: js
```css
[data-reveal="reveal-width-49"] { width: 98.4px; height: 122.6px; transition: width 1811ms cubic-bezier(0.17,0.89,0.34,1),
    height 1811ms cubic-bezier(0.17,0.89,0.34,1); }
[data-reveal="reveal-width-49"].is-in { width: 115.8px; height: 144.2px; }
```

## Scroll-linked
Follows the scroll position continuously (parallax/scrub). Use `data-parallax="<name>"`.

### parallax-height-53 — ×4
Seen on: section 1366×16979; div 1366×16833; div.relative 1366×16833
- from `height: 4132.5px;` to `height: 16978.8px;`
- 3985ms, `linear`, moves 3.782px per px scrolled — source: js
```css
transition: height 3985ms linear;
```
### parallax-height-54 — ×1
Seen on: div.relative 1366×19307
- from `height: 6805px;` to `height: 19307px;`
- 8712ms, `linear`, moves 5.492px per px scrolled — source: js
```css
transition: height 8712ms linear;
```

## Hover
Measured by hovering every distinct interactive element.

### hover-scale-55 — ×48
Seen on: img.size-full.transform-gpu 55×111; img.size-full.transform-gpu 109×111; img.transform-gpu.object-cover 365×456; div.size-full.transform-gpu 120×151
- from `transform: scale(none);` to `transform: scale(1.1);`
- 400ms, `cubic-bezier(0, 0, 0.2, 1)` — source: css-transition
```css
transition: transform 400ms cubic-bezier(0, 0, 0.2, 1);
```
### hover-up-56 — ×36
Seen on: span._O9AMq_dot 6×6
- from `transform: translate(0px, -8.26987px);` to `transform: translate(7.16165px, -4.13462px);`
- 800ms, `cubic-bezier(0.66, 0, 0, 1)` — source: css-animation
```css
transition: transform 800ms cubic-bezier(0.66, 0, 0, 1);
```
### hover-blur-57 — ×33
Seen on: img.absolute.inset-0 257×264; img.absolute.inset-0 252×259; img.absolute.inset-0 206×560; img.absolute.inset-0 202×549
- from `filter: blur(12px);` to `filter: none;`
- 500ms, `cubic-bezier(0.4, 0, 0.2, 1)`, stagger 30ms between siblings — source: css-transition
```css
transition: filter 500ms cubic-bezier(0.4, 0, 0.2, 1);
```
