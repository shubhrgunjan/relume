---
name: www.cosmos.so
colors:
  background: "#ffffff"
  surface: "#f7f5f3"
  border: "rgb(13 13 13 / 0.12)"
  surface-2: "rgb(0 0 0 / 0.05)"
  surface-3: "rgb(0 0 0 / 0.2)"
  text: "#0d0d0d"
  surface-4: "rgb(13 13 13 / 0.4)"
  text-secondary: "#6e6a69"
  black-a40: "rgb(0 0 0 / 0.4)"
  black-a10: "rgb(0 0 0 / 0.1)"
  black-50: "#000000"
  gray-800: "#c7c6c5"
  gray-800-2: "#d0cdcd"
  text-tertiary: "#9a9796"
  gray-900: "#dad7d3"
  gray-900-2: "#ededed"
  gray-800-3: "#c2bebc"
  gray-900-3: "#dfdcd9"
  white-a92: "rgb(247 245 243 / 0.92)"
  amber-600: "#ac8778"
  gray-500: "#7c7b75"
  white-a78: "rgb(247 245 243 / 0.78)"
  white-a60: "rgb(247 245 243 / 0.6)"
  white-a42: "rgb(247 245 243 / 0.42)"
typography:
  h1:
    fontFamily: "cosmosOracle"
    fontSize: 88px
    fontWeight: 700
    lineHeight: 1.5
    letterSpacing: -0.05em
  display:
    fontFamily: "cosmosOracle"
    fontSize: 72px
    fontWeight: 700
    lineHeight: 1
    letterSpacing: 0em
  h2:
    fontFamily: "cosmosOracle"
    fontSize: 48px
    fontWeight: 500
    lineHeight: 1
    letterSpacing: -0.04em
  h2-regular:
    fontFamily: "cosmosOracle"
    fontSize: 48px
    fontWeight: 400
    lineHeight: 1
    letterSpacing: 0em
  h2-medium:
    fontFamily: "cosmosOracle"
    fontSize: 32px
    fontWeight: 500
    lineHeight: 1.1
    letterSpacing: 0em
  h2-medium-2:
    fontFamily: "cosmosOracle"
    fontSize: 26px
    fontWeight: 500
    lineHeight: 1.15
    letterSpacing: 0em
  title:
    fontFamily: "cosmosOracle"
    fontSize: 20px
    fontWeight: 500
    lineHeight: 1.15
    letterSpacing: 0em
  h2-regular-2:
    fontFamily: "cosmosOracle"
    fontSize: 20px
    fontWeight: 400
    lineHeight: 1.15
    letterSpacing: 0em
  body-medium:
    fontFamily: "cosmosOracle"
    fontSize: 16px
    fontWeight: 500
    lineHeight: 1.4
    letterSpacing: 0em
  body:
    fontFamily: "cosmosOracle"
    fontSize: 16px
    fontWeight: 400
    lineHeight: 1.4
    letterSpacing: 0em
  body-medium-2:
    fontFamily: "cosmosOracle"
    fontSize: 15px
    fontWeight: 500
    lineHeight: 1.467
    letterSpacing: -0.02em
  small:
    fontFamily: "cosmosOracle"
    fontSize: 14px
    fontWeight: 500
    lineHeight: 1.429
    letterSpacing: -0.021em
  small-regular:
    fontFamily: "cosmosOracle"
    fontSize: 14px
    fontWeight: 400
    lineHeight: 1.4
    letterSpacing: 0em
rounded:
  full: 9999px
  md: 4px
  lg: 3px
  xl: 12px
  2xl: 16px
  3xl: 20px
spacing:
  "1": 3px
  "2": 4px
  "3": 8px
  "4": 12px
  "5": 16px
  "6": 20px
  "7": 24px
  "8": 32px
components:
  card:
    backgroundColor: "transparent"
    textColor: "#0d0d0d"
    rounded: 4px
    padding: 0px 0px 0px 0px
  card-2:
    backgroundColor: "transparent"
    textColor: "#0d0d0d"
    rounded: 3px
    padding: 0px 0px 0px 0px
  card-3:
    backgroundColor: "rgb(0 0 0 / 0.05)"
    textColor: "#0d0d0d"
    padding: 0px 0px 0px 0px
  card-4:
    backgroundColor: "linear-gradient(rgba(0, 0, 0, 0) 0%, rgb(0 0 0 / 0.4) 100%)"
    textColor: "#0d0d0d"
    padding: 16px 16px 16px 16px
  card-5:
    backgroundColor: "#ffffff"
    textColor: "#0d0d0d"
    rounded: 16px
    padding: 0px 0px 0px 0px
  card-6:
    backgroundColor: "#f2f1f0"
    textColor: "#0d0d0d"
    padding: 0px 0px 0px 0px
---

# www.cosmos.so

## Overview
Light interface, almost entirely neutral — colour is rationed (chromatic share 0.6%). Maximum-contrast text (19.4:1). Headlines 88px / 700, tightly tracked (-0.05em); body 16px at 1.4 leading. Crisp, near-square geometry (4px). Layered shadows carry depth. Translucent, blurred (glass) layers are part of the language. Generous vertical rhythm: sections breathe with ~80px padding on desktop. Entrances run ~372ms, with spring physics (8 spring curves); native scrolling.

## Colors
- **background** `#ffffff` — background
- **surface** `#f7f5f3` — surface
- **border** `rgb(13 13 13 / 0.12)` — border
- **surface-2** `rgb(0 0 0 / 0.05)` — surface-2
- **surface-3** `rgb(0 0 0 / 0.2)` — surface-3
- **text** `#0d0d0d` — text
- **surface-4** `rgb(13 13 13 / 0.4)` — surface-4
- **text-secondary** `#6e6a69` — text-secondary
- **black-a40** `rgb(0 0 0 / 0.4)` — palette
- **black-a10** `rgb(0 0 0 / 0.1)` — palette

## Typography
- cosmosOracle (open substitute: Inter)

## Motion
Durations 500ms, 900ms, 250ms, 540ms, 400ms; curves cubic-bezier(0.4, 0, 0.2, 1), ease, cubic-bezier(0.4, 0, 1, 1).

## Do's and Don'ts
- Use the tokens above only.
- Keep motion within the measured durations and curves.
- Never reuse the source brand’s logo, imagery or copy.
