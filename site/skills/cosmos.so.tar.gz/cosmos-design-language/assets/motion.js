// Motion runtime measured from https://www.cosmos.so by relume. Import once on every page.
// Scroll reveals start when an element's top crosses the measured fraction of the viewport height.
const ENTRY = {"reveal-fade-36":0.99,"reveal-fade-blur-37":0.85,"reveal-fade-38":0.85,"reveal-fade-blur-scale-39":1,"reveal-fade-blur-40":0.85,"reveal-fade-41":0.05,"reveal-fade-42":0.85,"reveal-width-43":0.05,"reveal-width-44":0.05,"reveal-width-45":0.05,"reveal-width-46":0.05,"reveal-width-47":0.85,"reveal-width-48":0.85,"reveal-width-49":0.85,"reveal-width-50":0.85,"reveal-fade-51":0.85,"reveal-fade-up-scale-52":0.85};
const DEFAULT_ENTRY = 0.62;

export function initReveals(root = document) {
  const els = [...root.querySelectorAll('[data-reveal]')];
  const byEntry = new Map();
  for (const el of els) {
    const e = ENTRY[el.dataset.reveal] ?? DEFAULT_ENTRY;
    if (!byEntry.has(e)) byEntry.set(e, []);
    byEntry.get(e).push(el);
  }
  for (const [entry, list] of byEntry) {
    const io = new IntersectionObserver((records) => {
      for (const r of records) if (r.isIntersecting) { r.target.classList.add('is-in'); io.unobserve(r.target); }
    }, { rootMargin: `0px 0px ${-Math.round((1 - entry) * 100)}% 0px` });
    list.forEach((el) => io.observe(el));
  }
}

// Scroll-linked motion: property change per px scrolled, as measured.
const PARALLAX = {"parallax-height-53":3.782,"parallax-height-54":5.492};
export function initParallax() {
  const els = [...document.querySelectorAll('[data-parallax]')];
  const tick = () => { for (const el of els) { const k = PARALLAX[el.dataset.parallax] ?? 0; const r = el.getBoundingClientRect(); el.style.transform = `translate3d(0, ${(r.top + r.height / 2 - innerHeight / 2) * k}px, 0)`; } requestAnimationFrame(tick); };
  requestAnimationFrame(tick);
}


// The source scrolls natively (one wheel notch = 100px, no smoothing). Keep it that way.
export function initSmoothScroll() { return null; }

export function initMotion() {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) { document.querySelectorAll('[data-reveal]').forEach((el) => el.classList.add('is-in')); return; }
  initSmoothScroll();
  initReveals();
  initParallax();
}

if (typeof window !== 'undefined') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initMotion); else initMotion();
}
