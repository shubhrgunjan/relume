---
name: cosmos-design-language
description: "Build UI in the design language measured from www.cosmos.so: Light interface, almost entirely neutral — colour is rationed (chromatic share 0.6%). Use whenever creating or restyling pages, sections or components that should look and move like www.cosmos.so — colours, type, spacing, components and motion come from measurement, not guesswork."
---

# www.cosmos.so design language

Measured from https://www.cosmos.so (4 pages at desktop, tablet, mobile, desktop-dark) on 2026-10-29 by relume. Every value here was read from the live site — computed styles, stylesheets, animations and a frame-by-frame motion recording — so treat them as facts, not suggestions.

## What makes this site feel like itself — build these first
- **The hero**: A drawn canvas fills the background. Its search field is a designed control, not a plain input: 552×64, radius 9999px, background #ffffff, border 1px rgb(13 13 13 / 0.12), text 20px, with an icon, placeholder “Search” / “Search for” / “bags” (several overlapping texts: an animated placeholder) (see home-00-form-1.jpg). A canvas 1440×900 keeps changing on its own (an animated canvas: objects moving, drifting or morphing); recreate the motion, not a frame of it. The link travels between 5 positions (up to 540px). The text (“bags”) brings its items in one at a time, fading in (4 steps).
- **Section 2 (content, “Build your world, your way”)**: One of 8 is active at a time in a set of 8 images; the others are dimmed (opacity, level 0.14 vs 1); the active one changes every ~24022ms. One of 3 is active at a time in the text (“AI”); the others are dimmed (blur, level 0.14 vs 1). An image stack (4 images 117×560) brings its items in one at a time, fading in (3 steps).
- **Section 3 (content, “Christofle”)**: An image stack (40 images 206×560) brings its items in one at a time, fading in (4 steps). 2× — An image stack (40 images 257×264) brings its items in one at a time, ~2969ms apart, fading in (6 steps). The text (“Tortoise General Store”) brings its items in one at a time, ~3024ms apart, fading in (6 steps).
- **Section 4 (content, “Find what others are saving”)**: An image stack (24 images 5184×64) drifts right at ~46px/s, looping (10 copies). An image stack (24 images 5184×64) travels between 13 positions (up to 491px). A container brings its items in one at a time, ~3016ms apart, fading in (4 steps).

Rebuild each of these for your product with the measured timings (`references/blueprint.md`; with the relume MCP, `see_behaviour` shows each section moving). A page with the right colours and fonts but none of these is not this language, and `check_style` scores it low.

## The feel
- Light interface, almost entirely neutral — colour is rationed (chromatic share 0.6%).
- Maximum-contrast text (19.4:1).
- Headlines 88px / 700, tightly tracked (-0.05em); body 16px at 1.4 leading.
- Crisp, near-square geometry (4px).
- Layered shadows carry depth.
- Translucent, blurred (glass) layers are part of the language.
- Generous vertical rhythm: sections breathe with ~80px padding on desktop.
- Entrances run ~372ms, with spring physics (8 spring curves); native scrolling.

## Build to the blueprint first
This language is not only its tokens. Its home page is 4 screens of 5 sections; 50% of it is covered by visuals (1 canvas-art, 1 form, 5 video, 5 image, 19 avatar, 4 logos), at ~60 painted elements per screen. Read `references/blueprint.md` before anything else: it lists every section of the source in order, with a crop, its layout, and what it is made of. A new page must have the same kinds of sections in the same order, filled with the same kinds of things for your product: product UI built in real HTML with the measured UI grammar, illustrations in the source's style, data visualisations, logo rows, testimonial cards. Headings over empty boxes are not this language, and the checker fails them.

## Build the behaviour, not just the picture
Sections on this site move on their own. A static copy of their layout is not this language: recreate each behaviour for your content, with the measured speeds, periods and levels. Each section's full behaviour and a filmstrip are in `references/blueprint.md`; with the relume MCP, `see_behaviour` shows it.

- **hero** (section 1): A canvas 1440×900 keeps changing on its own (an animated canvas: objects moving, drifting or morphing); recreate the motion, not a frame of it. The link travels between 5 positions (up to 540px). The text (“bags”) brings its items in one at a time, fading in (4 steps). A container brings its items in one at a time, fading in (4 steps).
- **content** (section 2): One of 8 is active at a time in a set of 8 images; the others are dimmed (opacity, level 0.14 vs 1); the active one changes every ~24022ms. One of 3 is active at a time in the text (“AI”); the others are dimmed (blur, level 0.14 vs 1). A span travels between 5 positions (up to 883px). An image stack (4 images 117×560) brings its items in one at a time, fading in (3 steps).
- **content** (section 3): A span travels between 3 positions (up to 423px). An image stack (40 images 206×560) brings its items in one at a time, fading in (4 steps). 2× — An image stack (40 images 257×264) brings its items in one at a time, ~2969ms apart, fading in (6 steps). The text (“Tortoise General Store”) brings its items in one at a time, ~3024ms apart, fading in (6 steps).
- **content** (section 4): An image stack (24 images 5184×64) drifts right at ~46px/s, looping (10 copies). An image stack (24 images 5184×64) travels between 13 positions (up to 491px). A span travels between 3 positions (up to 426px). A container brings its items in one at a time, ~3016ms apart, fading in (4 steps).

## Setup
1. Copy `assets/tokens.css` (plain CSS variables, text styles, component classes, `.container` and `.section` with the measured width, gutters and rhythm — use them, don't re-derive) into the project; with Tailwind v4 also import `assets/tailwind.css` after `@import "tailwindcss"`.
2. Add `assets/motion.css` and `assets/motion.js` (scroll reveals, intro choreography, stagger and scroll feel, all with measured timings).
3. Fonts: **cosmosOracle** (use **Inter** unless you hold a licence) for h1, display, h2, h2-regular — `var(--font-sans)`.
   Load the open ones: `<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap" rel="stylesheet">`

## Core tokens
- Background #ffffff, text #0d0d0d / #6e6a69 / #9a9796, accent #a88e6c, surface #f7f5f3, border rgb(13 13 13 / 0.12).
- Type scale ≈1.071 (minor second) from 16px: h1 88/700, display 72/700, h2 48/500, h2-regular 48/400, h2-medium 32/500, h2-medium-2 26/500, title 20/500, h2-regular-2 20/400.
- Radii 9999px, 4px, 3px, 12px, 16px. Spacing grid 4px. Container —px, gutters — / — / 16px (desktop / tablet / mobile).
- Motion: 500ms, 900ms, 250ms, 540ms, 400ms; curves `cubic-bezier(0.4, 0, 0.2, 1)`, `ease`, `cubic-bezier(0.4, 0, 1, 1)` plus 1 spring curve (kept exact as `linear()`). Scroll: native.
- Primary action: #0d0d0d / #ffffff, radius 9999px, 500 14px/20.02px; on hover backgroundColor → #232323.

## Do
- Use only the colour tokens in `assets/tokens.css`; the accent (#a88e6c) covers ≤1% of any screen.
- Set text with the named styles (`.text-body`, `.text-h1` …); never invent sizes between them.
- Space on the 4px grid (16, 4, 12, 32, 20, 8 are the workhorses); sections get ~80px vertical padding on desktop.
- Reuse the measured shadows verbatim; they are layered, not single blurs.
- Floating chrome (nav, popovers) uses the measured backdrop blur over a translucent fill.

## Don't
- Do not use radii outside 9999px, 4px, 3px, 12px, 16px.
- Do not use durations or curves that are not in the motion tokens (500ms, 900ms, 250ms, 540ms, 400ms).
- Do not add smooth-scroll libraries; the source scrolls natively.
- Do not copy the source’s logo, product names, photography, illustrations or copy; describe your own product in this language.

## Motion signature
- **intro-fade-1** (load, ×83): opacity: 0; → opacity: 1; over 250ms `ease`.
- **intro-fade-blur-2** (load, ×10): opacity: 0; filter: blur(15px); → opacity: 1; filter: blur(0px); over 900ms `cubic-bezier(0.4, 0, 0.2, 1)`, stagger 180ms.
- **intro-fade-3** (load, ×4): opacity: 0; → opacity: 1; over 200ms `ease-out`.
- **intro-fade-4** (load, ×4): opacity: 0; → opacity: 1; over 500ms `cubic-bezier(0.22, 1, 0.36, 1)`, stagger 80ms.
- **intro-fade-5** (load, ×4): opacity: 0; → opacity: 1; over 495ms `ease-in-out`.
- **intro-fade-scale-6** (load, ×2): transform: scale(0.95); opacity: 0; → transform: scale(1); opacity: 1; over 200ms `ease`.

## Workflow
1. Read `references/tokens.md` and `references/components.md` before writing UI; open the images in `assets/reference/` to see the look.
2. Build with the component classes and text styles; take motion from `references/motion.md` (exact CSS per pattern).
3. Run `node scripts/lint.mjs <your files…>` and fix every off-system colour, size, radius, duration and curve it reports.
4. If the relume MCP server is connected, call `check_style` with your page's URL: it re-measures your page and compares its DNA (composition, tokens and motion) with this one. Fix what it reports until it passes.

## References
- `references/blueprint.md` — the page, section by section: order, layout, contents, density, crops, and the UI grammar of the product mock-ups.
- `references/tokens.md` — every colour (with dark values and the source’s own variable names), text style (with fluid sizes), spacing, radius, border, shadow, gradient.
- `references/components.md` — buttons, links, inputs, cards, badges, navigation, footer: resting style, hover/focus states and transitions.
- `references/motion.md` — scroll feel, intro choreography, scroll reveals, hover motion, loops; exact CSS.
- `references/layout.md` — containers, gutters, grids, breakpoints, section rhythm, density.
- `assets/DESIGN.md` — the same system in Google's DESIGN.md format, for other tools.
