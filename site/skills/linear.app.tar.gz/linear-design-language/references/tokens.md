# Tokens

## Colour (dark scheme)
Ordered by painted weight (area × use). `aliases` are the source's own custom properties holding the same value.

| token | value | role | share | used for | dark | source aliases |
|---|---|---|---|---|---|---|
| background | `#08090a` | background | 85.9% | bg | — | --color-bg-primary --color-bg-level-0 |
| surface | `#0f1011` | surface | 4.9% | bg | — | --color-bg-level-1 --color-bg-panel |
| accent | `#5e69d1` | accent | 2.3% | accent-fill | — | --sx-n8xqcl --sx-ch85qk --color-brand-bg |
| text | `#f7f8f8` | text | 1.3% | text | — | --color-fg-primary --color-text-primary |
| text-tertiary | `#8a8f98` | text-tertiary | 1.2% | text | — | --color-text-tertiary --color-fg-tertiary |
| border | `rgb(255 255 255 / 0.08)` | border | 0.9% | border | — | --sx-irmyh9 --header-border --color-border-translucent-strong |
| text-secondary | `#d0d6e0` | text-secondary | 0.7% | text, gradient | — | --color-text-secondary --color-fg-secondary |
| white-a4 | `rgb(255 255 255 / 0.04)` | palette | 0.4% | gradient | — | --sx-1urpf9d --color-border-translucent --sx-1n1r1h9 |
| surface-2 | `#ffffff` | surface-2 | 0.3% | accent-fill, bg | — | --color-white --sx-ys2i3t --color-link-hover |
| surface-3 | `#161718` | surface-3 | 0.2% | bg | — | --color-line-tertiary --color-line-tint --color-bg-tint |
| black-a50 | `rgb(8 9 10 / 0.5)` | palette | 0.2% | gradient | — | — |
| black-a80 | `rgb(11 11 11 / 0.8)` | palette | 0.2% | gradient | — | --header-bg |
| white-a40 | `rgb(255 255 255 / 0.4)` | palette | 0.2% | gradient | — | --scrollbar-color-active |
| lime-900 | `#e4f222` | palette | 0.2% | bg | — | — |
| text-quaternary | `#62666d` | text-quaternary | 0.1% | text | — | --color-text-quaternary --color-fg-quaternary |
| violet-500 | `#7170ff` | palette | 0.1% | accent-fill | — | --color-accent |
| indigo-800 | `#b2d5ff` | palette | 0.1% | gradient | — | — |
| violet-900 | `#dfd1ff` | palette | 0.1% | gradient | — | — |
| border-2 | `#23252a` | border-2 | 0.1% | shadow, border | — | --color-border-primary --sx-1gcjx5j |
| green-a7 | `rgb(39 166 68 / 0.07)` | palette | 0.1% | bg | — | — |
| surface-4 | `#e5e5e6` | surface-4 | 0.1% | accent-fill, border | — | --color-button-invert-bg |
| black-50 | `#000000` | palette | 0% | bg, accent-fill | — | --color-black --color-bg-marketing |
| border-3 | `#2e2e32` | border-3 | 0% | bg, border, gradient | — | — |
| gray-200 | `#2a2a2d` | palette | 0% | border, accent-fill | — | --sx-1fphd1n --sx-hfmm6c |
| gray-100 | `#121414` | palette | 0% | accent-fill | — | --color-line-quaternary |

### Gradients
- `radial-gradient(52.53% 57.5% at 50% 100%, rgba(8, 9, 10, 0) 0%, rgba(8, 9, 10, 0.5) 100%), linear-gradient(rgb(8, 9, 10) 10%, rgb(208, 214, 224) 100%)`
- `radial-gradient(circle, rgba(255, 255, 255, 0.04) 0%, rgba(0, 0, 0, 0) 50%)`
- `linear-gradient(rgba(255, 255, 255, 0.02), rgba(255, 255, 255, 0.02)), none`
- `linear-gradient(0deg, rgba(255, 255, 255, 0.4) 0%, rgba(255, 255, 255, 0.4) 100%), linear-gradient(rgb(178, 213, 255) 0%, rgb(223, 209, 255) 100%)`
- `linear-gradient(rgba(11, 11, 11, 0.8) 0%, oklab(0.149576 0.00000680983 0.00000298768 / 0.761905) 100%)`
- `radial-gradient(50% 50%, rgba(255, 255, 255, 0.04) 0%, rgba(255, 255, 255, 0) 90%)`
- `radial-gradient(circle, rgba(255, 255, 255, 0.03) 0%, rgba(0, 0, 0, 0) 50%)`
- `linear-gradient(rgba(255, 255, 255, 0.03), rgba(255, 255, 255, 0.03)), none`

## Typography
| family | share | weights | source | licence | substitute |
|---|---|---|---|---|---|
| Inter Variable | 92.2% | 300 400 500 510 590 | self-hosted | open (Google Fonts) — load it from Google Fonts or self-host | — |
| Berkeley Mono | 7% | 400 | self-hosted | likely commercial — do not copy the font files; license it or use the substitute | JetBrains Mono |

| style | family | size | weight | line-height | tracking | case | share | responsive | sample |
|---|---|---|---|---|---|---|---|---|---|
| h2 | Inter Variable | 72px | 510 | 72px (1) | -0.022em | none | 0.7% | 38→40→72px | Built for the future. Available today. |
| display | Inter Variable | 64px | 510 | 64px (1) | -0.022em | none | 0.5% | 38→56→64px | The product development system for teams |
| h2-medium | Inter Variable | 48px | 510 | 48px (1) | -0.023em | none | 2% | 24→40→48px | Purpose-built for modern teams with AI w |
| title-lg | Inter Variable | 32px | 400 | 36px (1.125) | -0.022em | none | 0.8% | — | You’ll probably build a better product,  |
| h3 | Inter Variable | 24px | 590 | 31.9px (1.329) | -0.012em | none | 0.1% | — | Enterprise |
| title-lg-medium | Inter Variable | 24px | 510 | 31.9px (1.329) | -0.012em | none | 0.7% | — | AI and agent workflows |
| title-lg-regular | Inter Variable | 24px | 400 | 31.9px (1.329) | -0.012em | none | 2.7% | 15→20→24px | Automatically turn conversations and cus |
| h3-semibold | Inter Variable | 20px | 590 | 26.6px (1.33) | -0.01em | none | 0.1% | — | Faster app launch |
| h3-medium | Inter Variable | 20px | 510 | 26.6px (1.33) | -0.01em | none | 6.1% | — | How teams at Oscar left one of the world |
| label | Inter Variable | 16px | 510 | 44px (2.75) | 0em | none | 0.5% | — | Contact sales |
| body-medium | Inter Variable | 15px | 510 | 24px (1.6) | -0.013em | none | 2.9% | — | Context is now the product: Product lead |
| body | Inter Variable | 15px | 400 | 24px (1.6) | -0.013em | none | 30% | — | Loops automate product work by respondin |
| body-light | Inter Variable | 15px | 300 | 20px (1.333) | -0.007em | none | 1.9% | 12→15→15px | Feels like we could render sooner and lo |
| body-medium-2 | Inter Variable | 14px | 510 | 21px (1.5) | -0.014em | none | 4.2% | — | Post mortem on Linear security incident  |
| body-regular | Inter Variable | 14px | 400 | 21px (1.5) | -0.014em | none | 7.1% | 15→15→14px | Render UI before sync when minimum requi |
| mono-sm | Berkeley Mono | 14px | 400 | 24px (1.714) | 0em | none | 6.2% | — | import React from 'react' import { View, |
| small | Inter Variable | 13px | 510 | 19.5px (1.5) | -0.008em | none | 4.2% | — | Reduce unnecessary map re-rendering on h |
| small-medium | Inter Variable | 13px | 500 | 16px (1.231) | 0em | none | 1.5% | — | Create custom roles with scoped access |
| small-regular | Inter Variable | 13px | 400 | 19.5px (1.5) | -0.008em | none | 17.3% | — | what are the three most important custom |
| caption | Inter Variable | 12px | 510 | 16.8px (1.4) | 0em | none | 4.5% | — | Reduce startup delay caused by vehicle s |
| caption-regular | Inter Variable | 12px | 400 | 14px (1.167) | 0em | none | 3.5% | — | created the issue via on behalf of |
| mono-sm-regular | Berkeley Mono | 12px | 400 | 16.8px (1.4) | 0em | uppercase | 0.8% | — | Powering the companies building the futu |
| micro | Inter Variable | 10px | 400 | 14px (1.4) | -0.01em | none | 0.9% | — | Core screens |

Scale: ratio 1.071 (minor second), base 15px, fit 0.87. Sizes in use: 10, 12, 13, 14, 15, 16, 20, 24, 32, 48, 64, 72.

## Spacing
Grid 2px (92.1% of measured paddings, margins and gaps sit on it).

| value | share |
|---|---|
| 32px | 23% |
| 8px | 22.4% |
| 14px | 13.5% |
| 4px | 6.8% |
| 6px | 5.7% |
| 12px | 5% |
| 16px | 3.7% |
| 24px | 2.4% |
| 10px | 2.1% |
| 7px | 1.9% |
| 2px | 1.7% |
| 23px | 1.2% |
| 20px | 0.9% |
| 11px | 0.9% |
| 3px | 0.6% |
| 5px | 0.6% |

## Radii
| radius | count | on |
|---|---|---|
| 9999px | 99 | button, small, media, surface |
| 5px | 26 | media, small |
| 4px | 21 | small, surface |
| 9px | 18 | surface |
| 12px | 17 | surface |
| 8px | 14 | button, surface, small |
| 6px | 10 | surface, media, small |
| 2px | 7 | small |

## Borders
| border | count |
|---|---|
| `1px solid rgb(255 255 255 / 0.08)` | 272 |
| `1px solid rgb(255 255 255 / 0.12)` | 52 |
| `1px solid rgb(255 255 255 / 0.05)` | 49 |
| `1px solid #e5e5e6` | 40 |
| `1px solid #23252a` | 10 |
| `1px solid #2e2e32` | 8 |
| `1px solid #24282c` | 4 |
| `1px solid rgb(255 255 255 / 0.06)` | 4 |

## Shadows
| shadow | count | on |
|---|---|---|
| `rgba(255, 255, 255, 0.03) 0px 0px 0px 1px inset, rgba(255, 255, 255, 0.04) 0px 1px 0px 0px inset, rgba(0, 0, 0, 0.6) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 4px 4px 0px` | 13 | a, button |
| `rgba(0, 0, 0, 0) 0px 8px 2px 0px, rgba(0, 0, 0, 0.01) 0px 5px 2px 0px, rgba(0, 0, 0, 0.04) 0px 3px 2px 0px, rgba(0, 0, 0, 0.07) 0px 1px 1px 0px, rgba(0, 0, 0, 0.08) 0px 0px 1px 0px` | 10 | a |
| `rgba(0, 0, 0, 0.2) 0px 0px 0px 1px` | 8 | div, p |
| `rgba(0, 0, 0, 0.2) 0px 0px 12px 0px inset` | 7 | div |
| `rgba(0, 0, 0, 0.25) 0px 2px 32px 0px` | 5 | div |
| `rgba(255, 255, 255, 0.08) 0px 0px 0px 0.5px inset` | 5 | span |
| `rgba(255, 255, 255, 0.05) 0px 0px 0px 1px inset` | 4 | button, div |
| `rgb(35, 37, 42) 0px 0px 0px 1px inset` | 3 | div |

## Backdrop
- `blur(4px)` (×13)
- `blur(20px)` (×4)
