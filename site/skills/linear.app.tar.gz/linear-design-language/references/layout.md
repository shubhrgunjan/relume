# Layout

## Containers
| viewport | content widths (most used first) | gutter |
|---|---|---|
| desktop | 1310px, 384px, 1344px, 720px | 48px |
| tablet | 744px, 778px, 416px, 780px | 36px |
| mobile | 342px, 358px, 274px, 343px | 24px |

## Breakpoints (from the stylesheets)
- max-width 640px (×262)
- max-width 768px (×134)
- max-width 1024px (×105)
- max-width 1280px (×37)
- max-width 928px (×5)
- min-width 1536px (×4)
- max-width 900px (×4)
- max-width 1120px (×4)

## Grids
- 5 cols, gap normal (×58)
- 12 cols, gap 32px (×16)
- 2 cols, gap 16px (×15)
- 2 cols, gap normal (×14)
- 5 cols, gap 0px (×5)
- 6 cols, gap 0px (×4)
- 4 equal flex columns, gap 12px (×2)
- 4 cols, gap 64px (×2)

## Section rhythm
| viewport | section padding-y (common) | median | gap between sections |
|---|---|---|---|
| desktop | 128px | 128px | 224px |
| tablet | 128px | 128px | 224px |

## Density
- First screen: 165 words, text covers 33.2% of it.
- Home page is 11.1 screens tall at desktop.
