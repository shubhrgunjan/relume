# Blueprint

Every section of the measured pages, top to bottom. Build the same kinds of sections in the same order for your product. "Made of" is what fills the section; recreate each block in kind (your content, the source's grammar). Crops are in `assets/reference/sections/`.

## UI grammar (product mock-ups)
Measured inside 10 product UI panels. Build mock-ups as real HTML with these numbers, never as a picture or an empty box.

| what | measured |
|---|---|
| panel surface | background rgb(9, 10, 11), radius 12px, border 0px rgb(247, 248, 248) |
| label sizes (px, count) | 14 (176), 12 (174), 13 (53), 10 (26), 15 (9), 20 (1) |
| list row heights (px, count) | 24 (31), 28 (15), 40 (11), 42 (4), 44 (3), 36 (3) |
| icon sizes (px, count) | 14 (75), 16 (27), 12 (23), 20 (8) |
| avatar | 14px round |
| chips | 24px tall, radius 4px, 400 12px; e.g. vehicle_state · Opus 5.5 · Performance · iOS · @Linear · isFullySynced |
| sidebar width | — |
| text colours (count) | rgb(98, 102, 109) (90), rgb(138, 143, 152) (87), rgb(226, 228, 231) (81), rgb(208, 214, 224) (74), rgb(247, 156, 224) (41) |
| status colours | #f79ce0, #27a644, #5e6ad2, #4ea7fc, #eb5757, #f34e52, #f0bf00, #fc7840 |

## home — 9960px, 11 sections, visuals 39%, 81 elements/screen

### 01 · hero + product UI
![hero + product UI](../assets/reference/sections/home-00.jpg)
- layout: **hero**; 1024px tall; visuals cover 85%; 168 painted elements
- heading: “The product development” — 64px / 510, at x 48, 770px wide
- made of: **ui-mock** (19 UI labels, 13 icons, ~10 rows, at 959/706/400/520); **ui-mock** (76 UI labels, 38 icons, ~31 rows, at 300/535/1072/704); **ui-mock** (90 UI labels, 55 icons, ~39 rows, at 60/527/1320/720); **image** (1440×804, at 0/491/1440/804)

### 02 · logo strip
![logo strip](../assets/reference/sections/home-01.jpg)
- layout: **stacked**; 40px tall; visuals cover 100%; 7 painted elements
- made of: **logos** (7 marks in a row, at 80/1407/1280/40)

### 03 · statement
![statement](../assets/reference/sections/home-02.jpg)
- layout: **stacked**; 144px tall; visuals cover 0%; 1 painted elements
- heading: “A new species of product tool.” — 48px / 510, at x 78, 618px wide
- made of: text only (30 characters)

### 04 · feature trio with illustrations
![feature trio with illustrations](../assets/reference/sections/home-03.jpg)
- layout: **columns**, 3 columns; 468px tall; visuals cover 40%; 15 painted elements
- made of: **illustration** (svg, 39 shapes, at 144/1939/265/262); **illustration** (svg, 17 shapes, at 567/1929/304/281); **illustration** (svg, 30 shapes, at 1027/1936/272/267)

### 05 · feature: split intro + product UI
![feature: split intro + product UI](../assets/reference/sections/home-04.jpg)
- layout: **split**; 1226px tall; visuals cover 55%; 202 painted elements
- heading: “Intake and integrations” — 48px / 510, at x 78, 540px wide
- made of: **ui-mock** (55 UI labels, 50 icons, ~15 rows, at -63/2935/1460/608); **ui-mock** (55 UI labels, 50 icons, ~15 rows, at -72/2926/1478/626); **avatar** (36px, at 80/3007/36/36); **avatar** (36px, at 80/3091/36/36); **avatar** (36px, at 80/3175/36/36)

### 06 · feature: split intro + product UI
![feature: split intro + product UI](../assets/reference/sections/home-05.jpg)
- layout: **split**; 1229px tall; visuals cover 54%; 100 painted elements
- heading: “Planning and monitoring” — 48px / 510, at x 78, 540px wide
- made of: **ui-mock** (46 UI labels, 19 icons, ~10 rows, at 0/4163/1392/600); **ui-mock** (46 UI labels, 19 icons, ~10 rows, at 0/4154/1392/609); **dataviz** (svg, 441 shapes, 825×400, at 752/4210/825/400)

### 07 · card row
![card row](../assets/reference/sections/home-06.jpg)
- layout: **split**, 2 columns; 1232px tall; visuals cover 0%; 55 painted elements
- heading: “AI and automations” — 48px / 510, at x 78, 540px wide
- made of: **avatar** (16px, at -77/5490/16/16); **avatar** (16px, at 747/5490/16/16); **avatar** (16px, at 1159/5490/16/16); **cards** (2 × 400×560, at 314/5473/400/560); **cards** (2 × 400×560, at 726/5473/400/560)

### 08 · feature: split intro + product UI
![feature: split intro + product UI](../assets/reference/sections/home-07.jpg)
- layout: **split**; 1220px tall; visuals cover 51%; 306 painted elements
- heading: “Build, review, and ship” — 48px / 510, at x 78, 540px wide
- made of: **ui-mock** (62 UI labels, 47 icons, ~18 rows, at 57/6675/1326/560); **ui-mock** (62 UI labels, 47 icons, ~18 rows, at 48/6666/1344/578); **code** (80 mono lines, at 496/6735/560/432); **code** (92 mono lines, at 1056/6735/784/432); **ui-mock** (173 UI labels (panel), at 496/6642/1344/560); **form** (inputs, at 48/6263/1344/1220)

### 09 · content
![content](../assets/reference/sections/home-08.jpg)
- layout: **stacked**; 422px tall; visuals cover 0%; 20 painted elements
- heading: “Changelog” — 48px / 510, at x 78, 228px wide
- made of: text only (1020 characters)

### 10 · testimonials
![testimonials](../assets/reference/sections/home-09.jpg)
- layout: **stacked**; 564px tall; visuals cover 0%; 14 painted elements
- heading: “You’ll probably build a better product, just because of the craft that using Lin” — 32px / 400, at x 92, 532px wide
- made of: **testimonial** (quote card 432×480, rgb(228, 242, 34), at 948/8238/432/480)

### 11 · call to action
![call to action](../assets/reference/sections/home-10.jpg)
- layout: **centered**; 228px tall; visuals cover 0%; 3 painted elements
- heading: “Built for the future. Available today.” — 72px / 510, at x 360, 720px wide
- made of: text only (62 characters)

## customers — 4329px, 6 sections, visuals 18%, 36 elements/screen

### 01 · hero
![hero](../assets/reference/sections/customers-00.jpg)
- layout: **hero**; 213px tall; visuals cover 0%; 9 painted elements
- heading: “Customers” — 48px / 510, at x 78, 230px wide
- made of: text only (62 characters)

### 02 · content
![content](../assets/reference/sections/customers-01.jpg)
- layout: **stacked**; 740px tall; visuals cover 53%; 34 painted elements
- made of: **video** (video 386×218, at 79/284/386/218); **video** (video 386×218, at 975/284/386/218); **video** (video 386×218, at 527/686/386/218); **video** (video 386×218, at 975/686/386/218); **image** (386×218, at 527/284/386/218)

### 03 · statement
![statement](../assets/reference/sections/customers-02.jpg)
- layout: **stacked**; 273px tall; visuals cover 0%; 9 painted elements
- heading: “2.0x” — 48px / 510, at x 529, 223px wide
- made of: text only (120 characters)

### 04 · content
![content](../assets/reference/sections/customers-03.jpg)
- layout: **stacked**; 740px tall; visuals cover 20%; 34 painted elements
- made of: **video** (video 386×218, at 527/1699/386/218); **image** (386×218, at 975/1699/386/218)

### 05 · statement
![statement](../assets/reference/sections/customers-04.jpg)
- layout: **stacked**; 224px tall; visuals cover 0%; 2 painted elements
- heading: “Powering more than 40,000 organizations.” — 48px / 510, at x 78, 1282px wide
- made of: text only (107 characters)

### 06 · content
![content](../assets/reference/sections/customers-05.jpg)
- layout: **stacked**; 896px tall; visuals cover 0%; 85 painted elements
- made of: **avatar** (32px, at 74/2275/32/32); **avatar** (32px, at 74/2331/32/32); **avatar** (32px, at 74/2387/32/32); **avatar** (32px, at 74/2443/32/32); **avatar** (32px, at 74/2499/32/32); **avatar** (32px, at 74/2555/32/32); **avatar** (32px, at 74/2611/32/32); **avatar** (32px, at 74/2667/32/32); **avatar** (32px, at 74/2723/32/32); **avatar** (32px, at 74/2779/32/32); **avatar** (32px, at 74/2835/32/32); **avatar** (32px, at 74/2891/32/32); **avatar** (32px, at 74/2947/32/32); **avatar** (32px, at 74/3003/32/32); **avatar** (32px, at 74/3059/32/32)

## pricing — 6192px, 6 sections, visuals 1%, 59 elements/screen

### 01 · hero
![hero](../assets/reference/sections/pricing-00.jpg)
- layout: **hero**; 984px tall; visuals cover 0%; 72 painted elements
- heading: “Pricing” — 48px / 510, at x 78, 140px wide
- made of: text only (653 characters)

### 02 · logo strip
![logo strip](../assets/reference/sections/pricing-01.jpg)
- layout: **stacked**; 40px tall; visuals cover 100%; 7 painted elements
- made of: **logos** (7 marks in a row, at 80/1056/1280/40)

### 03 · content
![content](../assets/reference/sections/pricing-02.jpg)
- layout: **stacked**; 3404px tall; visuals cover 0%; 312 painted elements
- heading: “Core” — 24px / 510, at x 80, 52px wide
- made of: text only (1102 characters)

### 04 · content
![content](../assets/reference/sections/pricing-03.jpg)
- layout: **stacked**; 114px tall; visuals cover 0%; 6 painted elements
- made of: text only (61 characters)

### 05 · content
![content](../assets/reference/sections/pricing-04.jpg)
- layout: **stacked**; 85px tall; visuals cover 0%; 3 painted elements
- made of: text only (31 characters)

### 06 · call to action
![call to action](../assets/reference/sections/pricing-05.jpg)
- layout: **centered**; 228px tall; visuals cover 0%; 3 painted elements
- heading: “Built for the future. Available today.” — 72px / 510, at x 360, 720px wide
- made of: text only (62 characters)

## now — 6782px, 11 sections, visuals 29%, 26 elements/screen

### 01 · hero
![hero](../assets/reference/sections/now-00.jpg)
- layout: **hero**; 213px tall; visuals cover 0%; 10 painted elements
- heading: “Now” — 48px / 510, at x 78, 95px wide
- made of: text only (74 characters)

### 02 · content
![content](../assets/reference/sections/now-01.jpg)
- layout: **stacked**; 874px tall; visuals cover 49%; 28 painted elements
- made of: **video** (video 384×216, at 976/285/384/216); **image** (384×216, at 80/285/384/216); **image** (384×216, at 528/285/384/216); **image** (307×76, at 1014/355/307/76); **image** (384×216, at 80/766/384/216); **image** (384×216, at 528/766/384/216); **image** (384×216, at 976/766/384/216)

### 03 · content
![content](../assets/reference/sections/now-02.jpg)
- layout: **stacked**; 422px tall; visuals cover 0%; 20 painted elements
- heading: “Changelog” — 48px / 510, at x 80, 228px wide
- made of: text only (1020 characters)

### 04 · content
![content](../assets/reference/sections/now-03.jpg)
- layout: **stacked**; 872px tall; visuals cover 46%; 28 painted elements
- made of: **video** (video 384×216, at 528/1831/384/216); **video** (video 384×216, at 528/2312/384/216); **image** (384×216, at 80/1831/384/216); **image** (307×76, at 566/1901/307/76); **image** (384×216, at 976/1831/384/216); **image** (384×216, at 80/2312/384/216); **image** (307×76, at 566/2382/307/76); **image** (384×216, at 976/2312/384/216)

### 05 · statement
![statement](../assets/reference/sections/now-04.jpg)
- layout: **stacked**; 48px tall; visuals cover 0%; 1 painted elements
- heading: “Press” — 48px / 510, at x 80, 116px wide
- made of: text only (5 characters)

### 06 · content
![content](../assets/reference/sections/now-05.jpg)
- layout: **stacked**; 286px tall; visuals cover 52%; 15 painted elements
- made of: **image** (272×154, at 80/2975/272/154); **image** (272×153, at 416/2975/272/153); **image** (272×154, at 752/2975/272/154); **image** (272×154, at 1088/2975/272/154)

### 07 · content
![content](../assets/reference/sections/now-06.jpg)
- layout: **stacked**; 872px tall; visuals cover 48%; 28 painted elements
- made of: **image** (384×216, at 80/3496/384/216); **image** (384×216, at 528/3496/384/216); **image** (384×216, at 976/3496/384/216); **image** (384×216, at 80/3950/384/216); **image** (384×216, at 528/3950/384/216); **image** (384×216, at 976/3950/384/216)

### 08 · content
![content](../assets/reference/sections/now-07.jpg)
- layout: **stacked**; 48px tall; visuals cover 0%; 0 painted elements
- made of: text only (0 characters)

### 09 · content
![content](../assets/reference/sections/now-08.jpg)
- layout: **stacked**; 840px tall; visuals cover 0%; 59 painted elements
- made of: text only (952 characters)

### 10 · content
![content](../assets/reference/sections/now-09.jpg)
- layout: **stacked**; 40px tall; visuals cover 0%; 1 painted elements
- made of: text only (9 characters)

### 11 · call to action
![call to action](../assets/reference/sections/now-10.jpg)
- layout: **centered**; 228px tall; visuals cover 0%; 3 painted elements
- heading: “Built for the future. Available today.” — 72px / 510, at x 360, 720px wide
- made of: text only (62 characters)
