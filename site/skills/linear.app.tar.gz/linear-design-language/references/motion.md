# Motion

## Scroll feel
Native scrolling: one wheel notch moves 100px instantly. Do not add smoothing.

## Tokens
| duration | uses |
|---|---|
| 420ms | 438 |
| 100ms | 148 |
| 160ms | 52 |
| 150ms | 36 |
| 300ms | 34 |
| 180ms | 34 |
| 120ms | 30 |
| 1000ms | 27 |
| 200ms | 23 |
| 1500ms | 5 |

| curve | uses | kind |
|---|---|---|
| `cubic-bezier(0.25, 0.46, 0.45, 0.94)` | 660 | bezier |
| `ease` | 81 | bezier |
| `cubic-bezier(0.215, 0.61, 0.355, 1)` | 36 | bezier |
| `linear(0 0%, 0.0411 3.45%, 0.1342 6.9%, 0.2478 10.34%, 0.3638 13.79%, 0.4725 17.…` | 28 | spring (CSS linear()) |
| `cubic-bezier(0.25, 0.1, 0.25, 1)` | 27 | bezier |
| `steps(1, end)` | 17 | bezier |
| `linear` | 10 | bezier |
| `ease-out` | 9 | bezier |
| `cubic-bezier(0.455, 0.03, 0.515, 0.955)` | 7 | bezier |
| `cubic-bezier(0.165, 0.84, 0.44, 1)` | 6 | bezier |

Spring curves, exact (paste as-is; supported in all evergreen browsers):
```css
linear(0 0%, 0.0411 3.45%, 0.1342 6.9%, 0.2478 10.34%, 0.3638 13.79%, 0.4725 17.24%, 0.5692 20.69%, 0.6524 24.14%, 0.7222 27.59%, 0.7798 31.03%, 0.8267 34.48%, 0.8644 37.93%, 0.8944 41.38%, 0.9181 44.83%, 0.9367 48.28%, 0.9513 51.72%, 0.9626 55.17%, 0.9714 58.62%, 0.9782 62.07%, 0.9834 65.52%, 0.9874 68.97%, 0.9904 72.41%, 0.9927 75.86%, 0.9945 79.31%, 0.9959 82.76%, 0.9969 86.21%, 0.9976 89.66%, 0.9982 93.1%, 0.9987 96.55%, 1 100%)
```

Libraries detected: next.

## Intro choreography (ms after load)
- -207ms — span.sx-1n2onr6.sx-ln7xf2 “Working…” 60×14 (intro-backgroundpositionx-4)
- -185ms — div 54×28 (intro-fade-10)
- 931ms — div.aFfDra_conversation 386×236 (intro-fade-5)
- 931ms — div.aFfDra_conversation 386×418 (intro-fade-5)
- 1131ms — div 1440×720 (intro-fade-8)
- 1330ms — span.show-mobile.QI8oKG_titleLine “The product” (intro-fade-blur-up-1)
- 1330ms — span.show-mobile.QI8oKG_titleLine “The product” (intro-fade-blur-up-1)
- 1330ms — span.show-mobile.QI8oKG_titleLine “The product” (intro-fade-blur-up-1)
- 1331ms — span.hide-mobile.QI8oKG_titleLine “The product development” 770×124 (intro-fade-blur-up-1)
- 1331ms — span.hide-mobile.QI8oKG_titleLine “The product development” 770×124 (intro-fade-blur-up-1)
- 1331ms — span.hide-mobile.QI8oKG_titleLine “The product development” 770×124 (intro-fade-blur-up-1)
- 1364ms — span.show-mobile.QI8oKG_titleLine “development” (intro-fade-blur-up-1)
- 1364ms — span.show-mobile.QI8oKG_titleLine “development” (intro-fade-blur-up-1)
- 1364ms — span.show-mobile.QI8oKG_titleLine “development” (intro-fade-blur-up-1)
- 1397ms — span.show-mobile.QI8oKG_titleLine “system for teams” (intro-fade-blur-up-1)
- 1397ms — span.show-mobile.QI8oKG_titleLine “system for teams” (intro-fade-blur-up-1)
- 1397ms — span.show-mobile.QI8oKG_titleLine “system for teams” (intro-fade-blur-up-1)
- 1430ms — span.show-mobile.QI8oKG_titleLine “and agents” (intro-fade-blur-up-1)
- 1430ms — span.show-mobile.QI8oKG_titleLine “and agents” (intro-fade-blur-up-1)
- 1430ms — span.show-mobile.QI8oKG_titleLine “and agents” (intro-fade-blur-up-1)
- 1431ms — span.hide-mobile.QI8oKG_titleLine “system for teams and age” 850×124 (intro-fade-blur-up-1)

## Load / intro
Plays once when the page loads. Use `data-intro="<name>"` with motion.css; set `--i` for stagger order.

### intro-fade-blur-up-1 — ×9
Seen on: span.show-mobile.QI8oKG_titleLine “The product”; span.show-mobile.QI8oKG_titleLine “development”; span.show-mobile.QI8oKG_titleLine “system for teams”; span.show-mobile.QI8oKG_titleLine “and agents”
- from `transform: translateY(20%); opacity: 0; filter: blur(10px);` to `transform: translateY(0%); opacity: 1; filter: blur(0px);`
- 1000ms, `cubic-bezier(0.25, 0.1, 0.25, 1)`, delay 400ms, stagger 34ms between siblings — source: waapi
```css
@keyframes intro-fade-blur-up-1 {
  from { transform: translateY(20%); opacity: 0; filter: blur(10px); }
  to { transform: translateY(0%); opacity: 1; filter: blur(0px); }
}
```
### intro-fade-2 — ×5
Seen on: div 1416×768; div.hide-laptop; div.hide-laptop 1440×804; nav.Mmx1Wq_sidebar 232×704
- from `opacity: 0;` to `opacity: 1;`
- 1500ms, `cubic-bezier(0.455, 0.03, 0.515, 0.955)`, delay 1300ms — source: waapi
```css
@keyframes intro-fade-2 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-blur-3 — ×4
Seen on: div.q1lnWq_message 386×88; p.q1lnWq_thinking; div 386×32; div 386×52
- from `opacity: 0; filter: blur(2px);` to `opacity: 1; filter: blur(0px);`
- 300ms, `linear(0 0%, 0.0411 3.45%, 0.1342 6.9%, 0.2478 10.34%, 0.3638 13.79%, …` (bezier fallback `cubic-bezier(0.29,0.81,0.26,1)`) — source: waapi
```css
@keyframes intro-fade-blur-3 {
  from { opacity: 0; filter: blur(2px); }
  to { opacity: 1; filter: blur(0px); }
}
```
### intro-backgroundpositionx-4 — ×3
Seen on: span.sx-1n2onr6.sx-ln7xf2 “Working…” 60×14
- from `background-position-x: -8px, 0px; background-position-y: 50%, 50%;` to `background-position-x: 112px, 0px; background-position-y: 50%, 50%;`
- 2000ms, `linear` — source: css-animation
```css
@keyframes intro-backgroundpositionx-4 { 0%{background-position:calc(-1 * var(--badge-label-offset)) 50%, 0 50%} to{background-position:calc(120px - var(--badge-label-offset)) 50%, 0 50%} }
```
### intro-fade-5 — ×2
Seen on: div.aFfDra_conversation 386×236; div.aFfDra_conversation 386×418
- from `opacity: 0;` to `opacity: 1;`
- 350ms, `cubic-bezier(0.16, 1, 0.3, 1)` — source: waapi
```css
@keyframes intro-fade-5 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-6 — ×1
Seen on: div 1320×720
- from `opacity: 0;` to `opacity: 1;`
- 500ms, `cubic-bezier(0.455, 0.03, 0.515, 0.955)`, delay 1300ms — source: waapi
```css
@keyframes intro-fade-6 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-7 — ×1
Seen on: div
- from `opacity: 0;` to `opacity: 1;`
- 1300ms, `ease-out`, delay 1400ms — source: waapi
```css
@keyframes intro-fade-7 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-8 — ×1
Seen on: div 1440×720
- from `opacity: 0;` to `opacity: 1;`
- 500ms, `ease-out`, delay 200ms — source: waapi
```css
@keyframes intro-fade-8 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-9 — ×1
Seen on: div.KFZpfa_chatBox 400×520
- from `opacity: 0;` to `opacity: 1;`
- 200ms, `cubic-bezier(0.455, 0.03, 0.515, 0.955)` — source: waapi
```css
@keyframes intro-fade-9 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-10 — ×1
Seen on: div 54×28
- from `opacity: 0;` to `opacity: 1;`
- 200ms, `ease-out` — source: waapi
```css
@keyframes intro-fade-10 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```

## Scroll reveals
Triggered as elements enter the viewport. Use `data-reveal="<name>"`; motion.js observes them at the measured entry point.

### reveal-fade-scale-11 — ×438
Seen on: circle.fFDhtq_dot
- from `transform: scale(0.4); opacity: 0;` to `transform: scale(1); opacity: 1;`
- 420ms, `cubic-bezier(0.25, 0.46, 0.45, 0.94)` — source: css-animation
```css
[data-reveal="reveal-fade-scale-11"] { transform: scale(0.4); opacity: 0; transition: transform 420ms cubic-bezier(0.25, 0.46, 0.45, 0.94),
    opacity 420ms cubic-bezier(0.25, 0.46, 0.45, 0.94); }
[data-reveal="reveal-fade-scale-11"].is-in { transform: scale(1); opacity: 1; }
```
### reveal-fade-blur-12 — ×10
Seen on: div 386×83; p.q1lnWq_thinking; div 386×32; div 386×54
- from `opacity: 0; filter: blur(2px);` to `opacity: 1; filter: blur(0px);`
- 300ms, `linear(0 0%, 0.0411 3.45%, 0.1342 6.9%, 0.2478 10.34%, 0.3638 13.79%, …` (bezier fallback `cubic-bezier(0.29,0.81,0.26,1)`), stagger 239ms between siblings, starts at 59% viewport — source: waapi
```css
[data-reveal="reveal-fade-blur-12"] { opacity: 0; filter: blur(2px); transition: opacity 300ms linear(0 0%, 0.0411 3.45%, 0.1342 6.9%, 0.2478 10.34%, 0.3638 13.79%, 0.4725 17.24%, 0.5692 20.69%, 0.6524 24.14%, 0.7222 27.59%, 0.7798 31.03%, 0.8267 34.48%, 0.8644 37.93%, 0.8944 41.38%, 0.9181 44.83%, 0.9367 48.28%, 0.9513 51.72%, 0.9626 55.17%, 0.9714 58.62%, 0.9782 62.07%, 0.9834 65.52%, 0.9874 68.97%, 0.9904 72.41%, 0.9927 75.86%, 0.9945 79.31%, 0.9959 82.76%, 0.9969 86.21%, 0.9976 89.66%, 0.9982 93.1%, 0.9987 96.55%, 1 100%),
    filter 300ms linear(0 0%, 0.0411 3.45%, 0.1342 6.9%, 0.2478 10.34%, 0.3638 13.79%, 0.4725 17.24%, 0.5692 20.69%, 0.6524 24.14%, 0.7222 27.59%, 0.7798 31.03%, 0.8267 34.48%, 0.8644 37.93%, 0.8944 41.38%, 0.9181 44.83%, 0.9367 48.28%, 0.9513 51.72%, 0.9626 55.17%, 0.9714 58.62%, 0.9782 62.07%, 0.9834 65.52%, 0.9874 68.97%, 0.9904 72.41%, 0.9927 75.86%, 0.9945 79.31%, 0.9959 82.76%, 0.9969 86.21%, 0.9976 89.66%, 0.9982 93.1%, 0.9987 96.55%, 1 100%); }
[data-reveal="reveal-fade-blur-12"].is-in { opacity: 1; filter: blur(0px); }
```
### reveal-fade-13 — ×4
Seen on: div.q1lnWq_turn 386×221; div.q1lnWq_turn 386×148; div.q1lnWq_turn 386×330; div.q1lnWq_turn 386×144
- from `opacity: 0;` to `opacity: 1;`
- 300ms, `ease-out` — source: waapi
```css
[data-reveal="reveal-fade-13"] { opacity: 0; transition: opacity 300ms ease-out; }
[data-reveal="reveal-fade-13"].is-in { opacity: 1; }
```
### reveal-fade-14 — ×1
Seen on: div.qM9FAa_sendButtonGroup 65×28
- from `opacity: 0.2;` to `opacity: 1;`
- 800ms, `cubic-bezier(0.22, 1, 0.36, 1)`, starts at 89% viewport — source: waapi
```css
[data-reveal="reveal-fade-14"] { opacity: 0.2; transition: opacity 800ms cubic-bezier(0.22, 1, 0.36, 1); }
[data-reveal="reveal-fade-14"].is-in { opacity: 1; }
```
### reveal-tint-15 — ×1
Seen on: div.PDOlRq_sticky 1344×56
- from `backdrop-filter: blur(0px); background-color: rgba(0, 0, 0, 0); border-bottom-color: rgba(0, 0, 0, 0);` to `backdrop-filter: blur(20px); background-color: rgba(11, 11, 11, 0.8); border-bottom-color: rgb(32, 33, 34);`
- 120ms, `cubic-bezier(0.25, 0.46, 0.45, 0.94)` — source: css-transition
```css
[data-reveal="reveal-tint-15"] { backdrop-filter: blur(0px); background-color: rgba(0, 0, 0, 0); border-bottom-color: rgba(0, 0, 0, 0); transition: backdrop-filter 120ms cubic-bezier(0.25, 0.46, 0.45, 0.94),
    background-color 120ms cubic-bezier(0.25, 0.46, 0.45, 0.94),
    border-bottom-color 120ms cubic-bezier(0.25, 0.46, 0.45, 0.94); }
[data-reveal="reveal-tint-15"].is-in { backdrop-filter: blur(20px); background-color: rgba(11, 11, 11, 0.8); border-bottom-color: rgb(32, 33, 34); }
```

## Hover
Measured by hovering every distinct interactive element.

### hover-tint-16 — ×32
Seen on: button.TZTsQG_anchor.TZTsQG_trigger “Product” 73×32; a.TZTsQG_anchor.I_mUeq_root “Customers” 92×32; button.TZTsQG_anchor.TZTsQG_trigger “Resources” 91×32; a.TZTsQG_anchor.I_mUeq_root “Pricing” 67×32
- from `background-color: rgba(0, 0, 0, 0); color: rgb(138, 143, 152);` to `background-color: rgba(255, 255, 255, 0.08); color: rgb(247, 248, 248);`
- 100ms, `cubic-bezier(0.25, 0.46, 0.45, 0.94)`, stagger 244ms between siblings — source: css-transition
```css
transition: background-color 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94),
    color 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94);
```
### hover-tint-17 — ×20
Seen on: a.S36ykG_root.S36ykG_variant-invert “Sign up” 72×32; button.Mmx1Wq_switchWorkspaceButton 100×28; button._1uFtza_navButton 30×28; button._1uFtza_pillButton 28×28
- from `background-color: rgb(229, 229, 230);` to `background-color: rgb(255, 255, 255);`
- 160ms, `cubic-bezier(0.25, 0.46, 0.45, 0.94)` — source: css-transition
```css
transition: background-color 160ms cubic-bezier(0.25, 0.46, 0.45, 0.94);
```
### hover-fade-out-scale-18 — ×14
Seen on: nav.Fzcv4W_hideScrollbars
- from `transform: scale(1); opacity: 1;` to `transform: scale(0.98); opacity: 0;`
- 180ms, `ease`, stagger 326ms between siblings — source: css-animation
```css
transition: transform 180ms ease,
    opacity 180ms ease;
```
### hover-tint-19 — ×10
Seen on: a.Jbvjba_tab.I_mUeq_root 35×25; a.Jmh1Wq_sectionLink.I_mUeq_root “Intake” 37×28; a.I_mUeq_root.I_mUeq_variant-dimmed “View docs” 84×17; a.Jmh1Wq_logoWrapper.I_mUeq_root 20×20
- from `color: rgb(138, 143, 152);` to `color: rgb(247, 248, 248);`
- 100ms, `ease` — source: css-transition
```css
transition: color 100ms ease;
```
### hover-filter-20 — ×9
Seen on: div.zHhpsW_thumbnail 384×216
- from `filter: brightness(0.95);` to `filter: brightness(1);`
- 200ms, `cubic-bezier(0.215, 0.61, 0.355, 1)` — source: css-transition
```css
transition: filter 200ms cubic-bezier(0.215, 0.61, 0.355, 1);
```
### hover-opacity-21 — ×8
Seen on: div.TZTsQG_positioner.hide-mobile
- from `opacity: 0; width: 860px; height: 281.5px;` to `opacity: 0; width: 0px; height: 0px;`
- 0ms, `steps(1, end)`, stagger 370ms between siblings — source: js
```css
transition: opacity 0ms steps(1, end),
    width 0ms steps(1, end),
    height 0ms steps(1, end);
```
### hover-fade-out-22 — ×8
Seen on: div.PDOlRq_row 1344×44; span.PDOlRq_infoIcon 14×14
- from `opacity: 1;` to `opacity: 0;`
- 150ms, `cubic-bezier(0.215, 0.61, 0.355, 1)`, stagger 55ms between siblings — source: css-transition
```css
transition: opacity 150ms cubic-bezier(0.215, 0.61, 0.355, 1);
```
### hover-fade-down-23 — ×7
Seen on: div “→” 12×20; div “↗” 12×24
- from `transform: translate(-2px) translateY(-1px); opacity: 0;` to `transform: translateY(-1px); opacity: 1;`
- 100ms, `cubic-bezier(0.25, 0.46, 0.45, 0.94)` — source: css-transition
```css
transition: transform 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94),
    opacity 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94);
```
### hover-opacity-24 — ×6
Seen on: div.TZTsQG_positioner.hide-mobile
- from `opacity: 0; width: 860px; height: 226px;` to `opacity: 0; width: 0px; height: 0px;`
- 0ms, `steps(1, end)`, stagger 358ms between siblings — source: js
```css
transition: opacity 0ms steps(1, end),
    width 0ms steps(1, end),
    height 0ms steps(1, end);
```
### hover-tint-25 — ×4
Seen on: span.sc-KOGVz.TxVeW “Read story” 360×45; span.sc-KOGVz.kUMWj “→” 13×17
- from `color: rgb(247, 248, 248);` to `color: rgb(138, 143, 152);`
- 150ms, `ease` — source: css-transition
```css
transition: color 150ms ease;
```
### hover-filter-26 — ×3
Seen on: a.hide-tablet.QI8oKG_newFeatureLink 104×25; div.qM9FAa_sendButtonGroup 65×28; button.qM9FAa_sendButton 32×28
- from `filter: none;` to `filter: brightness(1.3);`
- 160ms, `cubic-bezier(0.25, 0.46, 0.45, 0.94)` — source: css-transition
```css
transition: filter 160ms cubic-bezier(0.25, 0.46, 0.45, 0.94);
```
### hover-tint-27 — ×3
Seen on: button._1uFtza_pillButton 28×28; div._1uFtza_pillButton.KFZpfa_splitButton 61×28; a.hbnAuG_root.hide-mobile 40×40
- from `color: rgb(138, 143, 152);` to `color: rgb(208, 214, 224);`
- 160ms, `cubic-bezier(0.25, 0.46, 0.45, 0.94)` — source: css-transition
```css
transition: color 160ms cubic-bezier(0.25, 0.46, 0.45, 0.94);
```
### hover-filter-28 — ×3
Seen on: a.qqCMlG_root.I_mUeq_root 97×24; a.qqCMlG_root.I_mUeq_root 136×24; a.qqCMlG_root.I_mUeq_root 71×24
- from `filter: none;` to `filter: brightness(1.3);`
- 100ms, `cubic-bezier(0.165, 0.84, 0.44, 1)` — source: css-transition
```css
transition: filter 100ms cubic-bezier(0.165, 0.84, 0.44, 1);
```
### hover-fade-out-scale-29 — ×3
Seen on: div
- from `transform: scale(1); opacity: 1;` to `transform: scale(0.9); opacity: 0;`
- 120ms, `cubic-bezier(0.25, 0.46, 0.45, 0.94)` — source: css-animation
```css
transition: transform 120ms cubic-bezier(0.25, 0.46, 0.45, 0.94),
    opacity 120ms cubic-bezier(0.25, 0.46, 0.45, 0.94);
```

## Loops
Ambient, infinite animations.

### loop-slide-40 — ×6
Seen on: span.sx-iy17q3.sx-ce8rw5 “Working…” 60×14; span.sx-iy17q3.sx-ce8rw5 “Thinking…”
- from `transform: translateX(0px);` to `transform: translateX(0px);`
- 2400ms, `linear`, loops forever — source: css-animation
```css
@keyframes loop-slide-40 { 0%, 100% { transform: translateX(0); } 75%, 99.999% { transform: translateX(100%); } }
```
### loop-backgroundpositionx-41 — ×3
Seen on: span 106×24
- from `background-position-x: 0px; background-position-y: 50%;` to `background-position-x: 120px; background-position-y: 50%;`
- 2000ms, `linear`, delay -80ms, loops forever — source: css-animation
```css
@keyframes loop-backgroundpositionx-41 { 0%{background-position:0} to{background-position:120px} }
```
### loop-opacity-42 — ×2
Seen on: circle.grid-dot-0-0-agent
- from `opacity: 1;` to `opacity: 1;`
- 3200ms, `steps(1)`, loops forever — source: css-animation
```css
@keyframes loop-opacity-42 { 0% { opacity: 1; } 6.25% { opacity: 1; } 6.25% { opacity: 1; } 12.5% { opacity: 1; } 12.5% { opacity: 1; } 18.75% { opacity: 1; } 18.75% { opacity: 1; } 25% { opacity: 1; } 25% { opacity: 1; } 31.25% { opacity: 1; } 31.25% { opacity: 1; } 37.5% { opacity: 1; } 37.5% { opacity: 1; } 43.75% { opacity: 1; } 43.75% { opacity: 1; } 50% { opacity: 1; } 50% { opacity: 1; } 56.25% { opacity: 1; } 56.25% { opacity: 1; } 62.5% { opacity: 1; } 62.5% { opacity: 1; } 68.75% { opacity: 1; } 68.75% { opacity: 1; } 75% { opacity: 1; } 75% { opacity: 1; } 81.25% { opacity: 1; } 81.25% { opacity: 1; } 87.5% { o }
```
