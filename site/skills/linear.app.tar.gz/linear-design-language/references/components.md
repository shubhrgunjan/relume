# Components

Each variant is the clustered style of every element that looked the same across the crawled pages. Classes of the same name are in `assets/tokens.css`. Crops are in `assets/reference/`.

## link (link, ×145)
![link](../assets/reference/link.jpg)
Examples: “Customers”, “Pricing”, “Now”, “Contact”

| property | value |
|---|---|
| background | `transparent` |
| color | `#8a8f98` |
| radius | `9999px` |
| font | `400 13px/19.5px` |
| family | `Inter Variable` |
| padding | `0px 12px 0px 12px` |
| transition | `color 0.1s cubic-bezier(0.25, 0.46, 0.45, 0.94), background 0.1s cubic-bezier(0.25, 0.46, 0.45, 0.94)` |
| cursor | `pointer` |
Size: 32px tall, from 12px wide, padding 0px × 12px.

**Hover**
| property | rest | hover |
|---|---|---|
| color | `rgb(138, 143, 152)` | `rgb(247, 248, 248)` |
| backgroundColor | `rgba(0, 0, 0, 0)` | `rgba(255, 255, 255, 0.08)` |
| borderTopColor | `rgb(138, 143, 152)` | `rgb(247, 248, 248)` |
Transitions: backgroundColor 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); backgroundPositionX 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); backgroundPositionY 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); color 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94)
Inside it: button.TZTsQG_anchor.TZTsQG_trigger “Product” 73×32 — backgroundColor 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); button.TZTsQG_anchor.TZTsQG_trigger “Product” 73×32 — backgroundPositionX 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); button.TZTsQG_anchor.TZTsQG_trigger “Product” 73×32 — backgroundPositionY 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); button.TZTsQG_anchor.TZTsQG_trigger “Product” 73×32 — color 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); nav.Fzcv4W_hideScrollbars — transform, opacity 180ms linear; button.TZTsQG_anchor.TZTsQG_trigger “Product” 73×32 — backgroundColor 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94)

**Focus-visible**: outline `1px solid rgb(94, 105, 209)`, offset 2px

## link-2 (link, ×16)
![link-2](../assets/reference/link-2.jpg)
Examples: “Privacy”, “Terms”, “DPA”, “AUP”

| property | value |
|---|---|
| background | `transparent` |
| color | `#62666d` |
| font | `400 13px/19.5px` |
| family | `Inter Variable` |
| letterSpacing | `-0.13px` |
| padding | `0px 0px 0px 0px` |
| cursor | `pointer` |
Size: 20px tall, from 25px wide, padding 0px × 0px.

**Hover**
| property | rest | hover |
|---|---|---|
| color | `rgb(98, 102, 109)` | `rgb(138, 143, 152)` |
| borderTopColor | `rgb(98, 102, 109)` | `rgb(138, 143, 152)` |

**Focus-visible**: outline `1px solid rgb(94, 105, 209)`, offset 2px

## link-3 (link, ×3)
![link-3](../assets/reference/link-3.jpg)
Examples: “Customers”, “Pricing”, “Now”

| property | value |
|---|---|
| background | `transparent` |
| color | `#f7f8f8` |
| radius | `9999px` |
| font | `400 13px/19.5px` |
| family | `Inter Variable` |
| padding | `0px 12px 0px 12px` |
| transition | `color 0.1s cubic-bezier(0.25, 0.46, 0.45, 0.94), background 0.1s cubic-bezier(0.25, 0.46, 0.45, 0.94)` |
| cursor | `pointer` |
Size: 32px tall, from 52px wide, padding 0px × 12px.

**Hover**
| property | rest | hover |
|---|---|---|
| backgroundColor | `rgba(0, 0, 0, 0)` | `rgba(255, 255, 255, 0.08)` |
Transitions: backgroundColor 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); backgroundPositionX 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); backgroundPositionY 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94)
Inside it: button.TZTsQG_anchor.TZTsQG_trigger “Product” 73×32 — backgroundColor 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); button.TZTsQG_anchor.TZTsQG_trigger “Product” 73×32 — backgroundPositionX 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); button.TZTsQG_anchor.TZTsQG_trigger “Product” 73×32 — backgroundPositionY 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); button.TZTsQG_anchor.TZTsQG_trigger “Product” 73×32 — color 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); nav.Fzcv4W_hideScrollbars — transform, opacity 180ms linear; button.TZTsQG_anchor.TZTsQG_trigger “Product” 73×32 — backgroundColor 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94)

**Focus-visible**: outline `1px solid rgb(94, 105, 209)`, offset 2px

## card (card, ×16)
![card](../assets/reference/card.jpg)

| property | value |
|---|---|
| background | `linear-gradient(rgba(255, 255, 255, 0.02), rgba(255, 255, 255, 0.02)), none` |
| color | `#f7f8f8` |
| border | `1px solid rgb(255 255 255 / 0.08)` |
| radius | `9px` |
| font | `400 16px/24px` |
| family | `Inter Variable` |
| padding | `8px 10px 12px 12px` |
| ::after | `{"content":"\"\"","backgroundColor":"rgba(255, 255, 255, 0.03)","width":"298px","height":"94px","position":"absolute","transform":"none","transitionProperty":"all","transitionDuration":"0s","transitionTimingFunction":"ease","borderRadius":"9px","opacity":"0","backgroundImage":"none"}` |
Size: 96px tall, from 300px wide, padding 8px × 12px.

## card-2 (card, ×6)
![card-2](../assets/reference/card-2.jpg)

| property | value |
|---|---|
| background | `radial-gradient(circle, rgba(255, 255, 255, 0.04) 0%, rgba(0, 0, 0, 0) 50%)` |
| color | `#f7f8f8` |
| font | `400 16px/24px` |
| family | `Inter Variable` |
| padding | `0px 0px 0px 0px` |
Size: 400px tall, from 400px wide, padding 0px × 0px.

## card-3 (card, ×5)
![card-3](../assets/reference/card-3.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#f7f8f8` |
| border | `1px solid rgb(255 255 255 / 0.08)` |
| radius | `12px` |
| font | `400 16px/24px` |
| family | `Inter Variable` |
| padding | `0px 0px 0px 0px` |
Size: 720px tall, from 400px wide, padding 0px × 0px.

## card-4 (card, ×5)
![card-4](../assets/reference/card-4.jpg)

| property | value |
|---|---|
| background | `#0f1011` |
| color | `#f7f8f8` |
| radius | `4px` |
| font | `400 16px/24px` |
| family | `Inter Variable` |
| padding | `0px 0px 0px 0px` |
| transition | `filter 0.2s cubic-bezier(0.215, 0.61, 0.355, 1)` |
| cursor | `pointer` |
Size: 216px tall, from 384px wide, padding 0px × 0px.

**Hover**
| property | rest | hover |
|---|---|---|
| filter | `brightness(0.95)` | `brightness(1)` |
Transitions: filter 200ms cubic-bezier(0.215, 0.61, 0.355, 1)

## card-5 (card, ×4)
![card-5](../assets/reference/card-5.jpg)

| property | value |
|---|---|
| background | `#0f1011` |
| color | `#f7f8f8` |
| border | `1px solid rgb(255 255 255 / 0.12)` |
| radius | `12px` |
| shadow | `rgba(0, 0, 0, 0.25) 0px 2px 32px 0px` |
| font | `400 16px/24px` |
| family | `Inter Variable` |
| padding | `0px 0px 0px 0px` |
Size: 560px tall, from 400px wide, padding 0px × 0px.

## card-6 (card, ×2)
![card-6](../assets/reference/card-6.jpg)

| property | value |
|---|---|
| background | `linear-gradient(rgba(255, 255, 255, 0.03), rgba(255, 255, 255, 0.03)), none` |
| color | `#f7f8f8` |
| border | `1px solid rgb(255 255 255 / 0.08)` |
| radius | `9px` |
| shadow | `rgba(0, 0, 0, 0.2) 0px 0px 0px 1px` |
| font | `400 16px/24px` |
| family | `Inter Variable` |
| padding | `12px 16px 16px 16px` |
| gap | `16px` |
| ::after | `{"content":"\"\"","backgroundColor":"rgba(0, 0, 0, 0)","width":"659.766px","height":"146.797px","position":"absolute","transform":"none","transitionProperty":"all","transitionDuration":"0s","transitionTimingFunction":"ease","borderRadius":"9px","opacity":"1","backgroundImage":"none"}` |
Size: 149px tall, from 662px wide, padding 12px × 16px.

## card-7 (card, ×2)
![card-7](../assets/reference/card-7.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#f7f8f8` |
| border | `1px solid rgb(255 255 255 / 0.08)` |
| radius | `8px` |
| font | `400 16px/24px` |
| family | `Inter Variable` |
| padding | `0px 0px 0px 0px` |
Size: 704px tall, from 1320px wide, padding 0px × 0px.

## navbar (navbar, ×14)
![navbar](../assets/reference/navbar.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#f7f8f8` |
| font | `400 16px/24px` |
| family | `Inter Variable` |
| padding | `0px 0px 0px 0px` |
Size: 72px tall, from 398px wide, padding 0px × 0px.

## button-secondary (button, ×7)
![button-secondary](../assets/reference/button-secondary.jpg)
Examples: “Get started”, “Contact sales”

| property | value |
|---|---|
| background | `rgb(255 255 255 / 0.05)` |
| color | `#f7f8f8` |
| radius | `9999px` |
| shadow | `rgba(255, 255, 255, 0.03) 0px 0px 0px 1px inset, rgba(255, 255, 255, 0.04) 0px 1px 0px 0px inset, rgba(0, 0, 0, 0.6) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 4px 4px 0px` |
| font | `510 13px/40px` |
| family | `Inter Variable` |
| padding | `0px 14px 0px 14px` |
| gap | `8px` |
| transition | `border 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), background-color 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), color 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), box-shadow 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), opacity 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), filter 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), transform 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94)` |
| backdrop | `blur(4px)` |
| cursor | `pointer` |
Size: 40px tall, from 131px wide, padding 0px × 14px.

**Hover**
| property | rest | hover |
|---|---|---|
| backgroundColor | `rgba(255, 255, 255, 0.05)` | `rgb(25, 26, 27)` |
Transitions: backgroundColor 160ms cubic-bezier(0.25, 0.46, 0.45, 0.94)

**Focus-visible**: outline `1px solid rgb(94, 105, 209)`, offset 2px, shadow `rgba(255, 255, 255, 0.03) 0px 0px 0px 1px inset, rgba(255, 255, 255, 0.04) 0px 1px 0px 0px inset, rgba(0, 0, 0, 0.6) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 4px 4px 0px`

## button-primary (button, ×6)
![button-primary](../assets/reference/button-primary.jpg)
Examples: “Sign up”, “Get started”

| property | value |
|---|---|
| background | `#e5e5e6` |
| color | `#08090a` |
| border | `1px solid #e5e5e6` |
| radius | `9999px` |
| shadow | `rgba(0, 0, 0, 0) 0px 8px 2px 0px, rgba(0, 0, 0, 0.01) 0px 5px 2px 0px, rgba(0, 0, 0, 0.04) 0px 3px 2px 0px, rgba(0, 0, 0, 0.07) 0px 1px 1px 0px, rgba(0, 0, 0, 0.08) 0px 0px 1px 0px` |
| font | `510 13px/32px` |
| family | `Inter Variable` |
| padding | `0px 12px 0px 12px` |
| gap | `8px` |
| transition | `border 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), background-color 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), color 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), box-shadow 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), opacity 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), filter 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), transform 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94)` |
| cursor | `pointer` |
Size: 32px tall, from 72px wide, padding 0px × 12px.

**Hover**
| property | rest | hover |
|---|---|---|
| backgroundColor | `rgb(229, 229, 230)` | `rgb(255, 255, 255)` |
Transitions: backgroundColor 160ms cubic-bezier(0.25, 0.46, 0.45, 0.94)
Inside it: button.TZTsQG_anchor.TZTsQG_trigger “Resources” 91×32 — backgroundColor 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); button.TZTsQG_anchor.TZTsQG_trigger “Resources” 91×32 — backgroundPositionX 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); button.TZTsQG_anchor.TZTsQG_trigger “Resources” 91×32 — backgroundPositionY 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); button.TZTsQG_anchor.TZTsQG_trigger “Resources” 91×32 — color 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94); nav.Fzcv4W_hideScrollbars — transform, opacity 180ms linear; button.TZTsQG_anchor.TZTsQG_trigger “Resources” 91×32 — backgroundColor 100ms cubic-bezier(0.25, 0.46, 0.45, 0.94)

**Focus-visible**: outline `1px solid rgb(94, 105, 209)`, offset 2px, shadow `rgba(0, 0, 0, 0) 0px 8px 2px 0px, rgba(0, 0, 0, 0.01) 0px 5px 2px 0px, rgba(0, 0, 0, 0.04) 0px 3px 2px 0px, rgba(0, 0, 0, 0.07) 0px 1px 1px 0px, rgba(0, 0, 0, 0.08) 0px 0px 1px 0px`

## button-secondary-2 (button, ×4)
![button-secondary-2](../assets/reference/button-secondary-2.jpg)
Examples: “Get started”

| property | value |
|---|---|
| background | `#e5e5e6` |
| color | `#08090a` |
| border | `1px solid #e5e5e6` |
| radius | `9999px` |
| shadow | `rgba(0, 0, 0, 0) 0px 8px 2px 0px, rgba(0, 0, 0, 0.01) 0px 5px 2px 0px, rgba(0, 0, 0, 0.04) 0px 3px 2px 0px, rgba(0, 0, 0, 0.07) 0px 1px 1px 0px, rgba(0, 0, 0, 0.08) 0px 0px 1px 0px` |
| font | `510 16px/44px` |
| family | `Inter Variable` |
| padding | `0px 20px 0px 20px` |
| gap | `6px` |
| transition | `border 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), background-color 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), color 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), box-shadow 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), opacity 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), filter 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), transform 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94)` |
| cursor | `pointer` |
Size: 44px tall, from 126px wide, padding 0px × 20px.

**Hover**
| property | rest | hover |
|---|---|---|
| backgroundColor | `rgb(229, 229, 230)` | `rgb(255, 255, 255)` |
Transitions: backgroundColor 160ms cubic-bezier(0.25, 0.46, 0.45, 0.94)

**Focus-visible**: outline `1px solid rgb(94, 105, 209)`, offset 2px, shadow `rgba(0, 0, 0, 0) 0px 8px 2px 0px, rgba(0, 0, 0, 0.01) 0px 5px 2px 0px, rgba(0, 0, 0, 0.04) 0px 3px 2px 0px, rgba(0, 0, 0, 0.07) 0px 1px 1px 0px, rgba(0, 0, 0, 0.08) 0px 0px 1px 0px`

## button-secondary-3 (button, ×4)
![button-secondary-3](../assets/reference/button-secondary-3.jpg)
Examples: “Contact sales”

| property | value |
|---|---|
| background | `rgb(255 255 255 / 0.05)` |
| color | `#f7f8f8` |
| radius | `9999px` |
| shadow | `rgba(255, 255, 255, 0.03) 0px 0px 0px 1px inset, rgba(255, 255, 255, 0.04) 0px 1px 0px 0px inset, rgba(0, 0, 0, 0.6) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 4px 4px 0px` |
| font | `510 16px/44px` |
| family | `Inter Variable` |
| padding | `0px 20px 0px 20px` |
| gap | `6px` |
| transition | `border 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), background-color 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), color 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), box-shadow 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), opacity 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), filter 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), transform 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94)` |
| backdrop | `blur(4px)` |
| cursor | `pointer` |
Size: 44px tall, from 142px wide, padding 0px × 20px.

**Hover**
| property | rest | hover |
|---|---|---|
| backgroundColor | `rgba(255, 255, 255, 0.05)` | `rgb(25, 26, 27)` |
Transitions: backgroundColor 160ms cubic-bezier(0.25, 0.46, 0.45, 0.94)

**Focus-visible**: outline `1px solid rgb(94, 105, 209)`, offset 2px, shadow `rgba(255, 255, 255, 0.03) 0px 0px 0px 1px inset, rgba(255, 255, 255, 0.04) 0px 1px 0px 0px inset, rgba(0, 0, 0, 0.6) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 4px 4px 0px`

## button-ghost (button, ×3)
![button-ghost](../assets/reference/button-ghost.jpg)
Examples: “Copy issue URL”, “Copy issue ID”, “Copy git branch name”

| property | value |
|---|---|
| background | `transparent` |
| color | `#8a8f98` |
| radius | `9999px` |
| shadow | `rgba(255, 255, 255, 0.05) 0px 0px 0px 1px inset` |
| font | `400 13.3333px/normal` |
| family | `Inter Variable` |
| padding | `0px 7px 0px 7px` |
| transition | `background 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), color 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94)` |
| cursor | `pointer` |
Size: 28px tall, from 28px wide, padding 0px × 7px.

**Hover**
| property | rest | hover |
|---|---|---|
| color | `rgb(138, 143, 152)` | `rgb(208, 214, 224)` |
| backgroundColor | `rgba(255, 255, 255, 0.02)` | `rgba(255, 255, 255, 0.05)` |
| borderTopColor | `rgb(138, 143, 152)` | `rgb(208, 214, 224)` |
Transitions: backgroundColor 160ms cubic-bezier(0.25, 0.46, 0.45, 0.94); color 160ms cubic-bezier(0.25, 0.46, 0.45, 0.94)

**Focus-visible**: outline `1px solid rgb(94, 105, 209)`, offset 2px, shadow `rgba(255, 255, 255, 0.05) 0px 0px 0px 1px inset`

## button-outline (button, ×2)
![button-outline](../assets/reference/button-outline.jpg)
Examples: “Performance”, “iOS”

| property | value |
|---|---|
| background | `transparent` |
| color | `#d0d6e0` |
| border | `1px solid #2e2e32` |
| radius | `16px` |
| font | `400 12px/14px` |
| family | `Inter Variable` |
| padding | `0px 11px 0px 7px` |
| gap | `2px` |
| transition | `filter 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94), transform 0.16s cubic-bezier(0.25, 0.46, 0.45, 0.94)` |
| cursor | `default` |
Size: 24px tall, from 59px wide, padding 0px × 7px.

**Focus-visible**: outline `1px solid rgb(94, 105, 209)`, offset 2px

## footer (footer, ×4)
![footer](../assets/reference/footer.jpg)

| property | value |
|---|---|
| background | `#08090a` |
| color | `#f7f8f8` |
| border | `1px solid #23252a` |
| font | `400 16px/24px` |
| family | `Inter Variable` |
| padding | `0px 0px 0px 0px` |
Size: 494px tall, from 1440px wide, padding 0px × 0px.

## badge (badge, ×3)
![badge](../assets/reference/badge.jpg)
Examples: “Opus 5.5”

| property | value |
|---|---|
| background | `transparent` |
| color | `#8a8f98` |
| border | `1px solid rgb(255 255 255 / 0.08)` |
| radius | `4px` |
| font | `400 11px/14px` |
| family | `Inter Variable` |
| padding | `1px 4px 1px 4px` |
Size: 18px tall, from 60px wide, padding 1px × 4px.

## badge-2 (badge, ×1)
![badge-2](../assets/reference/badge-2.jpg)
Examples: “vehicle_state”

| property | value |
|---|---|
| background | `rgb(255 255 255 / 0.05)` |
| color | `#d0d6e0` |
| border | `1px solid rgb(255 255 255 / 0.08)` |
| radius | `4px` |
| font | `400 12px/20px` |
| family | `Berkeley Mono` |
| letterSpacing | `-0.182px` |
| padding | `0px 6px 0px 6px` |
Size: 24px tall, from 103px wide, padding 0px × 6px.

## badge-3 (badge, ×1)
![badge-3](../assets/reference/badge-3.jpg)
Examples: “@Linear”

| property | value |
|---|---|
| background | `rgb(109 120 213 / 0.15)` |
| color | `#6d78d5` |
| radius | `4px` |
| font | `400 15px/24px` |
| family | `Inter Variable` |
| letterSpacing | `-0.165px` |
| padding | `0px 3px 0px 3px` |
Size: 24px tall, from 61px wide, padding 0px × 3px.

## input (input, ×1)
![input](../assets/reference/input.jpg)
Examples: “import React from 'react' import { View,”

| property | value |
|---|---|
| background | `transparent` |
| font | `400 14px/24px` |
| family | `Berkeley Mono` |
| padding | `0px 32px 0px 63px` |
| cursor | `text` |
Size: 432px tall, from 784px wide, padding 0px × 63px.

## input-2 (input, ×1)
![input-2](../assets/reference/input-2.jpg)

| property | value |
|---|---|
| background | `#3b3b3b` |
| color | `#ffffff` |
| font | `400 13.3333px/normal` |
| family | `Inter Variable` |
| padding | `0px 0px 0px 0px` |
| cursor | `text` |
Size: 1px tall, from 1px wide, padding 0px × 0px.
