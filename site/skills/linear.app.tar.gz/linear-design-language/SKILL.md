---
name: linear-design-language
description: "Build UI in the design language measured from linear.app: Dark interface, almost entirely neutral — colour is rationed (chromatic share 2.9%). Use whenever creating or restyling pages, sections or components that should look and move like linear.app — colours, type, spacing, components and motion come from measurement, not guesswork."
---

# linear.app design language

Measured from https://linear.app (4 pages at desktop, tablet, mobile, desktop-dark) on 2026-10-28 by relume. Every value here was read from the live site — computed styles, stylesheets, animations and a frame-by-frame motion recording — so treat them as facts, not suggestions.

## The feel
- Dark interface, almost entirely neutral — colour is rationed (chromatic share 2.9%).
- Maximum-contrast text (18.7:1).
- Headlines 64px / 510, tightly tracked (-0.022em); body 15px at 1.6 leading.
- Moderately rounded surfaces (8px).
- Layered shadows carry depth.
- Translucent, blurred (glass) layers are part of the language.
- Generous vertical rhythm: sections breathe with ~128px padding on desktop.
- Entrances run ~460ms, with spring physics (4 spring curves); native scrolling.

## Build to the blueprint first
This language is not only its tokens. Its home page is 11 screens of 11 sections; 39% of it is covered by visuals (10 ui-mock, 1 image, 1 logos, 3 illustration, 6 avatar, 1 dataviz, 2 cards, 2 code, 1 form, 1 testimonial), at ~81 painted elements per screen. Read `references/blueprint.md` before anything else: it lists every section of the source in order, with a crop, its layout, and what it is made of. A new page must have the same kinds of sections in the same order, filled with the same kinds of things for your product: product UI built in real HTML with the measured UI grammar, illustrations in the source's style, data visualisations, logo rows, testimonial cards. Headings over empty boxes are not this language, and the checker fails them.

## Setup
1. Copy `assets/tokens.css` (plain CSS variables, text styles, component classes, `.container` and `.section` with the measured width, gutters and rhythm — use them, don't re-derive) into the project; with Tailwind v4 also import `assets/tailwind.css` after `@import "tailwindcss"`.
2. Add `assets/motion.css` and `assets/motion.js` (scroll reveals, intro choreography, stagger and scroll feel, all with measured timings).
3. Fonts: **Inter Variable** (= Inter on Google Fonts) for h2, display, h2-medium, title-lg — `var(--font-sans)`; **Berkeley Mono** (use **JetBrains Mono** unless you hold a licence) for mono-sm, mono-sm-regular — `var(--font-mono)`.
   Load the open ones: `<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=JetBrains+Mono:wght@400&display=swap" rel="stylesheet">`

## Core tokens
- Background #08090a, text #f7f8f8 / #d0d6e0 / #8a8f98, accent #5e69d1, surface #0f1011, border rgb(255 255 255 / 0.08).
- Type scale ≈1.071 (minor second) from 15px: h2 72/510, display 64/510, h2-medium 48/510, title-lg 32/400, h3 24/590, title-lg-medium 24/510, title-lg-regular 24/400, h3-semibold 20/590.
- Radii 9999px, 5px, 4px, 9px, 12px. Spacing grid 2px. Container 1310px, gutters 48 / 36 / 24px (desktop / tablet / mobile).
- Motion: 420ms, 100ms, 160ms, 150ms, 300ms; curves `cubic-bezier(0.25, 0.46, 0.45, 0.94)`, `ease`, `cubic-bezier(0.215, 0.61, 0.355, 1)` plus 1 spring curve (kept exact as `linear()`). Scroll: native.
- Primary action: #e5e5e6 / #08090a, radius 9999px, 510 13px/32px; on hover backgroundColor → rgb(255, 255, 255).

## Do
- Use only the colour tokens in `assets/tokens.css`; the accent (#5e69d1) covers ≤7% of any screen.
- Set text with the named styles (`.text-body`, `.text-h2` …); never invent sizes between them.
- Space on the 2px grid (32, 8, 14, 4, 6, 12 are the workhorses); sections get ~128px vertical padding on desktop.
- Reuse the measured shadows verbatim; they are layered, not single blurs.
- Floating chrome (nav, popovers) uses the measured backdrop blur over a translucent fill.

## Don't
- Do not use radii outside 9999px, 5px, 4px, 9px, 12px.
- Do not use durations or curves that are not in the motion tokens (420ms, 100ms, 160ms, 150ms, 300ms).
- Do not add smooth-scroll libraries; the source scrolls natively.
- Do not copy the source’s logo, product names, photography, illustrations or copy; describe your own product in this language.

## Motion signature
- **intro-fade-blur-up-1** (load, ×9): transform: translateY(20%); opacity: 0; filter: blur(10px); → transform: translateY(0%); opacity: 1; filter: blur(0px); over 1000ms `cubic-bezier(0.25, 0.1, 0.25, 1)`, delay 400ms, stagger 34ms.
- **intro-fade-2** (load, ×5): opacity: 0; → opacity: 1; over 1500ms `cubic-bezier(0.455, 0.03, 0.515, 0.955)`, delay 1300ms.
- **intro-fade-blur-3** (load, ×4): opacity: 0; filter: blur(2px); → opacity: 1; filter: blur(0px); over 300ms `spring (see motion.md)`.
- **intro-backgroundpositionx-4** (load, ×3): background-position-x: -8px, 0px; background-position-y: 50%, 50%; → background-position-x: 112px, 0px; background-position-y: 50%, 50%; over 2000ms `linear`.
- **intro-fade-5** (load, ×2): opacity: 0; → opacity: 1; over 350ms `cubic-bezier(0.16, 1, 0.3, 1)`.
- **intro-fade-6** (load): opacity: 0; → opacity: 1; over 500ms `cubic-bezier(0.455, 0.03, 0.515, 0.955)`, delay 1300ms.

## Workflow
1. Read `references/tokens.md` and `references/components.md` before writing UI; open the images in `assets/reference/` to see the look.
2. Build with the component classes and text styles; take motion from `references/motion.md` (exact CSS per pattern).
3. Run `node scripts/lint.mjs <your files…>` and fix every off-system colour, size, radius, duration and curve it reports.
4. If the relume MCP server is connected, call `check_style` with your page's URL: it re-measures your page and compares its DNA (composition, tokens and motion) with this one. Fix what it reports until it passes.

## References
- `references/blueprint.md` — the page, section by section: order, layout, contents, density, crops, and the UI grammar of the product mock-ups.
- `references/tokens.md` — every colour (with dark values and the source’s own variable names), text style (with fluid sizes), spacing, radius, border, shadow, gradient.
- `references/components.md` — buttons, links, inputs, cards, badges, navigation, footer: resting style, hover/focus states and transitions.
- `references/motion.md` — scroll feel, intro choreography, scroll reveals, hover motion, loops; exact CSS.
- `references/layout.md` — containers, gutters, grids, breakpoints, section rhythm, density.
- `assets/DESIGN.md` — the same system in Google's DESIGN.md format, for other tools.
