# Motion

## Scroll feel
Native scrolling: one wheel notch moves 100px instantly. Do not add smoothing.

## Tokens
| duration | uses |
|---|---|
| 150ms | 183 |
| 300ms | 79 |
| 1250ms | 54 |
| 100ms | 28 |
| 500ms | 25 |
| 1000ms | 17 |
| 200ms | 16 |
| 5ms | 16 |
| 26ms | 8 |
| 69ms | 5 |

| curve | uses | kind |
|---|---|---|
| `cubic-bezier(0.4, 0, 0.2, 1)` | 315 | bezier |
| `cubic-bezier(0.4, 0.04, 0.04, 1)` | 58 | bezier |
| `cubic-bezier(0, 0, 0.2, 1)` | 42 | bezier |
| `ease-out` | 37 | bezier |
| `steps(1, end)` | 11 | bezier |
| `linear` | 6 | bezier |
| `ease-in` | 3 | bezier |
| `ease-in-out` | 3 | bezier |
| `ease` | 2 | bezier |
| `cubic-bezier(0.3, 0.57, 0.07, 0.95)` | 2 | bezier |

Libraries detected: canvas, next, tailwindLike.

## Intro choreography (ms after load)
- -196ms — span.block.whitespace-nowrap “npm i ai” 64×28 (intro-fade-5)
- 225ms — summary.flex.min-h-11 “Products” (intro-tint-1)
- 417ms — path (intro-strokedashoffset-2)
- 836ms — canvas.absolute.inset-0 1080×720 (intro-fade-3)
- 887ms — span.pointer-events-none.absolute 304×62 (intro-fade-6)
- 946ms — div.pointer-events-none.absolute “fallback” 68×22 (intro-tint-7)
- 946ms — div.pointer-events-none.absolute “fallback” 68×22 (intro-tint-7)
- 946ms — div.pointer-events-none.absolute “fallback” 68×22 (intro-tint-7)
- 2085ms — div.absolute.inset-0 1080×720 (intro-fade-out-4)

## Load / intro
Plays once when the page loads. Use `data-intro="<name>"` with motion.css; set `--i` for stagger order.

### intro-tint-1 — ×3
Seen on: summary.flex.min-h-11 “Products”
- from `color: rgb(77, 77, 77);` to `color: rgb(23, 23, 23);`
- 150ms, `cubic-bezier(0.4, 0, 0.2, 1)`, stagger 302ms between siblings — source: css-transition
```css
@keyframes intro-tint-1 {
  from { color: rgb(77, 77, 77); }
  to { color: rgb(23, 23, 23); }
}
```
### intro-strokedashoffset-2 — ×2
Seen on: path
- from `stroke-dashoffset: 1px;` to `stroke-dashoffset: 0px;`
- 260ms, `linear` — source: css-animation
```css
@keyframes intro-strokedashoffset-2 {
  from { stroke-dashoffset: 1px; }
  to { stroke-dashoffset: 0px; }
}
```
### intro-fade-3 — ×1
Seen on: canvas.absolute.inset-0 1080×720
- from `opacity: 0;` to `opacity: 1;`
- 1200ms, `linear` — source: css-transition
```css
@keyframes intro-fade-3 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-out-4 — ×1
Seen on: div.absolute.inset-0 1080×720
- from `opacity: 1;` to `opacity: 0;`
- 700ms, `linear` — source: css-transition
```css
@keyframes intro-fade-out-4 {
  from { opacity: 1; }
  to { opacity: 0; }
}
```
### intro-fade-5 — ×1
Seen on: span.block.whitespace-nowrap “npm i ai” 64×28
- from `opacity: 0;` to `opacity: 1;`
- 200ms, `ease-out` — source: css-animation
```css
@keyframes intro-fade-5 { 0%{opacity:0} to{opacity:1} }
```
### intro-fade-6 — ×1
Seen on: span.pointer-events-none.absolute 304×62
- from `opacity: 0;` to `opacity: 1;`
- 300ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
@keyframes intro-fade-6 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-tint-7 — ×1
Seen on: div.pointer-events-none.absolute “fallback” 68×22
- from `background-color: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.08) 0px 0px 0px 1px, rgba(0, 0, 0, 0.04) 0px 2px 2px 0px, rgb(250, 250, 250) 0px 0px 0px 1px; color: rgb(77, 77, 77);` to `background-color: rgb(23, 23, 23); box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.04) 0px 2px 2px 0px; color: rgb(255, 255, 255);`
- 300ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
@keyframes intro-tint-7 {
  from { background-color: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.08) 0px 0px 0px 1px, rgba(0, 0, 0, 0.04) 0px 2px 2px 0px, rgb(250, 250, 250) 0px 0px 0px 1px; color: rgb(77, 77, 77); }
  to { background-color: rgb(23, 23, 23); box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.04) 0px 2px 2px 0px; color: rgb(255, 255, 255); }
}
```

## Scroll reveals
Triggered as elements enter the viewport. Use `data-reveal="<name>"`; motion.js observes them at the measured entry point.

### reveal-fade-up-8 — ×54
Seen on: div.absolute.opacity-0 120×84; div.absolute.opacity-0
- from `transform: translateY(75%); opacity: 0;` to `transform: translateY(0px); opacity: 1;`
- 1250ms, `cubic-bezier(0.4, 0.04, 0.04, 1)`, stagger 17ms between siblings, starts at 85% viewport — source: css-animation
```css
[data-reveal="reveal-fade-up-8"] { transform: translateY(75%); opacity: 0; transition: transform 1250ms cubic-bezier(0.4, 0.04, 0.04, 1),
    opacity 1250ms cubic-bezier(0.4, 0.04, 0.04, 1); }
[data-reveal="reveal-fade-up-8"].is-in { transform: translateY(0px); opacity: 1; }
```
### reveal-fade-out-9 — ×8
Seen on: div.col-start-1.row-start-1; div.shrink-0.size-32; div.flex.items-end; div.col-start-1.row-start-1 468×263
- from `opacity: 1;` to `opacity: 0;`
- 300ms, `cubic-bezier(0.4, 0, 0.2, 1)`, stagger 473ms between siblings, starts at 35% viewport — source: css-transition
```css
[data-reveal="reveal-fade-out-9"] { opacity: 1; transition: opacity 300ms cubic-bezier(0.4, 0, 0.2, 1); }
[data-reveal="reveal-fade-out-9"].is-in { opacity: 0; }
```
### reveal-tint-10 — ×7
Seen on: h3.text-heading-24.transition-colors “Text” 43×32; h3.text-heading-24.transition-colors “Image” 64×32; h3.text-heading-24.transition-colors “Video” 58×32; h3.text-heading-24.transition-colors “Realtime” 92×32
- from `color: rgb(23, 23, 23);` to `color: rgb(77, 77, 77);`
- 300ms, `cubic-bezier(0.4, 0, 0.2, 1)`, starts at 20% viewport — source: css-transition
```css
[data-reveal="reveal-tint-10"] { color: rgb(23, 23, 23); transition: color 300ms cubic-bezier(0.4, 0, 0.2, 1); }
[data-reveal="reveal-tint-10"].is-in { color: rgb(77, 77, 77); }
```
### reveal-tint-11 — ×7
Seen on: h3.text-heading-24.transition-colors “Image” 64×32; h3.text-heading-24.transition-colors “Video” 58×32; h3.text-heading-24.transition-colors “Realtime” 92×32; h3.text-heading-24.transition-colors “Speech” 79×32
- from `color: rgb(77, 77, 77);` to `color: rgb(23, 23, 23);`
- 300ms, `cubic-bezier(0.4, 0, 0.2, 1)`, starts at 47% viewport — source: css-transition
```css
[data-reveal="reveal-tint-11"] { color: rgb(77, 77, 77); transition: color 300ms cubic-bezier(0.4, 0, 0.2, 1); }
[data-reveal="reveal-tint-11"].is-in { color: rgb(23, 23, 23); }
```
### reveal-tint-12 — ×7
Seen on: div.transition-colors.duration-300 14×14; div.transition-colors.duration-300; div.transition-all.duration-300; div.transition-all.duration-300 14×14
- from `color: rgb(218, 47, 53);` to `color: rgb(0, 104, 214);`
- 300ms, `cubic-bezier(0, 0, 0.2, 1)`, starts at 27% viewport — source: css-transition
```css
[data-reveal="reveal-tint-12"] { color: rgb(218, 47, 53); transition: color 300ms cubic-bezier(0, 0, 0.2, 1); }
[data-reveal="reveal-tint-12"].is-in { color: rgb(0, 104, 214); }
```
### reveal-fade-13 — ×5
Seen on: div.sticky.grid 1392×145; div.sticky.grid 1392×176; div.sticky.grid 1392×453; div.sticky.grid 1392×128
- from `opacity: 0.4;` to `opacity: 1;`
- 300ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
[data-reveal="reveal-fade-13"] { opacity: 0.4; transition: opacity 300ms cubic-bezier(0.4, 0, 0.2, 1); }
[data-reveal="reveal-fade-13"].is-in { opacity: 1; }
```
### reveal-fade-out-14 — ×4
Seen on: span.status-dot.shrink-0
- from `opacity: 1; width: 10px; height: 10px;` to `opacity: 0; width: 0px; height: 0px;`
- 0ms, `steps(1, end)`, starts at 98% viewport — source: js
```css
[data-reveal="reveal-fade-out-14"] { opacity: 1; width: 10px; height: 10px; transition: opacity 0ms steps(1, end),
    width 0ms steps(1, end),
    height 0ms steps(1, end); }
[data-reveal="reveal-fade-out-14"].is-in { opacity: 0; width: 0px; height: 0px; }
```
### reveal-fade-out-15 — ×4
Seen on: p.status-text.text-copy-14 “All systems normal.”
- from `opacity: 1; width: 133px; height: 20px;` to `opacity: 0; width: 0px; height: 0px;`
- 0ms, `steps(1, end)`, starts at 97% viewport — source: js
```css
[data-reveal="reveal-fade-out-15"] { opacity: 1; width: 133px; height: 20px; transition: opacity 0ms steps(1, end),
    width 0ms steps(1, end),
    height 0ms steps(1, end); }
[data-reveal="reveal-fade-out-15"].is-in { opacity: 0; width: 0px; height: 0px; }
```
### reveal-fade-16 — ×4
Seen on: div.flex.w-full; button.flex.size-11; button.flex.shrink-0
- from `opacity: 0;` to `opacity: 1;`
- 400ms, `ease-out`, stagger 150ms between siblings — source: css-animation
```css
[data-reveal="reveal-fade-16"] { opacity: 0; transition: opacity 400ms ease-out; }
[data-reveal="reveal-fade-16"].is-in { opacity: 1; }
```
### reveal-fade-scale-17 — ×4
Seen on: div.transition-all.duration-300; div.transition-opacity.duration-300 691×232; div.transition-all.duration-300 14×14
- from `transform: scale(0); opacity: 0;` to `transform: scale(1); opacity: 1;`
- 300ms, `cubic-bezier(0, 0, 0.2, 1)`, starts at 17% viewport — source: css-transition
```css
[data-reveal="reveal-fade-scale-17"] { transform: scale(0); opacity: 0; transition: transform 300ms cubic-bezier(0, 0, 0.2, 1),
    opacity 300ms cubic-bezier(0, 0, 0.2, 1); }
[data-reveal="reveal-fade-scale-17"].is-in { transform: scale(1); opacity: 1; }
```
### reveal-fade-tint-18 — ×3
Seen on: span.opacity-0.text-gray-900 “You”; span.opacity-0.text-gray-900 “can”; span.opacity-0.text-gray-900 “build”
- from `color: rgb(77, 77, 77); opacity: 0;` to `color: rgb(23, 23, 23); opacity: 1;`
- 500ms, `cubic-bezier(0.4, 0, 0.2, 1)`, stagger 199ms between siblings — source: css-transition
```css
[data-reveal="reveal-fade-tint-18"] { color: rgb(77, 77, 77); opacity: 0; transition: color 500ms cubic-bezier(0.4, 0, 0.2, 1),
    opacity 500ms cubic-bezier(0.4, 0, 0.2, 1); }
[data-reveal="reveal-fade-tint-18"].is-in { color: rgb(23, 23, 23); opacity: 1; }
```
### reveal-fade-19 — ×2
Seen on: div.sticky.flex 463×269
- from `opacity: 0.3;` to `opacity: 1;`
- 300ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
[data-reveal="reveal-fade-19"] { opacity: 0.3; transition: opacity 300ms cubic-bezier(0.4, 0, 0.2, 1); }
[data-reveal="reveal-fade-19"].is-in { opacity: 1; }
```
### reveal-fade-20 — ×2
Seen on: div.material-large.[transition-duration:500ms] 60×60
- from `opacity: 0; translate: 0px;` to `opacity: 1; translate: -20px -20px;`
- 500ms, `cubic-bezier(0.4, 0.04, 0.04, 1)`, starts at 25% viewport — source: css-transition
```css
[data-reveal="reveal-fade-20"] { opacity: 0; translate: 0px; transition: opacity 500ms cubic-bezier(0.4, 0.04, 0.04, 1),
    translate 500ms cubic-bezier(0.4, 0.04, 0.04, 1); }
[data-reveal="reveal-fade-20"].is-in { opacity: 1; translate: -20px -20px; }
```
### reveal-fade-21 — ×1
Seen on: span.col-start-1.row-start-1 “Onboard your agent” 148×24
- from `opacity: 0;` to `opacity: 1;`
- 200ms, `ease-out` — source: css-animation
```css
[data-reveal="reveal-fade-21"] { opacity: 0; transition: opacity 200ms ease-out; }
[data-reveal="reveal-fade-21"].is-in { opacity: 1; }
```

## Hover
Measured by hovering every distinct interactive element.

### hover-tint-29 — ×40
Seen on: a.outline-none.border-0 100×32; a.outline-none.border-0 76×32; a.outline-none.border-0 124×40; a.outline-none.border-0 133×40
- from `background-color: rgb(255, 255, 255);` to `background-color: rgb(242, 242, 242);`
- 150ms, `cubic-bezier(0.4, 0, 0.2, 1)`, stagger 28ms between siblings — source: css-transition
```css
transition: background-color 150ms cubic-bezier(0.4, 0, 0.2, 1);
```
### hover-fade-30 — ×14
Seen on: span 27×437
- from `opacity: 0;` to `opacity: 0.67;`
- 1000ms, `ease-out` — source: css-transition
```css
transition: opacity 1000ms ease-out;
```
### hover-tint-31 — ×12
Seen on: a.cursor-pointer.focus-visible:outline-2 “AI SDK” 51×24; a.cursor-pointer.focus-visible:outline-2 “Connect” 105×24; a.cursor-pointer.focus-visible:outline-2 “Marketing Sites” 103×24; a.cursor-pointer.focus-visible:outline-2 “Design Engineers” 114×24
- from `color: rgb(77, 77, 77);` to `color: rgb(23, 23, 23);`
- 100ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
transition: color 100ms cubic-bezier(0.4, 0, 0.2, 1);
```
### hover-tint-32 — ×10
Seen on: a.flex.flex-col 330×238; a.flex.flex-col 448×214; a.flex.cursor-pointer “And More” 109×32; a.cursor-pointer.focus-visible:outline-2 448×240
- from `border-bottom-color: rgb(230, 230, 230); border-left-color: rgb(230, 230, 230); border-right-color: rgb(230, 230, 230); border-color: rgb(230, 230, 230);` to `border-bottom-color: rgb(201, 201, 201); border-left-color: rgb(201, 201, 201); border-right-color: rgb(201, 201, 201); border-color: rgb(201, 201, 201);`
- 150ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
transition: border-bottom-color 150ms cubic-bezier(0.4, 0, 0.2, 1),
    border-left-color 150ms cubic-bezier(0.4, 0, 0.2, 1),
    border-right-color 150ms cubic-bezier(0.4, 0, 0.2, 1),
    border-color 150ms cubic-bezier(0.4, 0, 0.2, 1);
```
### hover-tint-33 — ×8
Seen on: button.text-gray-600.rounded-full 28×28; button.flex-1.min-w-0 “Image” 105×40; button.relative.inline-flex 107×32; span.relative.inline-flex 122×32
- from `color: rgb(168, 168, 168);` to `color: rgb(77, 77, 77);`
- 150ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
transition: color 150ms cubic-bezier(0.4, 0, 0.2, 1);
```
### hover-up-34 — ×3
Seen on: span.absolute.inset-y-0 109×68; span.absolute.inset-y-0 132×68
- from `transform: translate(-180%) skew(-12deg, 0deg);` to `transform: translate(280%) skew(-12deg, 0deg);`
- 1000ms, `ease-in-out`, delay 220ms — source: css-animation
```css
transition: transform 1000ms ease-in-out 220ms;
```
### hover-tint-35 — ×3
Seen on: span.flex.size-6 24×24
- from `background-color: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(235, 235, 235) 0px 0px 0px 1px inset;` to `background-color: rgb(242, 242, 242); box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(201, 201, 201) 0px 0px 0px 1px inset;`
- 200ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
transition: background-color 200ms cubic-bezier(0.4, 0, 0.2, 1),
    box-shadow 200ms cubic-bezier(0.4, 0, 0.2, 1);
```
### hover-fade-36 — ×2
Seen on: div.font-normal.rounded-lg “View as Agent”
- from `opacity: 0;` to `opacity: 1;`
- 100ms, `ease-in` — source: css-animation
```css
transition: opacity 100ms ease-in;
```
### hover-fade-37 — ×2
Seen on: button.outline-none.border-0 32×32; div.hover:opacity-80.outline-none 32×32
- from `opacity: 0; box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px;` to `opacity: 1; box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(235, 235, 235) 0px 0px 0px 1px;`
- 150ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
transition: opacity 150ms cubic-bezier(0.4, 0, 0.2, 1),
    box-shadow 150ms cubic-bezier(0.4, 0, 0.2, 1);
```
### hover-tint-38 — ×2
Seen on: button.vF3MAa_lineNumber “1” 32×20
- from `color: rgb(168, 168, 168);` to `color: rgb(23, 23, 23);`
- 125ms, `ease-out` — source: css-transition
```css
transition: color 125ms ease-out;
```
### hover-fade-39 — ×2
Seen on: div.transition-all.duration-500 632×59
- from `opacity: 0; translate: 0px 8px;` to `opacity: 1; translate: 0px;`
- 500ms, `cubic-bezier(0, 0, 0.2, 1)` — source: css-transition
```css
transition: opacity 500ms cubic-bezier(0, 0, 0.2, 1),
    translate 500ms cubic-bezier(0, 0, 0.2, 1);
```
### hover-tint-40 — ×2
Seen on: p.text-heading-16.@sm:text-heading-24 “AI SDK UI” 443×32; p.mt-3.text-copy-16 “A set of framework-agnos” 443×48
- from `color: rgb(143, 143, 143);` to `color: rgb(23, 23, 23);`
- 250ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
transition: color 250ms cubic-bezier(0.4, 0, 0.2, 1);
```
### hover-tint-41 — ×2
Seen on: a.flex.flex-col 330×238; a.cursor-pointer.focus-visible:outline-2 448×240
- from `border-bottom-color: rgb(229, 229, 229); border-left-color: rgb(229, 229, 229); border-right-color: rgb(229, 229, 229); border-color: rgb(229, 229, 229);` to `border-bottom-color: rgb(230, 230, 230); border-left-color: rgb(230, 230, 230); border-right-color: rgb(230, 230, 230); border-color: rgb(230, 230, 230);`
- 5ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
transition: border-bottom-color 5ms cubic-bezier(0.4, 0, 0.2, 1),
    border-left-color 5ms cubic-bezier(0.4, 0, 0.2, 1),
    border-right-color 5ms cubic-bezier(0.4, 0, 0.2, 1),
    border-color 5ms cubic-bezier(0.4, 0, 0.2, 1);
```
### hover-tint-42 — ×1
Seen on: a.cursor-pointer.focus-visible:outline-2 “Connect” 105×24
- from `color: rgb(72, 72, 72);` to `color: rgb(77, 77, 77);`
- 8ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
transition: color 8ms cubic-bezier(0.4, 0, 0.2, 1);
```
