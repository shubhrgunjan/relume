# Blueprint

Every section of the measured pages, top to bottom. Build the same kinds of sections in the same order for your product. "Made of" is what fills the section; recreate each block in kind (your content, the source's grammar). Crops are in `assets/reference/sections/`.

## home — 5986px, 6 sections, visuals 30%, 28 elements/screen

### 01 · hero
![hero](../assets/reference/sections/home-00.jpg)
- layout: **hero**; 64px tall; visuals cover 0%; 0 painted elements
- made of: text only (0 characters)

### 02 · logo strip
![logo strip](../assets/reference/sections/home-01.jpg)
- layout: **stacked**; 836px tall; visuals cover 75%; 14 painted elements
- heading: “Agentic Infrastructure” — 64px / 400, at x 24, 444px wide
- made of: **dataviz** (canvas 1080×720, at 180/88/1080/720); **logos** (6 marks in a row, at 24/816/1392/45)

### 03 · content
![content](../assets/reference/sections/home-02.jpg)
- layout: **stacked**; 2418px tall; visuals cover 42%; 24 painted elements
- heading: “Build agents on infrastructure that thinks like them” — 56px / 450, at x 24, 666px wide
- made of: **image** (921×486, at 24/1320/921/486); **image** (921×516, at 495/2193/921/516); **image** (921×516, at 24/3065/921/516)

### 04 · card row
![card row](../assets/reference/sections/home-03.jpg)
- layout: **columns**, 3 columns; 926px tall; visuals cover 12%; 30 painted elements
- heading: “Recently shipped” — 56px / 450, at x 24, 921px wide
- made of: **dataviz** (canvas 685×280, at 922/4171/685/280); **cards** (3 × 685×580, at 25/3871/1390/580); **cards** (2 × 685×580, at 25/3871/685/580)

### 05 · statement
![statement](../assets/reference/sections/home-04.jpg)
- layout: **centered**; 688px tall; visuals cover 0%; 12 painted elements
- heading: “Built by you, or your agents” — 56px / 450, at x 400, 640px wide
- made of: text only (56 characters)

### 06 · footer
![footer](../assets/reference/sections/home-05.jpg)
- layout: **stacked**; 846px tall; visuals cover 0%; 106 painted elements
- made of: text only (913 characters)

## ai-sdk — 4140px, 2 sections, visuals 17%, 69 elements/screen

### 01 · hero + product UI
![hero + product UI](../assets/reference/sections/ai-sdk-00.jpg)
- layout: **hero**, 4 columns; 3230px tall; visuals cover 21%; 213 painted elements
- heading: “The AI layer for building frameworks and agents on Vercel” — 64px / 450, at x 24, 684px wide
- made of: **code** (42 mono lines, at 890/258/526/192); **avatar** (48px, at 614/832/48/48); **avatar** (48px, at 740/832/48/48); **avatar** (48px, at 865/832/48/48); **avatar** (48px, at 991/832/48/48); **avatar** (48px, at 1117/832/48/48); **avatar** (48px, at 1242/832/48/48); **avatar** (48px, at 1368/832/48/48); **logos** (7 marks in a row, at 614/832/802/48); **cards** (4 × 330×238, at 24/2066/1392/238); **cards** (3 × 448×214, at 24/2984/1392/214); **ui-mock** (6 UI labels (panel), at 736/1384/680/354); **ui-mock** (13 UI labels (panel), at 24/1296/1392/578); **form** (inputs, at 0/64/1440/3230)

### 02 · footer
![footer](../assets/reference/sections/ai-sdk-01.jpg)
- layout: **stacked**; 846px tall; visuals cover 0%; 106 painted elements
- made of: text only (913 characters)

## ai-gateway — 19766px, 0 sections, visuals 0%, 0 elements/screen

## sandbox — 12869px, 2 sections, visuals 8%, 86 elements/screen

### 01 · hero
![hero](../assets/reference/sections/sandbox-00.jpg)
- layout: **hero**; 11959px tall; visuals cover 9%; 1120 painted elements
- heading: “The safest way to run code you didn’t write” — 64px / 450, at x 24, 684px wide
- made of: **code** (83 mono lines, at 733/1384/681/232); **code** (5 mono lines, at 732/1797/683/72); **code** (5 mono lines, at 732/2237/683/72); **code** (5 mono lines, at 732/2377/683/72); **code** (89 mono lines, at 724/2678/691/212); **code** (96 mono lines, at 732/5041/683/532); **code** (31 mono lines, at 733/6093/681/152); **code** (162 mono lines, at 732/6757/683/432); **code** (63 mono lines, at 632/10430/766/272); **logos** (7 marks in a row, at 24/825/1392/34); **form** (inputs, at 0/64/1440/11959)

### 02 · footer
![footer](../assets/reference/sections/sandbox-01.jpg)
- layout: **stacked**; 846px tall; visuals cover 0%; 106 painted elements
- made of: text only (913 characters)
