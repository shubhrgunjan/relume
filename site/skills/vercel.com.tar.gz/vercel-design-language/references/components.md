# Components

Each variant is the clustered style of every element that looked the same across the crawled pages. Classes of the same name are in `assets/tokens.css`. Crops are in `assets/reference/`.

## link (link, ×324)
![link](../assets/reference/link.jpg)
Examples: “AI SDK”, “AI Gateway”, “Sandbox”, “Workflows”

| property | value |
|---|---|
| background | `transparent` |
| color | `#4d4d4d` |
| font | `400 14px/20px` |
| family | `GeistSans` |
| padding | `2px 2px 2px 2px` |
| gap | `6px` |
| transition | `color 0.1s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.1s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.1s cubic-bezier(0.4, 0, 0.2, 1), outline-color 0.1s cubic-bezier(0.4, 0, 0.2, 1), text-decoration-color 0.1s cubic-bezier(0.4, 0, 0.2, 1), fill 0.1s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.1s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-from 0.1s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-via 0.1s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-to 0.1s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 24px tall, from 12px wide, padding 2px × 2px.

**Hover**
| property | rest | hover |
|---|---|---|
| color | `rgb(77, 77, 77)` | `rgb(23, 23, 23)` |
Transitions: color 100ms cubic-bezier(0.4, 0, 0.2, 1)

**Focus-visible**: outline `2px solid rgb(0, 114, 245)`, offset 4px

## link-2 (link, ×23)
![link-2](../assets/reference/link-2.jpg)
Examples: “pricing page”, “AI SDK”, “OpenAI Chat Completions”, “OpenAI Responses”

| property | value |
|---|---|
| background | `transparent` |
| color | `#4d4d4d` |
| font | `400 16px/25.6px` |
| family | `GeistSans` |
| padding | `0px 0px 0px 0px` |
| cursor | `pointer` |
Size: 21px tall, from 30px wide, padding 0px × 0px.

## link-3 (link, ×4)
![link-3](../assets/reference/link-3.jpg)
Examples: “AI Gateway API Keys page”, “OIDC tokens”, “all Vercel regions”, “regional pricing”

| property | value |
|---|---|
| background | `transparent` |
| color | `#171717` |
| font | `400 16px/24px` |
| family | `GeistSans` |
| padding | `0px 0px 0px 0px` |
| cursor | `pointer` |
Size: 21px tall, from 91px wide, padding 0px × 0px.

## card (card, ×17)
![card](../assets/reference/card.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#171717` |
| border | `1px solid #e6e6e6` |
| radius | `2px` |
| font | `400 16px/24px` |
| family | `GeistSans` |
| padding | `32px 32px 32px 32px` |
| gap | `32px` |
| transition | `color 0.15s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), outline-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), text-decoration-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), fill 0.15s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-from 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-via 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-to 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 238px tall, from 330px wide, padding 32px × 32px.

**Hover**
| property | rest | hover |
|---|---|---|
| borderTopColor | `rgb(230, 230, 230)` | `rgb(201, 201, 201)` |
Transitions: borderBottomColor 150ms cubic-bezier(0.4, 0, 0.2, 1); borderLeftColor 150ms cubic-bezier(0.4, 0, 0.2, 1); borderRightColor 150ms cubic-bezier(0.4, 0, 0.2, 1); borderTopColor 150ms cubic-bezier(0.4, 0, 0.2, 1)

**Focus-visible**: outline `1px none rgb(23, 23, 23)`, offset 1px, shadow `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(255, 255, 255) 0px 0px 0px 2px, rgb(0, 114, 245) 0px 0px 0px 4px, rgba(0, 0, 0, 0) 0px 0px 0px 0px`

## card-2 (card, ×7)
![card-2](../assets/reference/card-2.jpg)

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#171717` |
| radius | `8px` |
| font | `400 16px/24px` |
| family | `Geist Mono` |
| padding | `16px 0px 16px 0px` |
Size: 152px tall, from 662px wide, padding 16px × 0px.

## card-3 (card, ×6)
![card-3](../assets/reference/card-3.jpg)

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#171717` |
| radius | `12px` |
| shadow | `rgba(0, 0, 0, 0.08) 0px 0px 0px 1px, rgba(0, 0, 0, 0.04) 0px 2px 2px 0px, rgba(0, 0, 0, 0.04) 0px 8px 16px -4px, rgb(250, 250, 250) 0px 0px 0px 1px` |
| font | `400 16px/24px` |
| family | `GeistSans` |
| padding | `0px 0px 0px 0px` |
Size: 260px tall, from 526px wide, padding 0px × 0px.

## card-4 (card, ×6)
![card-4](../assets/reference/card-4.jpg)

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#171717` |
| font | `400 16px/24px` |
| family | `GeistSans` |
| padding | `0px 0px 0px 0px` |
Size: 220px tall, from 468px wide, padding 0px × 0px.

## card-5 (card, ×5)
![card-5](../assets/reference/card-5.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#171717` |
| font | `400 16px/24px` |
| family | `GeistSans` |
| padding | `0px 0px 0px 0px` |
Size: 342px tall, from 664px wide, padding 0px × 0px.

## card-6 (card, ×4)
![card-6](../assets/reference/card-6.jpg)

| property | value |
|---|---|
| background | `linear-gradient(to top in oklab, rgb(250, 250, 250) 0%, rgba(0, 0, 0, 0) 100%)` |
| color | `#171717` |
| font | `400 16px/24px` |
| family | `GeistSans` |
| padding | `0px 0px 0px 0px` |
Size: 160px tall, from 684px wide, padding 0px × 0px.

## card-7 (card, ×3)
![card-7](../assets/reference/card-7.jpg)

| property | value |
|---|---|
| background | `#fafafa` |
| color | `#171717` |
| radius | `6px` |
| shadow | `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.08) 0px 0px 0px 1px, rgb(250, 250, 250) 0px 0px 0px 1px` |
| font | `400 16px/24px` |
| family | `GeistSans` |
| padding | `20px 20px 20px 20px` |
| cursor | `pointer` |
Size: 580px tall, from 685px wide, padding 20px × 20px.

**Focus-visible**: outline `2px solid rgb(0, 114, 245)`, offset 4px, shadow `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.08) 0px 0px 0px 1px, rgb(250, 250, 250) 0px 0px 0px 1px`

## card-8 (card, ×3)
![card-8](../assets/reference/card-8.jpg)

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#171717` |
| border | `1px solid #e6e6e6` |
| radius | `2px` |
| font | `400 16px/24px` |
| family | `GeistSans` |
| padding | `32px 32px 32px 32px` |
| transition | `color 0.15s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), outline-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), text-decoration-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), fill 0.15s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-from 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-via 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-to 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 240px tall, from 448px wide, padding 32px × 32px.

**Hover**
| property | rest | hover |
|---|---|---|
| backgroundColor | `rgb(255, 255, 255)` | `rgba(0, 0, 0, 0.05)` |
| borderTopColor | `rgb(230, 230, 230)` | `rgb(201, 201, 201)` |
Transitions: backgroundColor 150ms cubic-bezier(0.4, 0, 0.2, 1); borderBottomColor 150ms cubic-bezier(0.4, 0, 0.2, 1); borderLeftColor 150ms cubic-bezier(0.4, 0, 0.2, 1); borderRightColor 150ms cubic-bezier(0.4, 0, 0.2, 1); borderTopColor 150ms cubic-bezier(0.4, 0, 0.2, 1)

**Focus-visible**: outline `2px none rgb(0, 114, 245)`, offset 4px, shadow `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(255, 255, 255) 0px 0px 0px 2px, rgb(0, 114, 245) 0px 0px 0px 4px, rgba(0, 0, 0, 0) 0px 0px 0px 0px`

## navbar (navbar, ×13)
![navbar](../assets/reference/navbar.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#171717` |
| font | `400 16px/24px` |
| family | `GeistSans` |
| padding | `0px 0px 0px 0px` |
| transition | `opacity 0.3s cubic-bezier(0.4, 0, 0.2, 1)` |
Size: 64px tall, from 123px wide, padding 0px × 0px.

## button-secondary (button, ×8)
![button-secondary](../assets/reference/button-secondary.jpg)

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#171717` |
| radius | `6px` |
| shadow | `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(235, 235, 235) 0px 0px 0px 1px` |
| font | `500 14px/21px` |
| family | `GeistSans` |
| padding | `0px 6px 0px 6px` |
| transition | `all 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 32px tall, from 64px wide, padding 0px × 6px.

**Hover**
| property | rest | hover |
|---|---|---|
| backgroundColor | `rgb(255, 255, 255)` | `rgb(242, 242, 242)` |
Transitions: backgroundColor 150ms cubic-bezier(0.4, 0, 0.2, 1)

**Focus-visible**: outline `3px none rgb(23, 23, 23)`, offset 0px, shadow `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(235, 235, 235) 0px 0px 0px 1px`

## button-primary (button, ×8)
![button-primary](../assets/reference/button-primary.jpg)
Examples: “Free”, “-51%”, “-50%”, “-25%”

| property | value |
|---|---|
| background | `#171717` |
| color | `#ffffff` |
| font | `450 12px/16px` |
| family | `GeistSans` |
| padding | `4px 8px 4px 8px` |
| cursor | `pointer` |
Size: 24px tall, from 48px wide, padding 4px × 8px.

## button-secondary-2 (button, ×7)
![button-secondary-2](../assets/reference/button-secondary-2.jpg)

| property | value |
|---|---|
| background | `#171717` |
| color | `#ffffff` |
| radius | `3.35544e+07px` |
| font | `500 14px/21px` |
| family | `GeistSans` |
| padding | `0px 12px 0px 12px` |
| transition | `all 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 36px tall, from 131px wide, padding 0px × 12px.

**Hover**
| property | rest | hover |
|---|---|---|
| backgroundColor | `rgb(23, 23, 23)` | `rgb(56, 56, 56)` |
Transitions: backgroundColor 150ms cubic-bezier(0.4, 0, 0.2, 1)
Inside it: p.text-heading-16.@sm:text-heading-24 “AI SDK UI” 443×32 — color 250ms cubic-bezier(0.4, 0, 0.2, 1); p.mt-3.text-copy-16 “A set of framework-agnos” 443×48 — color 250ms cubic-bezier(0.4, 0, 0.2, 1)

**Focus-visible**: outline `3px none rgb(255, 255, 255)`, offset 0px

## button-secondary-3 (button, ×7)
![button-secondary-3](../assets/reference/button-secondary-3.jpg)

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#171717` |
| border | `1px solid rgb(0 0 0 / 0.08)` |
| radius | `6px` |
| font | `400 16px/24px` |
| family | `GeistSans` |
| padding | `10px 48px 10px 12px` |
| cursor | `pointer` |
Size: 42px tall, from 264px wide, padding 10px × 12px.

## button-secondary-4 (button, ×5)
![button-secondary-4](../assets/reference/button-secondary-4.jpg)

| property | value |
|---|---|
| background | `#171717` |
| color | `#ffffff` |
| radius | `3.35544e+07px` |
| font | `500 16px/24px` |
| family | `GeistSans` |
| padding | `0px 12px 0px 12px` |
| transition | `all 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 40px tall, from 123px wide, padding 0px × 12px.

**Hover**
| property | rest | hover |
|---|---|---|
| backgroundColor | `rgb(23, 23, 23)` | `rgb(56, 56, 56)` |
Transitions: backgroundColor 150ms cubic-bezier(0.4, 0, 0.2, 1)

**Focus-visible**: outline `3px none rgb(255, 255, 255)`, offset 0px

## button-secondary-5 (button, ×5)
![button-secondary-5](../assets/reference/button-secondary-5.jpg)
Examples: “Onboard your agent”

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#171717` |
| radius | `3.35544e+07px` |
| shadow | `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(235, 235, 235) 0px 0px 0px 1px` |
| font | `500 16px/24px` |
| family | `GeistSans` |
| padding | `0px 12px 0px 12px` |
| transition | `all 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 40px tall, from 133px wide, padding 0px × 12px.

**Hover**
| property | rest | hover |
|---|---|---|
| backgroundColor | `rgb(255, 255, 255)` | `rgb(242, 242, 242)` |
Transitions: backgroundColor 150ms cubic-bezier(0.4, 0, 0.2, 1)

**Focus-visible**: outline `3px none rgb(23, 23, 23)`, offset 0px, shadow `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(235, 235, 235) 0px 0px 0px 1px`

## footer (footer, ×4)
![footer](../assets/reference/footer.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#171717` |
| font | `400 14px/21px` |
| family | `GeistSans` |
| padding | `40px 24px 40px 24px` |
Size: 846px tall, from 1440px wide, padding 40px × 24px.

## badge (badge, ×2)
![badge](../assets/reference/badge.jpg)
Examples: “.env.local”, “index.ts”

| property | value |
|---|---|
| background | `#f2f2f2` |
| color | `#171717` |
| border | `1px solid #ebebeb` |
| radius | `4px` |
| font | `400 13px/18px` |
| family | `Geist Mono` |
| padding | `1px 3px 1px 3px` |
Size: 21px tall, from 72px wide, padding 1px × 3px.

## badge-2 (badge, ×1)
![badge-2](../assets/reference/badge-2.jpg)
Examples: “primary”

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#4d4d4d` |
| radius | `3.35544e+07px` |
| shadow | `rgba(0, 0, 0, 0.08) 0px 0px 0px 1px, rgba(0, 0, 0, 0.04) 0px 2px 2px 0px, rgb(250, 250, 250) 0px 0px 0px 1px` |
| font | `400 13px/18px` |
| family | `GeistSans` |
| padding | `2px 10px 2px 10px` |
| transition | `all 0.3s cubic-bezier(0.4, 0, 0.2, 1)` |
Size: 22px tall, from 66px wide, padding 2px × 10px.

## badge-3 (badge, ×1)
![badge-3](../assets/reference/badge-3.jpg)
Examples: “fallback”

| property | value |
|---|---|
| background | `#171717` |
| color | `#ffffff` |
| radius | `3.35544e+07px` |
| shadow | `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.04) 0px 2px 2px 0px` |
| font | `400 13px/18px` |
| family | `GeistSans` |
| padding | `2px 10px 2px 10px` |
| transition | `all 0.3s cubic-bezier(0.4, 0, 0.2, 1)` |
Size: 22px tall, from 68px wide, padding 2px × 10px.

## badge-4 (badge, ×1)
![badge-4](../assets/reference/badge-4.jpg)
Examples: “Degraded”

| property | value |
|---|---|
| background | `#f2f2f2` |
| color | `#7d7d7d` |
| border | `1px solid transparent` |
| radius | `3.35544e+07px` |
| font | `500 12px/16px` |
| family | `GeistSans` |
| padding | `2px 10px 2px 10px` |
Size: 22px tall, from 77px wide, padding 2px × 10px.

## input (input, ×1)
![input](../assets/reference/input.jpg)
Examples: “Search models”

| property | value |
|---|---|
| background | `transparent` |
| color | `#171717` |
| font | `400 14px/20px` |
| family | `GeistSans` |
| padding | `0px 0px 0px 0px` |
| cursor | `text` |
Size: 20px tall, from 200px wide, padding 0px × 0px.

**Focus-visible**: outline `1px none rgb(16, 16, 16)`, offset 0px

## input-2 (input, ×1)
![input-2](../assets/reference/input-2.jpg)
Examples: “Sandbox hours value”

| property | value |
|---|---|
| background | `transparent` |
| color | `#171717` |
| radius | `4px` |
| font | `450 24px/32px` |
| family | `Geist Mono` |
| letterSpacing | `-0.96px` |
| padding | `0px 0px 0px 0px` |
| cursor | `text` |
Size: 32px tall, from 126px wide, padding 0px × 0px.

**Focus-visible**: outline `1px none rgb(16, 16, 16)`, offset 0px
