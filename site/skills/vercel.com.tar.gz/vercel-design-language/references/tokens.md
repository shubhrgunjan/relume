# Tokens

## Colour (light scheme, dark mode via class)
Ordered by painted weight (area × use). `aliases` are the source's own custom properties holding the same value.

| token | value | role | share | used for | dark | source aliases |
|---|---|---|---|---|---|---|
| background | `#fafafa` | background | 90.8% | bg | `#000000` | --ds-background-200 --geist-marketing-gray --color-gray-50 |
| text | `#171717` | text | 3.6% | text | `#ededed` | --ds-gray-1000 --color-gray-1000 --geist-selection |
| text-secondary | `#4d4d4d` | text-secondary | 2.8% | text, accent-fill | `#a1a1a1` | --color-gray-900 --ds-gray-900 |
| border | `#ebebeb` | border | 1.1% | gradient, border | `#1f1f1f` | --geist-secondary-lighter --accents-2 --ds-gray-200 |
| accent | `#0072f5` | accent | 0.8% | gradient, accent-fill | `#52a8ff` | --geist-console-text-color-blue --ds-blue-700 --develop-text |
| white-a16 | `rgb(255 255 255 / 0.16)` | palette | 0.2% | gradient | — | — |
| border-2 | `rgb(0 0 0 / 0.08)` | border-2 | 0.1% | shadow, border, bg | — | --ds-gray-alpha-400 --color-gray-alpha-400 --ds-gray-alpha-200 |
| surface | `#101010` | surface | 0.1% | accent-fill | — | --accents-8 |
| indigo-700 | `#52aeff` | palette | 0.1% | gradient | — | --ds-blue-600 |
| text-tertiary | `#297a3a` | text-tertiary | 0.1% | text | — | --ds-green-900 |
| shadow | `rgb(0 0 0 / 0.04)` | shadow | 0.1% | shadow | — | --ds-gray-alpha-100 |
| text-quaternary | `#8f8f8f` | text-quaternary | 0% | text | `#8f8f8f` | --ds-gray-700 --color-gray-700 |
| border-3 | `#f2f2f2` | border-3 | 0% | border, bg | — | --geist-selection-text-color --color-zinc-100 --ds-overlay-backdrop-color |
| surface-2 | `#c9c9c9` | surface-2 | 0% | bg | — | --color-gray-500 --ds-gray-500 |
| indigo-a80 | `rgb(82 174 255 / 0.8)` | palette | 0% | accent-fill | — | — |

### Gradients
- `radial-gradient(rgb(235, 235, 235) 1px, rgba(0, 0, 0, 0) 1px)`
- `linear-gradient(to top in oklab, rgb(250, 250, 250) 0%, rgba(0, 0, 0, 0) 100%)`
- `linear-gradient(to right, rgba(255, 255, 255, 0.16) 1px, rgba(0, 0, 0, 0) 1px), linear-gradient(rgba(255, 255, 255, 0.16) 1px, rgba(0, 0, 0, 0) 1px), linear-gradient(rgb(82, 174, 255), rgb(0, 114, 245) 160%)`
- `linear-gradient(-45deg, rgb(255, 255, 255) 23.2px, rgb(235, 235, 235) 61.2px, rgb(255, 255, 255) 76.2px, rgb(235, 235, 235) 79.2px)`
- `linear-gradient(in oklab, rgb(250, 250, 250) 0%, rgba(0, 0, 0, 0) 100%)`
- `linear-gradient(to top in oklab, rgb(250, 250, 250) 25%, rgba(0, 0, 0, 0) 100%)`
- `linear-gradient(in oklab, rgba(0, 0, 0, 0) 0%, rgb(250, 250, 250) 36%)`
- `linear-gradient(to right, rgb(250, 250, 250) 0%, oklab(0 0 0 / 0) 100%)`

## Typography
| family | share | weights | source | licence | substitute |
|---|---|---|---|---|---|
| GeistSans | 83.4% | 400 450 500 550 | self-hosted | open (Google Fonts) — load it from Google Fonts or self-host | — |
| Geist Mono | 14.6% | 400 | self-hosted | open (Google Fonts) — load it from Google Fonts or self-host | — |

| style | family | size | weight | line-height | tracking | case | share | responsive | sample |
|---|---|---|---|---|---|---|---|---|---|
| h1 | GeistSans | 64px | 450 | 64px (1) | -0.059em | none | 0.4% | — | The AI layer for building frameworks and |
| h1-regular | GeistSans | 64px | 400 | 64px (1) | -0.059em | none | 0.1% | 48→48→64px | Agentic Infrastructure |
| h2 | GeistSans | 56px | 450 | 56px (1) | -0.061em | none | 2.8% | 32→48→56px | Run each sandbox near your users, your d |
| display | GeistSans | 56px | 400 | 56px (1) | -0.061em | none | 0.6% | — | Moving to the gateway is just so ergonom |
| h2-medium | GeistSans | 48px | 450 | 56px (1.167) | -0.06em | none | 0.3% | — | The framework agnostic AI toolkit |
| title-lg | GeistSans | 32px | 400 | 40px (1.25) | -0.041em | none | 1.5% | — | Vercel Sandbox expands what our frontend |
| title | GeistSans | 24px | 550 | 36px (1.5) | 0em | none | 0.5% | — | Modern apps increasingly need to execute |
| h3 | GeistSans | 24px | 450 | 32px (1.333) | -0.042em | none | 1.9% | — | Kimi K3.1 Pro and Kimi K3.1 Pro Highspee |
| title-regular | GeistSans | 24px | 400 | 36px (1.5) | 0em | none | 1.7% | — | to your environment variables, databases |
| title-medium | GeistSans | 20px | 500 | 26px (1.3) | -0.02em | none | 0.4% | — | Chatbot Starter Template |
| title-regular-2 | GeistSans | 20px | 400 | 32px (1.6) | 0em | none | 3.3% | — | What's the difference between using AI G |
| title-regular-3 | GeistSans | 18px | 400 | 28px (1.556) | 0em | none | 12.7% | — | 400+ models at provider speed with near- |
| body-semibold | GeistSans | 16px | 550 | 24px (1.5) | 0em | none | 1% | — | Spin up multiple parallel instances |
| body-medium | GeistSans | 16px | 500 | 24px (1.5) | 0em | none | 0.4% | — | Onboard your agent |
| body-medium-2 | GeistSans | 16px | 450 | 24px (1.5) | 0em | none | 1.1% | — | Route on behavior, fallback anytime. |
| body | GeistSans | 16px | 400 | 24px (1.5) | 0em | none | 30.3% | — | Unified billing and observability across |
| small | GeistSans | 14px | 500 | 20px (1.429) | 0em | none | 6% | — | How Zo Computer improved AI reliability  |
| small-regular | GeistSans | 14px | 400 | 20px (1.429) | 0em | none | 16% | — | The base image already includes , , and  |
| caption | GeistSans | 13px | 400 | 18px (1.385) | 0em | none | 1.7% | — | North America dipped 4% in August. I pos |
| mono-sm | Geist Mono | 13px | 400 | 20px (1.538) | 0em | none | 14.5% | — | Bootstrap a simple Node.js CLI that crea |
| caption-regular | GeistSans | 12px | 400 | 19.5px (1.625) | 0em | none | 0.7% | — | Two particles stay linked, so measuring  |
| mono-sm-regular | Geist Mono | 12px | 400 | 16px (1.333) | 0em | none | 0.1% | — | remote-sandbox.vercel.run |

Scale: ratio 1.072 (minor second), base 16px, fit 0.83. Sizes in use: 12, 13, 14, 16, 18, 20, 24, 32, 48, 56, 64.

## Spacing
Grid 2px (98.6% of measured paddings, margins and gaps sit on it).

| value | share |
|---|---|
| 2px | 33.2% |
| 6px | 15% |
| 12px | 11.6% |
| 8px | 9.4% |
| 16px | 8% |
| 24px | 6.1% |
| 4px | 4.2% |
| 10px | 3% |
| 32px | 2.1% |
| 18px | 1.1% |
| 14px | 0.8% |
| 48px | 0.7% |
| 72px | 0.7% |
| 96px | 0.6% |
| 40px | 0.6% |
| 3px | 0.4% |

## Radii
| radius | count | on |
|---|---|---|
| 9999px | 267 | button, small, surface, media |
| 12px | 64 | surface |
| 6px | 54 | button, small, surface |
| 8px | 34 | surface, small |
| 2px | 30 | small, button, surface |
| 4px | 13 | surface, small, button |
| 20px | 3 | surface |

## Borders
| border | count |
|---|---|
| `1px solid #ebebeb` | 361 |
| `1px solid #e6e6e6` | 118 |
| `1px solid rgb(0 0 0 / 0.08)` | 57 |
| `1px solid rgb(255 255 255 / 0.4)` | 12 |
| `1px solid #a8a8a8` | 8 |
| `1px dashed #ebebeb` | 6 |
| `1px solid #f2f2f2` | 4 |
| `4px solid #171717` | 4 |

## Shadows
| shadow | count | on |
|---|---|---|
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.04) 0px 2px 2px 0px` | 53 | div |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(235, 235, 235) 0px 0px 0px 1px` | 16 | a, button |
| `rgba(0, 0, 0, 0.08) 0px 0px 0px 1px, rgba(0, 0, 0, 0.04) 0px 2px 2px 0px, rgb(250, 250, 250) 0px 0px 0px 1px` | 14 | div |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px` | 10 | div, pre, button |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.08) 0px 0px 0px 1px, rgba(0, 0, 0, 0.04) 0px 2px 2px 0px, rgb(250, 250, 250) 0px 0px 0px 1px` | 9 | span, div, button, a |
| `rgba(0, 0, 0, 0.08) 0px 0px 0px 1px, rgba(0, 0, 0, 0.04) 0px 2px 2px 0px, rgba(0, 0, 0, 0.04) 0px 8px 16px -4px, rgb(250, 250, 250) 0px 0px 0px 1px` | 9 | div |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.08) 0px 0px 0px 1px, rgb(250, 250, 250) 0px 0px 0px 1px` | 7 | a, fieldset |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(255, 255, 255) 0px 0px 0px 1px` | 7 | span |
