# Layout

## Containers
| viewport | content widths (most used first) | gutter |
|---|---|---|
| desktop | 1080px, 640px, 582px, 382px | 24px |
| tablet | 560px, 786px, 444px, 556px | 24px |
| mobile | 342px, 276px, 294px, 267px | 24px |

## Breakpoints (from the stylesheets)
- max-width 960px (×66)
- max-width 600px (×52)
- min-width 601px (×27)
- min-width 961px (×13)
- min-width 401px (×13)
- max-width 768px (×8)
- min-width 1200px (×8)
- min-width 960px (×6)

## Grids
- 12 cols, gap 24px (×55)
- 2 cols, gap normal (×44)
- 2 cols, gap 24px (×44)
- 12 cols, gap 20px (×8)
- 12 cols, gap 0px (×2)
- 5 equal flex columns, gap normal (×1)
- 7 equal flex columns, gap 0px (×1)
- 12 cols, gap 32px (×1)

## Section rhythm
| viewport | section padding-y (common) | median | gap between sections |
|---|---|---|---|
| desktop | 120px, 144px, 96px | 120px | 208px |
| tablet | 96px, 80px, 32px | 96px | 168px |

## Density
- First screen: 68 words, text covers 11.4% of it.
- Home page is 6.7 screens tall at desktop.
