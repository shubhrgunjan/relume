---
name: vercel-design-language
description: "Build UI in the design language measured from vercel.com: Light interface, almost entirely neutral — colour is rationed (chromatic share 1%). Use whenever creating or restyling pages, sections or components that should look and move like vercel.com — colours, type, spacing, components and motion come from measurement, not guesswork."
---

# vercel.com design language

Measured from https://vercel.com (4 pages at desktop, tablet, mobile, desktop-dark) on 2026-10-28 by relume. Every value here was read from the live site — computed styles, stylesheets, animations and a frame-by-frame motion recording — so treat them as facts, not suggestions.

## The feel
- Light interface, almost entirely neutral — colour is rationed (chromatic share 1%).
- Maximum-contrast text (17.2:1).
- Headlines 64px / 450, tightly tracked (-0.059em); body 16px at 1.5 leading.
- Moderately rounded surfaces (6px).
- Layered shadows carry depth.
- Generous vertical rhythm: sections breathe with ~120px padding on desktop.
- Entrances run ~621ms; native scrolling.

## Build to the blueprint first
This language is not only its tokens. Its home page is 7 screens of 6 sections; 30% of it is covered by visuals (2 dataviz, 1 logos, 3 image, 2 cards), at ~28 painted elements per screen. Read `references/blueprint.md` before anything else: it lists every section of the source in order, with a crop, its layout, and what it is made of. A new page must have the same kinds of sections in the same order, filled with the same kinds of things for your product: product UI built in real HTML with the measured UI grammar, illustrations in the source's style, data visualisations, logo rows, testimonial cards. Headings over empty boxes are not this language, and the checker fails them.

## Setup
1. Copy `assets/tokens.css` (plain CSS variables, text styles, component classes, `.container` and `.section` with the measured width, gutters and rhythm — use them, don't re-derive) into the project; with Tailwind v4 also import `assets/tailwind.css` after `@import "tailwindcss"`.
2. Add `assets/motion.css` and `assets/motion.js` (scroll reveals, intro choreography, stagger and scroll feel, all with measured timings).
3. Fonts: **GeistSans** (= Geist on Google Fonts) for h1, h1-regular, h2, display — `var(--font-sans)`; **Geist Mono** for mono-sm, mono-sm-regular — `var(--font-mono)`.
   Load the open ones: `<link href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600&family=Geist+Mono:wght@400&display=swap" rel="stylesheet">`

## Core tokens
- Background #fafafa, text #171717 / #4d4d4d / #297a3a, accent #0072f5, surface #101010, border #ebebeb. A dark scheme exists (class).
- Type scale ≈1.072 (minor second) from 16px: h1 64/450, h1-regular 64/400, h2 56/450, display 56/400, h2-medium 48/450, title-lg 32/400, title 24/550, h3 24/450.
- Radii 9999px, 12px, 6px, 8px, 2px. Spacing grid 2px. Container 1080px, gutters 24 / 24 / 24px (desktop / tablet / mobile).
- Motion: 150ms, 300ms, 1250ms, 100ms, 500ms; curves `cubic-bezier(0.4, 0, 0.2, 1)`, `cubic-bezier(0.4, 0.04, 0.04, 1)`, `cubic-bezier(0, 0, 0.2, 1)`. Scroll: native.
- Primary action: #171717 / #ffffff, radius 0, 450 12px/16px.

## Do
- Use only the colour tokens in `assets/tokens.css`; the accent (#0072f5) covers ≤2% of any screen.
- Set text with the named styles (`.text-body`, `.text-h1` …); never invent sizes between them.
- Space on the 2px grid (2, 6, 12, 8, 16, 24 are the workhorses); sections get ~120px vertical padding on desktop.
- Reuse the measured shadows verbatim; they are layered, not single blurs.

## Don't
- Do not use radii outside 9999px, 12px, 6px, 8px, 2px.
- Do not use durations or curves that are not in the motion tokens (150ms, 300ms, 1250ms, 100ms, 500ms).
- Do not add smooth-scroll libraries; the source scrolls natively.
- Do not copy the source’s logo, product names, photography, illustrations or copy; describe your own product in this language.

## Motion signature
- **intro-tint-1** (load, ×3): color: rgb(77, 77, 77); → color: rgb(23, 23, 23); over 150ms `cubic-bezier(0.4, 0, 0.2, 1)`, stagger 302ms.
- **intro-strokedashoffset-2** (load, ×2): stroke-dashoffset: 1px; → stroke-dashoffset: 0px; over 260ms `linear`.
- **intro-fade-3** (load): opacity: 0; → opacity: 1; over 1200ms `linear`.
- **intro-fade-out-4** (load): opacity: 1; → opacity: 0; over 700ms `linear`.
- **intro-fade-5** (load): opacity: 0; → opacity: 1; over 200ms `ease-out`.
- **intro-fade-6** (load): opacity: 0; → opacity: 1; over 300ms `cubic-bezier(0.4, 0, 0.2, 1)`.

## Workflow
1. Read `references/tokens.md` and `references/components.md` before writing UI; open the images in `assets/reference/` to see the look.
2. Build with the component classes and text styles; take motion from `references/motion.md` (exact CSS per pattern).
3. Run `node scripts/lint.mjs <your files…>` and fix every off-system colour, size, radius, duration and curve it reports.
4. If the relume MCP server is connected, call `check_style` with your page's URL: it re-measures your page and compares its DNA (composition, tokens and motion) with this one. Fix what it reports until it passes.

## References
- `references/blueprint.md` — the page, section by section: order, layout, contents, density, crops, and the UI grammar of the product mock-ups.
- `references/tokens.md` — every colour (with dark values and the source’s own variable names), text style (with fluid sizes), spacing, radius, border, shadow, gradient.
- `references/components.md` — buttons, links, inputs, cards, badges, navigation, footer: resting style, hover/focus states and transitions.
- `references/motion.md` — scroll feel, intro choreography, scroll reveals, hover motion, loops; exact CSS.
- `references/layout.md` — containers, gutters, grids, breakpoints, section rhythm, density.
- `assets/DESIGN.md` — the same system in Google's DESIGN.md format, for other tools.
