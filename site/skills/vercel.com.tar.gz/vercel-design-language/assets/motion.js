// Motion runtime measured from https://vercel.com by relume. Import once on every page.
// Scroll reveals start when an element's top crosses the measured fraction of the viewport height.
const ENTRY = {"reveal-fade-up-8":0.85,"reveal-fade-out-9":0.35,"reveal-tint-10":0.2,"reveal-tint-11":0.47,"reveal-tint-12":0.27,"reveal-fade-13":0.85,"reveal-fade-out-14":0.98,"reveal-fade-out-15":0.97,"reveal-fade-16":0.85,"reveal-fade-scale-17":0.17,"reveal-fade-tint-18":0.85,"reveal-fade-19":0.85,"reveal-fade-20":0.25,"reveal-fade-21":0.85,"reveal-fade-22":0.35,"reveal-fade-23":0.85,"reveal-tint-24":0.85,"reveal-tint-25":0.85,"reveal-fade-out-scale-26":0.63,"reveal-fade-out-27":0.43,"reveal-fade-out-28":0.47};
const DEFAULT_ENTRY = 0.63;

export function initReveals(root = document) {
  const els = [...root.querySelectorAll('[data-reveal]')];
  const byEntry = new Map();
  for (const el of els) {
    const e = ENTRY[el.dataset.reveal] ?? DEFAULT_ENTRY;
    if (!byEntry.has(e)) byEntry.set(e, []);
    byEntry.get(e).push(el);
  }
  for (const [entry, list] of byEntry) {
    const io = new IntersectionObserver((records) => {
      for (const r of records) if (r.isIntersecting) { r.target.classList.add('is-in'); io.unobserve(r.target); }
    }, { rootMargin: `0px 0px ${-Math.round((1 - entry) * 100)}% 0px` });
    list.forEach((el) => io.observe(el));
  }
}


// The source scrolls natively (one wheel notch = 100px, no smoothing). Keep it that way.
export function initSmoothScroll() { return null; }

export function initMotion() {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) { document.querySelectorAll('[data-reveal]').forEach((el) => el.classList.add('is-in')); return; }
  initSmoothScroll();
  initReveals();
}

if (typeof window !== 'undefined') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initMotion); else initMotion();
}
