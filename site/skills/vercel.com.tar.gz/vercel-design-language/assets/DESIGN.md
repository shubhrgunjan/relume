---
name: vercel.com
colors:
  background: "#fafafa"
  text: "#171717"
  text-secondary: "#4d4d4d"
  border: "#ebebeb"
  accent: "#0072f5"
  white-a16: "rgb(255 255 255 / 0.16)"
  border-2: "rgb(0 0 0 / 0.08)"
  surface: "#101010"
  indigo-700: "#52aeff"
  text-tertiary: "#297a3a"
  shadow: "rgb(0 0 0 / 0.04)"
  text-quaternary: "#8f8f8f"
  border-3: "#f2f2f2"
  surface-2: "#c9c9c9"
  indigo-a80: "rgb(82 174 255 / 0.8)"
typography:
  h1:
    fontFamily: "GeistSans"
    fontSize: 64px
    fontWeight: 450
    lineHeight: 1
    letterSpacing: -0.059em
  h1-regular:
    fontFamily: "GeistSans"
    fontSize: 64px
    fontWeight: 400
    lineHeight: 1
    letterSpacing: -0.059em
  h2:
    fontFamily: "GeistSans"
    fontSize: 56px
    fontWeight: 450
    lineHeight: 1
    letterSpacing: -0.061em
  display:
    fontFamily: "GeistSans"
    fontSize: 56px
    fontWeight: 400
    lineHeight: 1
    letterSpacing: -0.061em
  h2-medium:
    fontFamily: "GeistSans"
    fontSize: 48px
    fontWeight: 450
    lineHeight: 1.167
    letterSpacing: -0.06em
  title-lg:
    fontFamily: "GeistSans"
    fontSize: 32px
    fontWeight: 400
    lineHeight: 1.25
    letterSpacing: -0.041em
  title:
    fontFamily: "GeistSans"
    fontSize: 24px
    fontWeight: 550
    lineHeight: 1.5
    letterSpacing: 0em
  h3:
    fontFamily: "GeistSans"
    fontSize: 24px
    fontWeight: 450
    lineHeight: 1.333
    letterSpacing: -0.042em
  title-regular:
    fontFamily: "GeistSans"
    fontSize: 24px
    fontWeight: 400
    lineHeight: 1.5
    letterSpacing: 0em
  title-medium:
    fontFamily: "GeistSans"
    fontSize: 20px
    fontWeight: 500
    lineHeight: 1.3
    letterSpacing: -0.02em
  title-regular-2:
    fontFamily: "GeistSans"
    fontSize: 20px
    fontWeight: 400
    lineHeight: 1.6
    letterSpacing: 0em
  title-regular-3:
    fontFamily: "GeistSans"
    fontSize: 18px
    fontWeight: 400
    lineHeight: 1.556
    letterSpacing: 0em
  body-semibold:
    fontFamily: "GeistSans"
    fontSize: 16px
    fontWeight: 550
    lineHeight: 1.5
    letterSpacing: 0em
  body-medium:
    fontFamily: "GeistSans"
    fontSize: 16px
    fontWeight: 500
    lineHeight: 1.5
    letterSpacing: 0em
rounded:
  full: 9999px
  md: 12px
  lg: 6px
  xl: 8px
  2xl: 2px
  3xl: 4px
spacing:
  "1": 2px
  "2": 4px
  "3": 6px
  "4": 8px
  "5": 10px
  "6": 12px
  "7": 16px
  "8": 24px
components:
  card:
    backgroundColor: "transparent"
    textColor: "#171717"
    rounded: 2px
    padding: 32px 32px 32px 32px
  card-2:
    backgroundColor: "#ffffff"
    textColor: "#171717"
    rounded: 8px
    padding: 16px 0px 16px 0px
  card-3:
    backgroundColor: "#ffffff"
    textColor: "#171717"
    rounded: 12px
    padding: 0px 0px 0px 0px
  card-4:
    backgroundColor: "#ffffff"
    textColor: "#171717"
    padding: 0px 0px 0px 0px
  card-5:
    backgroundColor: "transparent"
    textColor: "#171717"
    padding: 0px 0px 0px 0px
  card-6:
    backgroundColor: "linear-gradient(to top in oklab, rgb(250, 250, 250) 0%, rgba(0, 0, 0, 0) 100%)"
    textColor: "#171717"
    padding: 0px 0px 0px 0px
---

# vercel.com

## Overview
Light interface, almost entirely neutral — colour is rationed (chromatic share 1%). Maximum-contrast text (17.2:1). Headlines 64px / 450, tightly tracked (-0.059em); body 16px at 1.5 leading. Moderately rounded surfaces (6px). Layered shadows carry depth. Generous vertical rhythm: sections breathe with ~120px padding on desktop. Entrances run ~621ms; native scrolling.

## Colors
- **background** `#fafafa` — background
- **text** `#171717` — text
- **text-secondary** `#4d4d4d` — text-secondary
- **border** `#ebebeb` — border
- **accent** `#0072f5` — accent
- **white-a16** `rgb(255 255 255 / 0.16)` — palette
- **border-2** `rgb(0 0 0 / 0.08)` — border-2
- **surface** `#101010` — surface
- **indigo-700** `#52aeff` — palette
- **text-tertiary** `#297a3a` — text-tertiary

## Typography
- GeistSans
- Geist Mono

## Motion
Durations 150ms, 300ms, 1250ms, 100ms, 500ms; curves cubic-bezier(0.4, 0, 0.2, 1), cubic-bezier(0.4, 0.04, 0.04, 1), cubic-bezier(0, 0, 0.2, 1).

## Do's and Don'ts
- Use the tokens above only.
- Keep motion within the measured durations and curves.
- Never reuse the source brand’s logo, imagery or copy.
