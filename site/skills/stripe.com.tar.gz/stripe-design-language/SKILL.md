---
name: stripe-design-language
description: "Build UI in the design language measured from stripe.com: Light interface, mostly neutral with a restrained accent (chromatic share 9.9%). Use whenever creating or restyling pages, sections or components that should look and move like stripe.com — colours, type, spacing, components and motion come from measurement, not guesswork."
---

# stripe.com design language

Measured from https://stripe.com (2 pages at desktop, tablet, mobile, desktop-dark) on 2026-10-28 by relume. Every value here was read from the live site — computed styles, stylesheets, animations and a frame-by-frame motion recording — so treat them as facts, not suggestions.

## The feel
- Light interface, mostly neutral with a restrained accent (chromatic share 9.9%).
- Maximum-contrast text (16.4:1).
- Headlines 56px / 500, tightly tracked (-0.02em); body 15px at 1.6 leading.
- Crisp, near-square geometry (0px).
- Layered shadows carry depth.
- Translucent, blurred (glass) layers are part of the language.
- Entrances run ~830ms; native scrolling.

## Build to the blueprint first
This language is not only its tokens. Its home page is 16 screens of 12 sections; 21% of it is covered by visuals (5 dataviz, 4 logos, 5 ui-mock, 6 cards, 4 image, 2 avatar), at ~44 painted elements per screen. Read `references/blueprint.md` before anything else: it lists every section of the source in order, with a crop, its layout, and what it is made of. A new page must have the same kinds of sections in the same order, filled with the same kinds of things for your product: product UI built in real HTML with the measured UI grammar, illustrations in the source's style, data visualisations, logo rows, testimonial cards. Headings over empty boxes are not this language, and the checker fails them.

## Setup
1. Copy `assets/tokens.css` (plain CSS variables, text styles, component classes, `.container` and `.section` with the measured width, gutters and rhythm — use them, don't re-derive) into the project; with Tailwind v4 also import `assets/tailwind.css` after `@import "tailwindcss"`.
2. Add `assets/motion.css` and `assets/motion.js` (scroll reveals, intro choreography, stagger and scroll feel, all with measured timings).
3. Fonts: **sohne-var** (use **Inter** unless you hold a licence) for h1, h2, display, h1-medium — `var(--font-sans)`.
   Load the open ones: `<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500&display=swap" rel="stylesheet">`

## Core tokens
- Background #f6f9fc, text #061b31 / #0a2540 / #425466, accent rgb(84 82 251 / 0.75), surface #ffffff, border #e7ecf1.
- Type scale ≈1.081 from 15px: h1 56/500, h2 56/300, display 48/300, h1-medium 38/500, title-lg 32/300, h1-medium-2 26/500, title-lg-light 26/300, h1-medium-3 24/500.
- Radii 4px, 6px, 9999px, 8px. Spacing grid 4px. Container 1080px, gutters 16 / 16 / 16px (desktop / tablet / mobile).
- Motion: 300ms, 150ms, 250ms, 500ms, 1420ms; curves `cubic-bezier(0.25, 1, 0.5, 1)`, `cubic-bezier(0.215, 0.61, 0.355, 1)`, `ease`. Scroll: native.
- Primary action: #635bff / #ffffff, radius 16.5px, 425 15px/24px; on hover backgroundColor → rgb(10, 37, 64), opacity → 0.6.

## Do
- Use only the colour tokens in `assets/tokens.css`; the accent (rgb(84 82 251 / 0.75)) covers ≤1% of any screen.
- Set text with the named styles (`.text-body`, `.text-h1` …); never invent sizes between them.
- Space on the 4px grid (4, 16, 8, 24, 32, 12 are the workhorses); sections get ~—px vertical padding on desktop.
- Reuse the measured shadows verbatim; they are layered, not single blurs.
- Floating chrome (nav, popovers) uses the measured backdrop blur over a translucent fill.

## Don't
- Do not use radii outside 4px, 6px, 9999px, 8px.
- Do not use durations or curves that are not in the motion tokens (300ms, 150ms, 250ms, 500ms, 1420ms).
- Do not add smooth-scroll libraries; the source scrolls natively.
- Do not copy the source’s logo, product names, photography, illustrations or copy; describe your own product in this language.

## Motion signature
- **intro-fade-out-1** (load, ×79): opacity: 1; → opacity: 0; over 150ms `cubic-bezier(0.25, 1, 0.5, 1)`.
- **intro-fade-out-2** (load, ×34): opacity: 1; → opacity: 0; over 250ms `ease`.
- **intro-up-3** (load, ×17): transform: translateY(0%); → transform: translateY(-100%); over 1420ms `ease-in-out`, delay 4000ms.
- **intro-fade-scale-4** (load, ×10): transform: scaleY(0); opacity: 0; → transform: scaleY(1); opacity: 1; over 1300ms `ease-out`, delay 200ms.
- **intro-tint-5** (load, ×6): color: rgb(100, 128, 178); → color: rgb(125, 139, 164); over 300ms `cubic-bezier(0.25, 1, 0.5, 1)`.
- **intro-tint-6** (load, ×6): background-color: rgba(0, 0, 0, 0); border-bottom-color: rgb(214, 217, 252); border-left-color: rgb(214, 217, 252); border-right-color: rgb(214, 217, 252); border-color: rgb(214, 217, 252); width: 50px; → background-color: rgb(226, 228, 255); border-bottom-color: rgb(226, 228, 255); border-left-color: rgb(226, 228, 255); border-right-color: rgb(226, 228, 255); border-color: rgb(226, 228, 255); width: 40px; over 400ms `cubic-bezier(0.3, 0, 0.2, 1)`.

## Workflow
1. Read `references/tokens.md` and `references/components.md` before writing UI; open the images in `assets/reference/` to see the look.
2. Build with the component classes and text styles; take motion from `references/motion.md` (exact CSS per pattern).
3. Run `node scripts/lint.mjs <your files…>` and fix every off-system colour, size, radius, duration and curve it reports.
4. If the relume MCP server is connected, call `check_style` with your page's URL: it re-measures your page and compares its DNA (composition, tokens and motion) with this one. Fix what it reports until it passes.

## References
- `references/blueprint.md` — the page, section by section: order, layout, contents, density, crops, and the UI grammar of the product mock-ups.
- `references/tokens.md` — every colour (with dark values and the source’s own variable names), text style (with fluid sizes), spacing, radius, border, shadow, gradient.
- `references/components.md` — buttons, links, inputs, cards, badges, navigation, footer: resting style, hover/focus states and transitions.
- `references/motion.md` — scroll feel, intro choreography, scroll reveals, hover motion, loops; exact CSS.
- `references/layout.md` — containers, gutters, grids, breakpoints, section rhythm, density.
- `assets/DESIGN.md` — the same system in Google's DESIGN.md format, for other tools.
