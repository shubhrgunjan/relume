# Layout

## Containers
| viewport | content widths (most used first) | gutter |
|---|---|---|
| desktop | 1080px, 1266px, 1232px, 400px | 16px |
| tablet | 802px, 768px, 356px, 770px | 16px |
| mobile | 358px, 326px, 294px, 356px | 16px |

## Breakpoints (from the stylesheets)
- min-width 640px (×210)
- min-width 940px (×125)
- max-width 639px (×45)
- min-width 600px (×37)
- min-width 900px (×25)
- max-width 939px (×15)
- max-width 599px (×5)
- max-width 899px (×5)

## Grids
- 4 cols, gap normal (×26)
- 2 cols, gap normal (×22)
- 2 cols, gap 32px (×9)
- 12 cols, gap 16px (×8)
- 3 cols, gap normal (×7)
- 2 cols, gap 10px (×5)
- 3 cols, gap 16px (×3)
- 4 cols, gap 16px (×3)

## Section rhythm
| viewport | section padding-y (common) | median | gap between sections |
|---|---|---|---|
| mobile | 32px | 32px | 1px |

## Density
- First screen: 112 words, text covers 45.1% of it.
- Home page is 16.2 screens tall at desktop.
