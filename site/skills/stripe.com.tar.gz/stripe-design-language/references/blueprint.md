# Blueprint

Every section of the measured pages, top to bottom. Build the same kinds of sections in the same order for your product. "Made of" is what fills the section; recreate each block in kind (your content, the source's grammar). Crops are in `assets/reference/sections/`.

## UI grammar (product mock-ups)
Measured inside 5 product UI panels. Build mock-ups as real HTML with these numbers, never as a picture or an empty box.

| what | measured |
|---|---|
| panel surface | background rgb(255, 255, 255), radius 0px, border 0px rgb(0, 0, 0) |
| label sizes (px, count) | 10 (132), 11 (30), 9 (19), 8 (12), 26 (6), 12 (5) |
| list row heights (px, count) | 42 (5), 29 (2), 36 (2), 34 (2), 40 (1), 30 (1) |
| icon sizes (px, count) | 9 (10), 16 (7), 14 (6), 11 (4) |
| avatar | — |
| chips | 19px tall, radius 4.51px, 400 11px; e.g. save |
| sidebar width | 285px |
| text colours (count) | rgb(6, 27, 49) (65), rgb(80, 97, 122) (65), rgb(100, 116, 141) (22), rgb(60, 79, 105) (16), rgb(39, 57, 81) (15) |
| status colours | — |

## in — 14613px, 12 sections, visuals 21%, 44 elements/screen

### 01 · hero
![hero](../assets/reference/sections/in-00.jpg)
- layout: **hero**; 76px tall; visuals cover 0%; 14 painted elements
- made of: text only (56 characters)

### 02 · data visualisation
![data visualisation](../assets/reference/sections/in-01.jpg)
- layout: **stacked**; 685px tall; visuals cover 80%; 66 painted elements; background rgb(255, 255, 255)
- heading: “Financial infrastructure to grow your revenue.” — 48px / 300, at x 208, 929px wide
- made of: **dataviz** (canvas 1393×761, at 337/0/1393/761); **logos** (36 marks in a row, at 74/708/6162/34)

### 03 · content
![content](../assets/reference/sections/in-02.jpg)
- layout: **stacked**; 2196px tall; visuals cover 0%; 0 painted elements
- made of: text only (0 characters)

### 04 · statement
![statement](../assets/reference/sections/in-03.jpg)
- layout: **stacked**; 106px tall; visuals cover 0%; 2 painted elements
- heading: “Flexible solutions for every business model.” — 32px / 300, at x 104, 586px wide
- made of: text only (165 characters)

### 05 · product UI showcase
![product UI showcase](../assets/reference/sections/in-04.jpg)
- layout: **stacked**, 2 columns; 1834px tall; visuals cover 93%; 293 painted elements
- heading: “Accept and optimise payments globally – online and in person” — 26px / 300, at x 128, 654px wide
- made of: **ui-mock** (37 UI labels, 16 icons, ~16 rows, at 371/2510/296/326); **ui-mock** (46 UI labels, 11 icons, ~14 rows, at 523/2461/716/423); **ui-mock** (74 UI labels, 23 icons, ~37 rows, at 402/1218/618/539); **ui-mock** (84 UI labels, 31 icons, ~25 rows, at 99/2409/1243/454); **ui-mock** (78 UI labels, 25 icons, ~41 rows, at 99/1023/826/684); **dataviz** (canvas 447×728, at 80/1693/447/728); **dataviz** (canvas 447×728, at 496/1693/447/728); **dataviz** (canvas 447×728, at 912/1693/447/728); **cards** (2 × 409×690, at 931/1020/409/690); **cards** (2 × 409×690, at 99/1712/409/690); **cards** (2 × 409×690, at 515/1712/409/690); **cards** (2 × 409×690, at 931/1712/409/690)

### 06 · content
![content](../assets/reference/sections/in-05.jpg)
- layout: **stacked**; 560px tall; visuals cover 64%; 4 painted elements; background rgb(255, 255, 255)
- heading: “Building the economic infrastructure for AI” — 48px / 300, at x 128, 660px wide
- made of: **image** (1232×400, at 104/3037/1232/400); **image** (1232×400, at 104/3037/1232/400)

### 07 · content
![content](../assets/reference/sections/in-06.jpg)
- layout: **centered**; 977px tall; visuals cover 5%; 11 painted elements; background rgb(255, 255, 255)
- heading: “The backbone of global commerce” — 56px / 300, at x 482, 476px wide
- made of: **logos** (4 marks in a row, at 192/3833/1084/48)

### 08 · card row
![card row](../assets/reference/sections/in-07.jpg)
- layout: **stacked**, 2 columns; 4530px tall; visuals cover 13%; 158 painted elements; background rgb(255, 255, 255)
- heading: “Powering businesses of all sizes.” — 32px / 300, at x 104, 441px wide
- made of: **image** (1232×531, at 104/5040/1232/531); **image** (1232×531, at 104/5040/1232/531); **logos** (8 marks in a row, at 124/6939/2575/60); **logos** (4 marks in a row, at 183/8908/1074/36); **cards** (2 × 610×170, at 103/7194/610/170); **cards** (2 × 610×170, at 727/7194/610/170)

### 09 · content
![content](../assets/reference/sections/in-08.jpg)
- layout: **stacked**; 2341px tall; visuals cover 0%; 30 painted elements; background rgb(13, 23, 56)
- heading: “500m+” — 48px / 300, at x 104, 152px wide
- made of: text only (1146 characters)

### 10 · data visualisation
![data visualisation](../assets/reference/sections/in-09.jpg)
- layout: **stacked**; 1766px tall; visuals cover 24%; 22 painted elements; background rgb(255, 255, 255)
- heading: “What's happening” — 32px / 300, at x 104, 349px wide
- made of: **dataviz** (canvas 1232×460, at 104/11596/1232/460); **avatar** (32px, at 889/12920/32/32); **avatar** (32px, at 889/12920/32/32)

### 11 · call to action
![call to action](../assets/reference/sections/in-10.jpg)
- layout: **stacked**; 380px tall; visuals cover 0%; 16 painted elements; background rgb(248, 250, 253)
- heading: “Ready to get started?” — 32px / 300, at x 104, 456px wide
- made of: text only (302 characters)

### 12 · footer
![footer](../assets/reference/sections/in-11.jpg)
- layout: **stacked**; 1102px tall; visuals cover 0%; 100 painted elements; background rgb(248, 250, 253)
- made of: text only (1218 characters)

## in-pricing — 12073px, 8 sections, visuals 11%, 47 elements/screen

### 01 · hero
![hero](../assets/reference/sections/in-pricing-00.jpg)
- layout: **hero**; 76px tall; visuals cover 0%; 20 painted elements; background rgb(246, 249, 252)
- made of: text only (63 characters)

### 02 · card row
![card row](../assets/reference/sections/in-pricing-01.jpg)
- layout: **stacked**, 2 columns; 785px tall; visuals cover 0%; 27 painted elements
- heading: “Pricing built for businesses of all sizes” — 56px / 500, at x 196, 682px wide
- made of: **cards** (2 × 262×149, at 446/364/262/303); **tabs** (5 sub-feature links, at 0/606/1440/255)

### 03 · content
![content](../assets/reference/sections/in-pricing-02.jpg)
- layout: **stacked**; 1022px tall; visuals cover 0%; 75 painted elements
- heading: “Features available out of the box:” — 26px / 500, at x 196, 682px wide
- made of: text only (869 characters)

### 04 · product UI showcase
![product UI showcase](../assets/reference/sections/in-pricing-03.jpg)
- layout: **columns**, 5 columns; 5537px tall; visuals cover 17%; 277 painted elements
- heading: “Explore pricing for the full Stripe platform” — 38px / 500, at x 196, 730px wide
- made of: **cards** (5 × 810×166, at 450/2288/810/1298); **cards** (2 × 810×176, at 450/4995/810/327); **ui-mock** (13 UI labels (panel), at 450/2060/810/1640)

### 05 · testimonials
![testimonials](../assets/reference/sections/in-pricing-04.jpg)
- layout: **split**; 2184px tall; visuals cover 17%; 102 painted elements
- heading: “Join leading enterprises on Stripe” — 38px / 500, at x 196, 412px wide
- made of: **illustration** (svg, 16 shapes, at 934/8083/270/356); **image** (834×433, at 438/8614/834/433); **image** (834×433, at 438/8614/834/433); **logos** (4 marks in a row, at 215/9110/1010/40); **testimonial** (quote card 1080×386, rgb(246, 249, 252), at 180/8018/1080/386)

### 06 · statement
![statement](../assets/reference/sections/in-pricing-05.jpg)
- layout: **stacked**; 706px tall; visuals cover 0%; 20 painted elements
- heading: “FAQs” — 38px / 500, at x 196, 682px wide
- made of: text only (162 characters)

### 07 · content
![content](../assets/reference/sections/in-pricing-06.jpg)
- layout: **split**; 649px tall; visuals cover 0%; 21 painted elements
- heading: “Ready to get started? Get in touch or create an account.” — 26px / 500, at x 196, 412px wide
- made of: text only (793 characters)

### 08 · footer
![footer](../assets/reference/sections/in-pricing-07.jpg)
- layout: **stacked**; 1420px tall; visuals cover 0%; 95 painted elements
- made of: text only (1094 characters)
