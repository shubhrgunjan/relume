# Tokens

## Colour (light scheme)
Ordered by painted weight (area × use). `aliases` are the source's own custom properties holding the same value.

| token | value | role | share | used for | dark | source aliases |
|---|---|---|---|---|---|---|
| background | `#f6f9fc` | background | 41% | bg | — | --hds-color-util-bg-quiet --hds-color-util-neutral-25 --hds-color-surface-bg-subdued |
| surface | `#ffffff` | surface | 39.6% | bg | — | --hds-color-util-bg-min --hds-color-action-text-onSolid --hds-color-core-neutral-0 |
| surface-2 | `#e5edf5` | surface-2 | 4.2% | bg, gradient | — | --hds-color-util-neutral-50 --hds-color-surface-border-quiet --hds-canary-ui-mini-stroke |
| violet-100 | `#0d1738` | palette | 3.2% | bg | — | --hds-color-core-neutralDark-990 |
| text-quaternary | `#64748d` | text-quaternary | 0.8% | text | — | --hds-color-heading-subdued --hds-color-icon-subdued --hds-color-util-text-subdued |
| text-tertiary | `#425466` | text-tertiary | 0.8% | text | — | — |
| text | `#061b31` | text | 0.8% | text | — | --hds-color-heading-solid --hds-color-util-neutral-990 --hds-color-util-text-solid |
| text-secondary | `#0a2540` | text-secondary | 0.8% | text, accent-fill | — | — |
| blue-700 | `#42b0d5` | palette | 0.7% | bg | — | — |
| surface-3 | `rgb(248 250 253 / 0.45)` | surface-3 | 0.7% | bg | — | — |
| indigo-400 | `#50617a` | palette | 0.6% | text, accent-fill | — | --hds-color-util-text-soft --hds-color-action-icon-navigation-soft --hds-color-core-neutral-600 |
| violet-600 | `#7f7dfc` | palette | 0.5% | gradient | — | --hds-color-core-brand-400 --hds-color-util-brand-400 --hds-color-input-bg-selectorActive |
| pink-600 | `#f44bcc` | palette | 0.5% | gradient | — | --hds-color-core-magenta-350 --hds-color-accentColorMode-magenta-icon-solidAlt --hds-color-accentColorMode-magenta-icon-solid |
| amber-800 | `#ffa577` | palette | 0.3% | gradient | — | — |
| red-700 | `#ff90a1` | palette | 0.3% | gradient | — | — |
| violet-800 | `#ddadff` | palette | 0.3% | gradient | — | — |
| violet-900 | `#ecd8ff` | palette | 0.3% | gradient | — | — |
| violet-900-2 | `#f5eaff` | palette | 0.3% | gradient | — | — |
| violet-400 | `#533afd` | palette | 0.3% | accent-fill, text | — | --hds-color-accent-border-solid --hds-color-input-icon-solidAlternate --hds-color-accent-charm-bg |
| yellow-700 | `#efa82e` | palette | 0.3% | bg | — | — |
| orange-500 | `#c54647` | palette | 0.3% | bg | — | — |
| indigo-300 | `#004377` | palette | 0.3% | bg | — | — |
| violet-500 | `#635bff` | palette | 0.3% | text, accent-fill, bg | — | --hds-canary-color-border-focus |
| surface-4 | `#f2f7fe` | surface-4 | 0.3% | bg | — | --hds-color-core-neutralDark-25 |
| indigo-600 | `#839bc8` | palette | 0.2% | text | — | --hds-color-core-neutralDark-400 |
| accent | `rgb(84 82 251 / 0.75)` | accent | 0.2% | accent-fill | — | --hds-color-action-focus-outerSoft --hds-color-core-brand-400A |
| indigo-500 | `#727f96` | palette | 0.2% | text, accent-fill | — | — |
| border | `#e7ecf1` | border | 0.2% | border, accent-fill | — | — |
| lime-700 | `#81b81a` | palette | 0.2% | text | — | — |
| violet-a50 | `rgb(0 14 255 / 0.5)` | palette | 0.2% | text | — | — |
| indigo-200 | `#0c2e4e` | palette | 0.2% | bg | — | — |
| indigo-300-2 | `#3f4b66` | palette | 0.1% | text | — | — |
| black-50 | `#101010` | palette | 0.1% | accent-fill | — | — |
| indigo-300-3 | `#1f4468` | palette | 0.1% | bg | — | — |
| yellow-900 | `#ffcf5e` | palette | 0.1% | gradient | — | — |
| violet-a80 | `rgb(83 58 253 / 0.8)` | palette | 0.1% | gradient | — | — |
| pink-a80 | `rgb(243 99 243 / 0.8)` | palette | 0.1% | gradient | — | — |
| violet-200 | `#2d2564` | palette | 0.1% | text | — | — |
| indigo-300-4 | `#3c4f69` | palette | 0.1% | text | — | --hds-color-util-neutral-700 --hds-color-core-neutral-700 |
| indigo-600-2 | `#7d8ba4` | palette | 0% | text | — | --hds-color-input-text-placeholder --hds-color-input-border-option --hds-color-util-text-quiet |

### Gradients
- `radial-gradient(circle, rgb(127, 125, 252), rgb(244, 75, 204) 33%, rgb(229, 237, 245) 66%)`
- `radial-gradient(103.12% 100% at 50% 100%, rgb(255, 165, 119) 0px, rgb(255, 144, 161) 15.52%, rgb(221, 173, 255) 30.09%, rgb(236, 216, 255) 45.72%, rgb(245, 234, 255) 54.96%, rgb(248, 250, 253) 88.16%)`
- `radial-gradient(50% 50%, rgb(255, 207, 94) 41.35%, rgba(255, 207, 94, 0) 100%)`
- `radial-gradient(50% 50%, rgba(83, 58, 253, 0.8) 62.5%, rgba(83, 58, 253, 0) 100%)`
- `radial-gradient(50% 50%, rgba(243, 99, 243, 0.8) 53.85%, rgba(243, 99, 243, 0) 100%)`
- `linear-gradient(rgb(255, 255, 255) 41.35%, rgba(255, 255, 255, 0))`
- `radial-gradient(circle, rgb(247, 45, 243), rgb(83, 58, 253) 33%, rgb(229, 237, 245) 66%)`
- `radial-gradient(circle, rgb(255, 173, 0), rgb(255, 118, 0) 33%, rgb(229, 237, 245) 66%)`

## Typography
| family | share | weights | source | licence | substitute |
|---|---|---|---|---|---|
| sohne-var | 98.6% | 300 400 425 500 | self-hosted | likely commercial — do not copy the font files; license it or use the substitute | Inter |

| style | family | size | weight | line-height | tracking | case | share | responsive | sample |
|---|---|---|---|---|---|---|---|---|---|
| h1 | sohne-var | 56px | 500 | 68px (1.214) | -0.02em | none | 0.2% | — | Pricing built for businesses of all size |
| h2 | sohne-var | 56px | 300 | 57.7px (1.03) | -0.025em | none | 0.1% | 34→48→56px | The backbone of global commerce |
| display | sohne-var | 48px | 300 | 55.2px (1.15) | -0.021em | none | 1.6% | 28→40→48px | Accept payments, offer financial service |
| h1-medium | sohne-var | 38px | 500 | 48px (1.263) | -0.005em | none | 0.3% | — | Explore pricing for the full Stripe plat |
| title-lg | sohne-var | 32px | 300 | 35.2px (1.1) | -0.019em | none | 1.8% | 22→28→32px | Grow your business with a comprehensive  |
| h1-medium-2 | sohne-var | 26px | 500 | 36px (1.385) | 0em | none | 2.1% | — | See how Maersk tapped into new technolog |
| title-lg-light | sohne-var | 26px | 300 | 29.1px (1.119) | -0.012em | none | 6.5% | 20→22→26px | With Stripe, we have a global technology |
| h1-medium-3 | sohne-var | 24px | 500 | 31.9px (1.329) | 0.008em | none | 0.1% | — | Millions |
| h1-medium-4 | sohne-var | 23px | 500 | 28px (1.217) | 0em | none | 0.1% | — | The Total Economic Impact™ Of Stripe |
| title | sohne-var | 22px | 300 | 24.2px (1.1) | -0.009em | none | 6.9% | 18→20→22px | Our annual letter explores the trends de |
| h2-medium | sohne-var | 18px | 500 | 28px (1.556) | 0.011em | none | 0.2% | — | Standard pricing for all products |
| h1-regular | sohne-var | 18px | 425 | 24px (1.333) | 0.011em | none | 0.3% | — | Build your custom package |
| title-light | sohne-var | 18px | 300 | 25.2px (1.4) | 0em | none | 4% | 16→16→18px | 50% of Fortune 100 companies have used S |
| label | sohne-var | 16px | 400 | normal | 0em | none | 4.2% | — | Item 1 of 8: Businesses on Stripe genera |
| body-light | sohne-var | 16px | 300 | 22.4px (1.4) | 0em | none | 12.3% | — | Set up billing, take in-person payments, |
| label-regular | sohne-var | 15px | 425 | 24px (1.6) | 0.013em | none | 6.9% | 16→16→15px | Fast, predictable payouts to your bank a |
| body | sohne-var | 15px | 300 | 24px (1.6) | 0.013em | none | 28.4% | 16→16→15px | Stripe sets and collects processing fees |
| body-regular | sohne-var | 14px | 400 | 18px (1.286) | 0em | none | 4.7% | 16→16→14px | Provision and manage services with agent |
| body-light-2 | sohne-var | 14px | 300 | 19.6px (1.4) | 0em | none | 2.5% | 16→16→14px | See how Stripe is building the economic  |
| small | sohne-var | 13px | 300 | 21px (1.615) | 0.015em | none | 3.1% | — | ¹ Stripe Radar for Fraud teams and Strip |
| caption | sohne-var | 12px | 400 | normal | 0em | none | 0.4% | — | Zusammenfassung der Bestellung |
| caption-light | sohne-var | 12px | 300 | 17px (1.417) | 0em | none | 2.3% | — | For more ideas on economic progress and  |
| micro | sohne-var | 11px | 400 | 15.4px (1.4) | -0.018em | none | 0.6% | — | Payment method |
| micro-light | sohne-var | 11px | 300 | 16px (1.455) | 0em | none | 2.5% | — | I'm refreshing my wardrobe. Can you reco |
| micro-regular | sohne-var | 10px | 400 | 11.5px (1.15) | 0.01em | none | 1.4% | — | Balance at Brunch |
| micro-light-2 | sohne-var | 10px | 300 | 14.5px (1.45) | 0em | none | 3.3% | — | Zum Bezahlen Karte auflegen, einführen o |
| micro-regular-2 | sohne-var | 9px | 400 | 10.8px (1.2) | 0em | none | 0.7% | — | Electric Kettle with Temperature Control |
| micro-light-3 | sohne-var | 9px | 300 | 10.8px (1.2) | 0em | none | 1.1% | — | Zahlen Sie jetzt oder in zinsfreien Rate |

Scale: ratio 1.081, base 15px, fit 0.76. Sizes in use: 9, 10, 11, 12, 13, 14, 15, 16, 18, 22, 23, 24, 26, 32, 38, 48, 56.

## Spacing
Grid 4px (81.5% of measured paddings, margins and gaps sit on it; common off-grid values: 6, 29).

| value | share |
|---|---|
| 4px | 18.5% |
| 16px | 16.8% |
| 8px | 12.8% |
| 24px | 12.6% |
| 32px | 6.9% |
| 12px | 5.8% |
| 6px | 3.9% |
| 29px | 3.3% |
| 10px | 2% |
| 64px | 1.7% |
| 20px | 1.6% |
| 3px | 1.4% |
| 2px | 1.4% |
| 14px | 1.1% |
| 40px | 1% |
| 48px | 1% |

## Radii
| radius | count | on |
|---|---|---|
| 4px | 47 | button, small, surface |
| 6px | 46 | surface, small, media |
| 9999px | 20 | small, button, surface |
| 8px | 13 | surface |

## Borders
| border | count |
|---|---|
| `1px solid #e5edf5` | 60 |
| `1px solid #d6d9fc` | 36 |
| `1px solid #b9b9f9` | 32 |
| `1px solid #e7ecf1` | 23 |
| `1px solid #e2e4ff` | 12 |
| `1px solid #ffffff` | 8 |
| `1px dashed #e7ecf1` | 8 |
| `1px solid #ff6118` | 4 |

## Shadows
| shadow | count | on |
|---|---|---|
| `rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px` | 8 | div |
| `rgba(50, 50, 93, 0.25) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px` | 5 | section, div |
| `rgba(0, 0, 0, 0.1) 0px 20.187px 40.374px -20.187px` | 3 | div |
| `rgba(23, 23, 23, 0.08) 0px 15px 35px 0px` | 2 | div |
| `rgba(23, 23, 23, 0.06) 0px 3px 6px 0px` | 2 | div |
| `rgba(50, 50, 93, 0.12) 0px 16px 32px 0px` | 2 | div |
| `rgba(50, 50, 93, 0.12) 0px 15.931px 31.863px 0px` | 1 | div |
| `rgba(50, 50, 93, 0.25) 0px 13.5px 27px -12.4px` | 1 | nav |

## Backdrop
- `blur(12px)` (×2)
- `blur(4.5px)` (×1)
