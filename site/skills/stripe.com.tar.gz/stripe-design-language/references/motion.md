# Motion

## Scroll feel
Native scrolling: one wheel notch moves 0px instantly. Do not add smoothing.

## Tokens
| duration | uses |
|---|---|
| 300ms | 196 |
| 150ms | 174 |
| 250ms | 60 |
| 500ms | 50 |
| 1420ms | 46 |
| 400ms | 43 |
| 240ms | 35 |
| 1300ms | 20 |
| 241ms | 16 |
| 258ms | 16 |

| curve | uses | kind |
|---|---|---|
| `cubic-bezier(0.25, 1, 0.5, 1)` | 338 | bezier |
| `cubic-bezier(0.215, 0.61, 0.355, 1)` | 94 | bezier |
| `ease` | 60 | bezier |
| `cubic-bezier(0.45, 0.05, 0.55, 0.95)` | 54 | bezier |
| `cubic-bezier(0.4, 0, 0.2, 1)` | 46 | bezier |
| `ease-in-out` | 44 | bezier |
| `cubic-bezier(0.3, 0, 0.2, 1)` | 29 | bezier |
| `linear` | 25 | bezier |
| `cubic-bezier(0.165, 0.84, 0.44, 1)` | 22 | bezier |
| `ease-out` | 20 | bezier |

Libraries detected: three, canvas, next.

## Intro choreography (ms after load)
- -703ms — div 296×440 (intro-fade-17)
- -702ms — div 608×585 (intro-fade-17)
- -261ms — svg.RefreshedHoverArrow (intro-fade-out-1)
- -201ms — span 88×18 (intro-width-41)
- -200ms — button 1152×24 (intro-width-16)

## Load / intro
Plays once when the page loads. Use `data-intro="<name>"` with motion.css; set `--i` for stagger order.

### intro-fade-out-1 — ×79
Seen on: svg.RefreshedHoverArrow
- from `opacity: 1;` to `opacity: 0;`
- 150ms, `cubic-bezier(0.25, 1, 0.5, 1)` — source: css-animation
```css
@keyframes intro-fade-out-1 {
  from { opacity: 1; }
  to { opacity: 0; }
}
```
### intro-fade-out-2 — ×34
Seen on: span 290×86; span; span 290×66
- from `opacity: 1;` to `opacity: 0;`
- 250ms, `ease` — source: css-animation
```css
@keyframes intro-fade-out-2 { 0%{opacity:0} }
```
### intro-up-3 — ×17
Seen on: div 154×30; div 154×24; div 44×12; div 32×9
- from `transform: translateY(0%);` to `transform: translateY(-100%);`
- 1420ms, `ease-in-out`, delay 4000ms — source: waapi
```css
@keyframes intro-up-3 {
  from { transform: translateY(0%); }
  to { transform: translateY(-100%); }
}
```
### intro-fade-scale-4 — ×10
Seen on: div
- from `transform: scaleY(0); opacity: 0;` to `transform: scaleY(1); opacity: 1;`
- 1300ms, `ease-out`, delay 200ms — source: waapi
```css
@keyframes intro-fade-scale-4 {
  from { transform: scaleY(0); opacity: 0; }
  to { transform: scaleY(1); opacity: 1; }
}
```
### intro-tint-5 — ×6
Seen on: p.hds-text.hds-text--xxl “US$1.9tn” 182×48; span.hds-text.hds-text--md “in payments volume proce” 220×45; p.hds-text.hds-text--xxl “99.999%” 184×48; span.hds-text.hds-text--md “for Stripe services” 220×45
- from `color: rgb(100, 128, 178);` to `color: rgb(125, 139, 164);`
- 300ms, `cubic-bezier(0.25, 1, 0.5, 1)` — source: css-transition
```css
@keyframes intro-tint-5 {
  from { color: rgb(100, 128, 178); }
  to { color: rgb(125, 139, 164); }
}
```
### intro-tint-6 — ×6
Seen on: a.hds-button.customer-story-button 40×40; div 38×40
- from `background-color: rgba(0, 0, 0, 0); border-bottom-color: rgb(214, 217, 252); border-left-color: rgb(214, 217, 252); border-right-color: rgb(214, 217, 252); border-color: rgb(214, 217, 252); width: 50px;` to `background-color: rgb(226, 228, 255); border-bottom-color: rgb(226, 228, 255); border-left-color: rgb(226, 228, 255); border-right-color: rgb(226, 228, 255); border-color: rgb(226, 228, 255); width: 40px;`
- 400ms, `cubic-bezier(0.3, 0, 0.2, 1)` — source: css-transition
```css
@keyframes intro-tint-6 {
  from { background-color: rgba(0, 0, 0, 0); border-bottom-color: rgb(214, 217, 252); border-left-color: rgb(214, 217, 252); border-right-color: rgb(214, 217, 252); border-color: rgb(214, 217, 252); width: 50px; }
  to { background-color: rgb(226, 228, 255); border-bottom-color: rgb(226, 228, 255); border-left-color: rgb(226, 228, 255); border-right-color: rgb(226, 228, 255); border-color: rgb(226, 228, 255); width: 40px; }
}
```
### intro-fade-7 — ×6
Seen on: div.lazy-animation.lazy-animation--loaded 826×684; div.lazy-animation.lazy-animation--loaded 407×688; div.lazy-animation.lazy-animation--loaded 1083×448
- from `opacity: 0;` to `opacity: 1;`
- 500ms, `cubic-bezier(0.33, 1, 0.68, 1)` — source: css-transition
```css
@keyframes intro-fade-7 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-8 — ×5
Seen on: svg 9×9; div 241×65; div 241×34
- from `opacity: 0;` to `opacity: 1;`
- 1420ms, `ease-in-out`, delay 4000ms — source: waapi
```css
@keyframes intro-fade-8 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-9 — ×4
Seen on: div.bento-overlay-gradient.bento-overlay-payments
- from `opacity: 0;` to `opacity: 1;`
- 800ms, `ease` — source: css-animation
```css
@keyframes intro-fade-9 { 0%{opacity:0} to{opacity:1} }
```
### intro-down-wipe-10 — ×4
Seen on: div 241×65; div 241×34
- from `transform: translateY(-65px); clip-path: inset(0px 0px 100%);` to `transform: translateY(0px); clip-path: inset(0px 0px 0%);`
- 1420ms, `ease-in-out`, delay 4000ms — source: waapi
```css
@keyframes intro-down-wipe-10 {
  from { transform: translateY(-65px); clip-path: inset(0px 0px 100%); }
  to { transform: translateY(0px); clip-path: inset(0px 0px 0%); }
}
```
### intro-fade-out-11 — ×3
Seen on: div 121×16
- from `opacity: 1;` to `opacity: 0;`
- 400ms, `cubic-bezier(0.3, 0, 0.2, 1)` — source: css-transition
```css
@keyframes intro-fade-out-11 {
  from { opacity: 1; }
  to { opacity: 0; }
}
```
### intro-fade-12 — ×3
Seen on: div 12×12
- from `opacity: 0;` to `opacity: 1;`
- 400ms, `cubic-bezier(0.3, 0, 0.2, 1)` — source: css-transition
```css
@keyframes intro-fade-12 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-13 — ×3
Seen on: div.phone-graphic.bento-dialog-reveal; div.bento-dialog-reveal; div.fraud-and-risk-graphic.bento-dialog-reveal
- from `transform: translate3d(0px, 30px, 0px); opacity: 0;` to `transform: translateZ(0px); opacity: 1;`
- 750ms, `cubic-bezier(0.2, 0, 0, 1)`, stagger 100ms between siblings — source: css-animation
```css
@keyframes intro-fade-13 { 0%{opacity:0;transform:translate3d(0,30px,0)} to{opacity:1;transform:translateZ(0)} }
```
### intro-slide-14 — ×3
Seen on: div 178×98; div 178×94; div 32×8
- from `transform: translateX(0%);` to `transform: translateX(-100%);`
- 1420ms, `ease-in-out`, delay 4000ms — source: waapi
```css
@keyframes intro-slide-14 {
  from { transform: translateX(0%); }
  to { transform: translateX(-100%); }
}
```

## Scroll reveals
Triggered as elements enter the viewport. Use `data-reveal="<name>"`; motion.js observes them at the measured entry point.

### reveal-tint-47 — ×8
Seen on: a.Link “Payments” 71×27; a.Link “Connect” 59×27; a.Link “Billing” 39×27; a.Link “Metronome” 82×27
- from `color: rgb(99, 91, 255);` to `color: rgb(63, 75, 102);`
- 150ms, `cubic-bezier(0.215, 0.61, 0.355, 1)`, starts at 33% viewport — source: css-transition
```css
[data-reveal="reveal-tint-47"] { color: rgb(99, 91, 255); transition: color 150ms cubic-bezier(0.215, 0.61, 0.355, 1); }
[data-reveal="reveal-tint-47"].is-in { color: rgb(63, 75, 102); }
```
### reveal-tint-48 — ×5
Seen on: a.Link “Money management” 222×19; a.Link “Revenue and finance auto” 222×38; a.Link “More” 222×19; a.Link “Custom pricing” 110×28
- from `color: rgb(10, 37, 64);` to `color: rgb(99, 91, 255);`
- 150ms, `cubic-bezier(0.215, 0.61, 0.355, 1)`, starts at 18% viewport — source: css-transition
```css
[data-reveal="reveal-tint-48"] { color: rgb(10, 37, 64); transition: color 150ms cubic-bezier(0.215, 0.61, 0.355, 1); }
[data-reveal="reveal-tint-48"].is-in { color: rgb(99, 91, 255); }
```
### reveal-tint-49 — ×4
Seen on: a.Link “Global payments” 222×19; a.Link “Revenue and finance auto” 222×38; a.Link “Standard pricing” 123×28; a.Link “Custom pricing” 110×28
- from `color: rgb(99, 91, 255);` to `color: rgb(10, 37, 64);`
- 150ms, `cubic-bezier(0.215, 0.61, 0.355, 1)`, starts at 11% viewport — source: css-transition
```css
[data-reveal="reveal-tint-49"] { color: rgb(99, 91, 255); transition: color 150ms cubic-bezier(0.215, 0.61, 0.355, 1); }
[data-reveal="reveal-tint-49"].is-in { color: rgb(10, 37, 64); }
```
### reveal-fade-out-50 — ×2
Seen on: div 270×1
- from `opacity: 1;` to `opacity: 0;`
- 500ms, `cubic-bezier(0.165, 0.84, 0.44, 1)`, starts at -3% viewport — source: waapi
```css
[data-reveal="reveal-fade-out-50"] { opacity: 1; transition: opacity 500ms cubic-bezier(0.165, 0.84, 0.44, 1); }
[data-reveal="reveal-fade-out-50"].is-in { opacity: 0; }
```
### reveal-scale-51 — ×2
Seen on: div 270×1; div 237×1
- from `transform: scaleX(0);` to `transform: scaleX(1);`
- 7000ms, `linear`, delay 300ms — source: waapi
```css
[data-reveal="reveal-scale-51"] { transform: scaleX(0); transition: transform 7000ms linear 300ms; }
[data-reveal="reveal-scale-51"].is-in { transform: scaleX(1); }
```
### reveal-fade-down-52 — ×1
Seen on: nav.FixedNav 1440×64
- from `transform: translateY(-100%); opacity: 0;` to `opacity: 1;`
- 250ms, `ease` — source: css-transition
```css
[data-reveal="reveal-fade-down-52"] { transform: translateY(-100%); opacity: 0; transition: transform 250ms ease,
    opacity 250ms ease; }
[data-reveal="reveal-fade-down-52"].is-in { opacity: 1; }
```
### reveal-tint-53 — ×1
Seen on: a.Link “Money management” 222×19
- from `color: rgb(97, 90, 251);` to `color: rgb(10, 37, 64);`
- 147ms, `cubic-bezier(0.215, 0.61, 0.355, 1)`, starts at 18% viewport — source: css-transition
```css
[data-reveal="reveal-tint-53"] { color: rgb(97, 90, 251); transition: color 147ms cubic-bezier(0.215, 0.61, 0.355, 1); }
[data-reveal="reveal-tint-53"].is-in { color: rgb(10, 37, 64); }
```
### reveal-tint-54 — ×1
Seen on: a.Link “More” 222×19
- from `color: rgb(91, 86, 237);` to `color: rgb(10, 37, 64);`
- 136ms, `cubic-bezier(0.215, 0.61, 0.355, 1)`, starts at 41% viewport — source: css-transition
```css
[data-reveal="reveal-tint-54"] { color: rgb(91, 86, 237); transition: color 136ms cubic-bezier(0.215, 0.61, 0.355, 1); }
[data-reveal="reveal-tint-54"].is-in { color: rgb(10, 37, 64); }
```
### reveal-slide-55 — ×1
Seen on: div 270×398
- from `transform: translateX(-100%);` to `transform: translateX(-200%);`
- 350ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
[data-reveal="reveal-slide-55"] { transform: translateX(-100%); transition: transform 350ms cubic-bezier(0.4, 0, 0.2, 1); }
[data-reveal="reveal-slide-55"].is-in { transform: translateX(-200%); }
```
### reveal-wipe-56 — ×1
Seen on: div 1440×3
- from `clip-path: inset(0px 99.105% 0px 0px);` to `clip-path: inset(0px 0% 0px 0px);`
- 10176ms, `linear`, starts at -7% viewport — source: js
```css
[data-reveal="reveal-wipe-56"] { clip-path: inset(0px 99.105% 0px 0px); transition: clip-path 10176ms linear; }
[data-reveal="reveal-wipe-56"].is-in { clip-path: inset(0px 0% 0px 0px); }
```
