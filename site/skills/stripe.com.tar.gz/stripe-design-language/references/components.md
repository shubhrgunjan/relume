# Components

Each variant is the clustered style of every element that looked the same across the crawled pages. Classes of the same name are in `assets/tokens.css`. Crops are in `assets/reference/`.

## link (link, ×85)
![link](../assets/reference/link.jpg)
Examples: “Pricing”, “Atlas”, “Authorization Boost”, “Billing”

| property | value |
|---|---|
| background | `transparent` |
| color | `#50617a` |
| font | `300 16px/20px` |
| family | `sohne-var` |
| padding | `0px 0px 0px 0px` |
| transition | `color 0.3s cubic-bezier(0.25, 1, 0.5, 1)` |
| cursor | `pointer` |
Size: 20px tall, from 26px wide, padding 0px × 0px.

## link-2 (link, ×79)
![link-2](../assets/reference/link-2.jpg)
Examples: “Pricing”, “Atlas”, “Authorization Boost”, “Billing”

| property | value |
|---|---|
| background | `transparent` |
| color | `#0a2540` |
| font | `300 15px/24px` |
| family | `sohne-var` |
| letterSpacing | `0.2px` |
| padding | `0px 0px 0px 0px` |
| transition | `color 0.15s cubic-bezier(0.215, 0.61, 0.355, 1), opacity 0.15s cubic-bezier(0.215, 0.61, 0.355, 1)` |
| cursor | `pointer` |
Size: 20px tall, from 26px wide, padding 0px × 0px.

## link-3 (link, ×76)
![link-3](../assets/reference/link-3.jpg)
Examples: “English”, “Deutsch”, “Nederlands”, “Français”

| property | value |
|---|---|
| background | `transparent` |
| color | `#727f96` |
| font | `300 12px/16.992px` |
| family | `sohne-var` |
| padding | `0px 0px 0px 0px` |
| transition | `color 0.15s cubic-bezier(0.215, 0.61, 0.355, 1), opacity 0.15s cubic-bezier(0.215, 0.61, 0.355, 1)` |
| cursor | `pointer` |
Size: 15px tall, from 18px wide, padding 0px × 0px.

## link-4 (link, ×30)
![link-4](../assets/reference/link-4.jpg)
Examples: “Sign in”, “Standard pricing”, “Global payments”, “Custom pricing”

| property | value |
|---|---|
| background | `transparent` |
| color | `#635bff` |
| radius | `16.5px` |
| font | `425 15px/24px` |
| family | `sohne-var` |
| padding | `3px 0px 5px 0px` |
| transition | `opacity 0.3s cubic-bezier(0.25, 1, 0.5, 1), color 0.3s cubic-bezier(0.25, 1, 0.5, 1), background-color 0.3s cubic-bezier(0.25, 1, 0.5, 1), border 0.3s cubic-bezier(0.25, 1, 0.5, 1), fill 0.3s cubic-bezier(0.25, 1, 0.5, 1), stroke 0.3s cubic-bezier(0.25, 1, 0.5, 1)` |
| cursor | `pointer` |
Size: 32px tall, from 67px wide, padding 3px × 0px.

**Hover**
| property | rest | hover |
|---|---|---|
| color | `rgb(99, 91, 255)` | `rgb(6, 27, 49)` |
| borderTopColor | `rgb(99, 91, 255)` | `rgb(6, 27, 49)` |
| opacity | `1` | `0.6` |
| outlineColor | `rgb(99, 91, 255)` | `rgb(6, 27, 49)` |
Transitions: color 300ms cubic-bezier(0.25, 1, 0.5, 1); opacity 300ms cubic-bezier(0.25, 1, 0.5, 1)
Inside it: div 1112×64 — opacity 240ms cubic-bezier(0.45, 0.05, 0.55, 0.95); path — fill 300ms cubic-bezier(0.25, 1, 0.5, 1); button 105×40 — color 300ms cubic-bezier(0.25, 1, 0.5, 1); button 107×40 — color 300ms cubic-bezier(0.25, 1, 0.5, 1); button 119×40 — color 300ms cubic-bezier(0.25, 1, 0.5, 1); button 114×40 — color 300ms cubic-bezier(0.25, 1, 0.5, 1)

**Focus-visible**: outline `3px none rgb(99, 91, 255)`, offset 1px

## navbar (navbar, ×59)
![navbar](../assets/reference/navbar.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#425466` |
| font | `300 16px/normal` |
| family | `sohne-var` |
| letterSpacing | `0.2px` |
| padding | `0px 112px 0px 16px` |
Size: 136px tall, from 178px wide, padding 0px × 16px.

## footer (footer, ×17)
![footer](../assets/reference/footer.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#425466` |
| font | `300 16px/normal` |
| family | `sohne-var` |
| letterSpacing | `0.2px` |
| padding | `0px 16px 0px 16px` |
Size: 116px tall, from 238px wide, padding 0px × 16px.

## footer-2 (footer, ×1)
![footer-2](../assets/reference/footer-2.jpg)

| property | value |
|---|---|
| background | `#f8fafd` |
| color | `#000000` |
| font | `400 16px/normal` |
| family | `sohne-var` |
| padding | `0px 16px 0px 16px` |
Size: 1102px tall, from 1440px wide, padding 0px × 16px.

## footer-3 (footer, ×1)
![footer-3](../assets/reference/footer-3.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#0a2540` |
| font | `300 16px/normal` |
| family | `sohne-var` |
| padding | `0px 0px 0px 0px` |
Size: 1420px tall, from 1440px wide, padding 0px × 0px.

## card (card, ×15)
![card](../assets/reference/card.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#425466` |
| border | `1px solid #e7ecf1` |
| font | `300 16px/normal` |
| family | `sohne-var` |
| padding | `0px 0px 0px 0px` |
Size: 166px tall, from 540px wide, padding 0px × 0px.

## card-2 (card, ×14)
![card-2](../assets/reference/card-2.jpg)

| property | value |
|---|---|
| background | `#e5edf5` |
| color | `#000000` |
| radius | `6px` |
| font | `400 16px/normal` |
| family | `sohne-var` |
| padding | `0px 0px 0px 0px` |
| transition | `clip-path 0.8s cubic-bezier(0.165, 0.84, 0.44, 1)` |
| cursor | `pointer` |
Size: 686px tall, from 332px wide, padding 0px × 0px.

## card-3 (card, ×13)
![card-3](../assets/reference/card-3.jpg)

| property | value |
|---|---|
| background | `#fafbfd` |
| color | `#425466` |
| font | `300 16px/normal` |
| family | `sohne-var` |
| padding | `16px 24px 16px 24px` |
| gap | `24px` |
Size: 165px tall, from 365px wide, padding 16px × 24px.

## card-4 (card, ×12)
![card-4](../assets/reference/card-4.jpg)

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#425466` |
| font | `300 16px/normal` |
| family | `sohne-var` |
| padding | `0px 0px 0px 0px` |
Size: 439px tall, from 316px wide, padding 0px × 0px.

## card-5 (card, ×9)
![card-5](../assets/reference/card-5.jpg)

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#000000` |
| font | `400 16px/normal` |
| family | `sohne-var` |
| padding | `0px 0px 0px 0px` |
| transition | `clip-path 0.8s cubic-bezier(0.165, 0.84, 0.44, 1)` |
| cursor | `pointer` |
Size: 684px tall, from 407px wide, padding 0px × 0px.

## card-6 (card, ×7)
![card-6](../assets/reference/card-6.jpg)

| property | value |
|---|---|
| background | `#ffffff` |
| color | `#425466` |
| radius | `8px` |
| shadow | `rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px` |
| font | `300 16px/normal` |
| family | `sohne-var` |
| padding | `0px 0px 0px 0px` |
Size: 372px tall, from 810px wide, padding 0px × 0px.

## card-7 (card, ×6)
![card-7](../assets/reference/card-7.jpg)

| property | value |
|---|---|
| background | `radial-gradient(circle, rgb(127, 125, 252), rgb(244, 75, 204) 33%, rgb(229, 237, 245) 66%)` |
| color | `#000000` |
| font | `400 16px/normal` |
| family | `sohne-var` |
| padding | `0px 0px 0px 0px` |
| transition | `transform 1s cubic-bezier(0.16, 1, 0.3, 1)` |
| cursor | `pointer` |
Size: 753px tall, from 552px wide, padding 0px × 0px.

## card-8 (card, ×3)
![card-8](../assets/reference/card-8.jpg)

| property | value |
|---|---|
| background | `#f8fafd` |
| color | `#425466` |
| font | `300 16px/normal` |
| family | `sohne-var` |
| padding | `32px 32px 32px 32px` |
| ::after | `{"content":"\"\"","backgroundColor":"rgb(248, 250, 253)","width":"auto","height":"auto","position":"absolute","transform":"none","transitionProperty":"all","transitionDuration":"0s","transitionTimingFunction":"ease","borderRadius":"0px","opacity":"1","backgroundImage":"none"}` |
Size: 595px tall, from 258px wide, padding 32px × 32px.

## button-primary (button, ×13)
![button-primary](../assets/reference/button-primary.jpg)
Examples: “Contact sales”, “Request an invite”, “Start now”, “Sign up with Metronome”

| property | value |
|---|---|
| background | `#635bff` |
| color | `#ffffff` |
| radius | `16.5px` |
| font | `425 15px/24px` |
| family | `sohne-var` |
| padding | `3px 12px 6px 16px` |
| transition | `opacity 0.3s cubic-bezier(0.25, 1, 0.5, 1), color 0.3s cubic-bezier(0.25, 1, 0.5, 1), background-color 0.3s cubic-bezier(0.25, 1, 0.5, 1), border 0.3s cubic-bezier(0.25, 1, 0.5, 1), fill 0.3s cubic-bezier(0.25, 1, 0.5, 1), stroke 0.3s cubic-bezier(0.25, 1, 0.5, 1)` |
| cursor | `pointer` |
Size: 33px tall, from 117px wide, padding 3px × 16px.

**Hover**
| property | rest | hover |
|---|---|---|
| backgroundColor | `rgb(99, 91, 255)` | `rgb(10, 37, 64)` |
| opacity | `1` | `0.6` |
Transitions: backgroundColor 300ms cubic-bezier(0.25, 1, 0.5, 1); backgroundColor 300ms cubic-bezier(0.25, 1, 0.5, 1); opacity 300ms cubic-bezier(0.25, 1, 0.5, 1)
Inside it: div 1112×64 — opacity 240ms cubic-bezier(0.45, 0.05, 0.55, 0.95); path — fill 300ms cubic-bezier(0.25, 1, 0.5, 1); button 105×40 — color 300ms cubic-bezier(0.25, 1, 0.5, 1); button 107×40 — color 300ms cubic-bezier(0.25, 1, 0.5, 1); button 119×40 — color 300ms cubic-bezier(0.25, 1, 0.5, 1); button 114×40 — color 300ms cubic-bezier(0.25, 1, 0.5, 1)

**Focus-visible**: outline `3px none rgb(255, 255, 255)`, offset 1px

## button-outline (button, ×8)
![button-outline](../assets/reference/button-outline.jpg)
Examples: “Read the letter”, “See the numbers”, “Get the data”, “Watch video”

| property | value |
|---|---|
| background | `transparent` |
| color | `#533afd` |
| border | `1px solid #b9b9f9` |
| radius | `4px` |
| font | `400 16px/16px` |
| family | `sohne-var` |
| padding | `14.5px 24px 15.5px 24px` |
| gap | `8px` |
| transition | `background-color 0.3s cubic-bezier(0.25, 1, 0.5, 1), color 0.3s cubic-bezier(0.25, 1, 0.5, 1), outline-color 0.3s cubic-bezier(0.25, 1, 0.5, 1), border 0.3s cubic-bezier(0.25, 1, 0.5, 1)` |
| cursor | `pointer` |
Size: 48px tall, from 139px wide, padding 14.5px × 24px.

## button-secondary (button, ×6)
![button-secondary](../assets/reference/button-secondary.jpg)
Examples: “Request an invite”, “Stripe for enterprises”, “Stripe for startups”, “Stripe for platforms”

| property | value |
|---|---|
| background | `#533afd` |
| color | `#ffffff` |
| radius | `4px` |
| font | `400 16px/16px` |
| family | `sohne-var` |
| padding | `15.5px 24px 16.5px 24px` |
| gap | `8px` |
| transition | `background-color 0.3s cubic-bezier(0.25, 1, 0.5, 1), color 0.3s cubic-bezier(0.25, 1, 0.5, 1), outline-color 0.3s cubic-bezier(0.25, 1, 0.5, 1), border 0.3s cubic-bezier(0.25, 1, 0.5, 1)` |
| cursor | `pointer` |
Size: 48px tall, from 164px wide, padding 15.5px × 24px.

**Hover**
| property | rest | hover |
|---|---|---|

Inside it: span 9×18 — transform 325ms cubic-bezier(0.33, 1, 0.68, 1); span “6” 9×18 — transform 325ms cubic-bezier(0.33, 1, 0.68, 1)

**Focus-visible**: outline `3px solid rgba(0, 0, 0, 0)`, offset 1px

## button-outline-2 (button, ×4)
![button-outline-2](../assets/reference/button-outline-2.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#000000` |
| border | `1px solid #e5edf5` |
| font | `400 16px/normal` |
| family | `sohne-var` |
| padding | `11px 8px 11px 8px` |
| cursor | `pointer` |
Size: 65px tall, from 241px wide, padding 11px × 8px.

## button-secondary-2 (button, ×3)
![button-secondary-2](../assets/reference/button-secondary-2.jpg)
Examples: “カード番号”, “有効期限”, “セキュリティコード”

| property | value |
|---|---|
| background | `#f8fafd` |
| color | `#64748d` |
| radius | `6px` |
| font | `300 9px/10.8px` |
| family | `sohne-var` |
| letterSpacing | `-0.081px` |
| padding | `9px 7px 9px 7px` |
| cursor | `pointer` |
Size: 30px tall, from 110px wide, padding 9px × 7px.

## button-secondary-3 (button, ×2)
![button-secondary-3](../assets/reference/button-secondary-3.jpg)

| property | value |
|---|---|
| background | `rgb(255 255 255 / 0.38)` |
| color | `#000000` |
| radius | `16px` |
| font | `400 16px/normal` |
| family | `sohne-var` |
| padding | `2px 8px 2px 8px` |
| gap | `10px` |
| cursor | `pointer` |
Size: 20px tall, from 262px wide, padding 2px × 8px.

## badge (badge, ×1)
![badge](../assets/reference/badge.jpg)
Examples: “Choose a plan”

| property | value |
|---|---|
| background | `#f6f9fb` |
| color | `#0a2540` |
| radius | `4px` |
| font | `425 15px/24px` |
| family | `sohne-var` |
| padding | `3px 10px 3px 10px` |
Size: 30px tall, from 120px wide, padding 3px × 10px.
