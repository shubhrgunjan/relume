---
name: resend-design-language
description: "Build UI in the design language measured from resend.com: Dark interface, almost entirely neutral — colour is rationed (chromatic share 0.7%). Use whenever creating or restyling pages, sections or components that should look and move like resend.com — colours, type, spacing, components and motion come from measurement, not guesswork."
---

# resend.com design language

Measured from https://resend.com (4 pages at desktop, tablet, mobile, desktop-dark) on 2026-10-29 by relume. Every value here was read from the live site — computed styles, stylesheets, animations and a frame-by-frame motion recording — so treat them as facts, not suggestions.

## The feel
- Dark interface, almost entirely neutral — colour is rationed (chromatic share 0.7%).
- Maximum-contrast text (18.4:1).
- Headlines 96px / 400; body 14px at 1.6 leading.
- Soft, rounded surfaces (16px).
- Layered shadows carry depth.
- Translucent, blurred (glass) layers are part of the language.
- Generous vertical rhythm: sections breathe with ~96px padding on desktop.
- Entrances run ~512ms, with spring physics (4 spring curves); native scrolling.

## Build to the blueprint first
This language is not only its tokens. Its home page is 14 screens of 13 sections; 32% of it is covered by visuals (1 3d-scene, 5 image, 6 logos, 5 ui-mock, 4 video, 2 form, 1 cards, 65 avatar, 3 testimonial), at ~78 painted elements per screen. Read `references/blueprint.md` before anything else: it lists every section of the source in order, with a crop, its layout, and what it is made of. A new page must have the same kinds of sections in the same order, filled with the same kinds of things for your product: product UI built in real HTML with the measured UI grammar, illustrations in the source's style, data visualisations, logo rows, testimonial cards. Headings over empty boxes are not this language, and the checker fails them.

## Build the behaviour, not just the picture
Sections on this site move on their own. A static copy of their layout is not this language: recreate each behaviour for your content, with the measured speeds, periods and levels. Each section's full behaviour and a filmstrip are in `references/blueprint.md`; with the relume MCP, `see_behaviour` shows it.

- **hero + visual** (section 1): canvas 648×550 is a live 3D scene (webgl2, three.js r149). Rebuild it as real 3D (three.js), not a still image. Part of the view drifts right at ~22px/s on its own (painted motion: canvas, background or image). img.pointer-events-none.absolute (image) 1440×900 fades out through a gradient mask (linear-gradient(to top, rgba(0, 0, 0, 0) 15%, rgb(0, 0, 0) 25%)).
- **product UI showcase** (section 5): video.mx-auto.mb-4 (3d-broadcast.mp4) 170×170 is autoplaying video on a loop. div.relative.mt-16 1109×600 fades out through a gradient mask (linear-gradient(rgb(0, 0, 0) 40%, rgba(0, 0, 0, 0) 100%)).
- **card row** (section 6): img.block.w-full (image) 534×228 fades out through a gradient mask (linear-gradient(45deg, rgb(0, 0, 0) 50%, rgba(0, 0, 0, 0) 100%)). img.w-full.rounded-2xl (image) 534×228 fades out through a gradient mask (linear-gradient(45deg, rgb(0, 0, 0) 50%, rgba(0, 0, 0, 0) 100%)).
- **product UI showcase** (section 7): video.mx-auto.mb-4 (3d-react.mp4) 170×170 is autoplaying video on a loop.
- **content** (section 10): video.mx-auto.mb-4 (3d-control.mp4) 170×170 is autoplaying video on a loop.
- **logo strip** (section 11): ul.flex.shrink-0 4788×268 moves between 49 positions (up to 4817px).

## Setup
1. Copy `assets/tokens.css` (plain CSS variables, text styles, component classes, `.container` and `.section` with the measured width, gutters and rhythm — use them, don't re-derive) into the project; with Tailwind v4 also import `assets/tailwind.css` after `@import "tailwindcss"`.
2. Add `assets/motion.css` and `assets/motion.js` (scroll reveals, intro choreography, stagger and scroll feel, all with measured timings).
3. Fonts: **inter** (= Inter on Google Fonts) for title-lg, h3-regular, title, title-semibold — `var(--font-sans)`; **commitMono** (use **Geist Mono** unless you hold a licence) for mono, mono-regular, mono-sm — `var(--font-mono)`; **aBCFavorit** (use **Inter** unless you hold a licence) for h2, h2-regular, h3, h3-regular-2 — `var(--font-abcfavorit)`; **interLatin** (use **Inter** unless you hold a licence) for title-medium, body-medium, body-regular-2 — `var(--font-interlatin)`; **Helvetica** (use **Inter** unless you hold a licence) for h2-regular-2, body-regular — `var(--font-helvetica)`; **domaine** (use **Playfair Display** unless you hold a licence) for h1, h1-regular — `var(--font-domaine)`.
   Load the open ones: `<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Geist+Mono:wght@400&family=Playfair+Display:wght@400&display=swap" rel="stylesheet">`

## Core tokens
- Background #000000, text #f0f0f0 / rgb(252 253 255 / 0.937) / rgb(241 247 254 / 0.71), accent #6565ec, surface #161618, border rgb(214 235 253 / 0.19).
- Type scale ≈1.071 (minor second) from 14px: h1 96/400, h1-regular 76.8/400, h2 56/400, h2-regular 36/400, title-lg 24/500, h2-regular-2 24/400, h3 20/400, h3-regular 20/400.
- Radii 9999px, 16px, 6px, 8px, 24px. Spacing grid 4px. Container 1280px, gutters 24 / 24 / 24px (desktop / tablet / mobile).
- Motion: 200ms, 150ms, 350ms, 300ms, 250ms; curves `cubic-bezier(0.4, 0, 0.2, 1)`, `cubic-bezier(0.22, 1, 0.36, 1)`, `cubic-bezier(0, 0, 0.2, 1)` plus 2 spring curves (kept exact as `linear()`). Scroll: native.
- Primary action: linear-gradient(to left bottom, rgb(255 255 255 / 0.06) 0%, rgba(0, 0, 0, 0) 100%) / rgb(252 253 255 / 0.937), radius 12px, 400 16px/24px.

## Do
- Use only the colour tokens in `assets/tokens.css`; the accent (#6565ec) covers ≤2% of any screen.
- Set text with the named styles (`.text-body`, `.text-h1` …); never invent sizes between them.
- Space on the 4px grid (12, 4, 16, 8, 24, 2 are the workhorses); sections get ~96px vertical padding on desktop.
- Reuse the measured shadows verbatim; they are layered, not single blurs.
- Floating chrome (nav, popovers) uses the measured backdrop blur over a translucent fill.
- The source animates with three.js (r149) for live 3D. Use the same kind of tool for those parts: a live 3D scene must be rebuilt as real 3D, not a still render.

## Don't
- Do not use radii outside 9999px, 16px, 6px, 8px, 24px.
- Do not use durations or curves that are not in the motion tokens (200ms, 150ms, 350ms, 300ms, 250ms).
- Do not add smooth-scroll libraries; the source scrolls natively.
- Do not copy the source’s logo, product names, photography, illustrations or copy; describe your own product in this language.

## Motion signature
- **intro-fade-1** (load, ×7): opacity: 0; → opacity: 1; over 650ms `spring (see motion.md)`.
- **intro-fade-2** (load, ×5): opacity: 0; → opacity: 1; over 1050ms `spring (see motion.md)`, delay 100ms.
- **intro-fade-up-3** (load, ×4): transform: translateY(16px); opacity: 0; → transform: translateY(0px); opacity: 1; over 1000ms `ease-in-out`.
- **intro-tint-4** (load, ×3): background-color: #6a7282; → background-color: #00c950; over 150ms `cubic-bezier(0.4, 0, 0.2, 1)`.
- **intro-fade-5** (load, ×2): opacity: 0; → opacity: 1; over 500ms `ease-out`.
- **intro-fade-up-scale-6** (load): transform: scale(0.98) translateY(5px); opacity: 0; → transform: scale(1) translateY(0px); opacity: 1; over 1500ms `ease-in-out`.

## Workflow
1. Read `references/tokens.md` and `references/components.md` before writing UI; open the images in `assets/reference/` to see the look.
2. Build with the component classes and text styles; take motion from `references/motion.md` (exact CSS per pattern).
3. Run `node scripts/lint.mjs <your files…>` and fix every off-system colour, size, radius, duration and curve it reports.
4. If the relume MCP server is connected, call `check_style` with your page's URL: it re-measures your page and compares its DNA (composition, tokens and motion) with this one. Fix what it reports until it passes.

## References
- `references/blueprint.md` — the page, section by section: order, layout, contents, density, crops, and the UI grammar of the product mock-ups.
- `references/tokens.md` — every colour (with dark values and the source’s own variable names), text style (with fluid sizes), spacing, radius, border, shadow, gradient.
- `references/components.md` — buttons, links, inputs, cards, badges, navigation, footer: resting style, hover/focus states and transitions.
- `references/motion.md` — scroll feel, intro choreography, scroll reveals, hover motion, loops; exact CSS.
- `references/layout.md` — containers, gutters, grids, breakpoints, section rhythm, density.
- `assets/DESIGN.md` — the same system in Google's DESIGN.md format, for other tools.
