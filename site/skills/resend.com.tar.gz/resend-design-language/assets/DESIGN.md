---
name: resend.com
colors:
  background: "#000000"
  surface: "#161618"
  text-quaternary: "#a1a4a5"
  text: "#f0f0f0"
  gray-a15: "rgb(80 80 80 / 0.15)"
  accent: "#6565ec"
  black-100: "#111111"
  surface-2: "#ffffff"
  black-a50: "rgb(0 0 0 / 0.5)"
  border: "rgb(214 235 253 / 0.19)"
  surface-3: "rgb(255 255 255 / 0.05)"
  black-a80: "rgb(0 0 0 / 0.8)"
  border-2: "rgb(217 237 254 / 0.145)"
  white-a50: "rgb(255 255 255 / 0.5)"
  border-3: "#e5e7eb"
  white-a10: "rgb(255 255 255 / 0.1)"
  gray-100: "#212629"
  text-secondary: "rgb(252 253 255 / 0.937)"
  text-tertiary: "rgb(241 247 254 / 0.71)"
  surface-4: "rgb(221 234 248 / 0.08)"
  gray-a10: "rgb(200 200 200 / 0.1)"
  black-a10: "rgb(0 0 0 / 0.1)"
  gray-200: "#39393f"
  gray-a88: "rgb(24 25 28 / 0.88)"
typography:
  h1:
    fontFamily: "domaine"
    fontSize: 96px
    fontWeight: 400
    lineHeight: 1
    letterSpacing: -0.01em
  h1-regular:
    fontFamily: "domaine"
    fontSize: 76.8px
    fontWeight: 400
    lineHeight: 1
    letterSpacing: -0.01em
  h2:
    fontFamily: "aBCFavorit"
    fontSize: 56px
    fontWeight: 400
    lineHeight: 1.2
    letterSpacing: -0.05em
  h2-regular:
    fontFamily: "aBCFavorit"
    fontSize: 36px
    fontWeight: 400
    lineHeight: 1.3
    letterSpacing: -0.05em
  title-lg:
    fontFamily: "inter"
    fontSize: 24px
    fontWeight: 500
    lineHeight: 1.5
    letterSpacing: 0em
  h2-regular-2:
    fontFamily: "Helvetica"
    fontSize: 24px
    fontWeight: 400
    lineHeight: 1.4
    letterSpacing: 0em
  h3:
    fontFamily: "aBCFavorit"
    fontSize: 20px
    fontWeight: 400
    lineHeight: 1
    letterSpacing: 0em
  h3-regular:
    fontFamily: "inter"
    fontSize: 20px
    fontWeight: 400
    lineHeight: 1.4
    letterSpacing: 0em
  title:
    fontFamily: "inter"
    fontSize: 18px
    fontWeight: 400
    lineHeight: 1.5
    letterSpacing: 0em
  title-semibold:
    fontFamily: "inter"
    fontSize: 16px
    fontWeight: 600
    lineHeight: 1.5
    letterSpacing: 0em
  title-medium:
    fontFamily: "interLatin"
    fontSize: 16px
    fontWeight: 500
    lineHeight: 1.5
    letterSpacing: -0.013em
  mono:
    fontFamily: "commitMono"
    fontSize: 16px
    fontWeight: 400
    lineHeight: 1.5
    letterSpacing: 0em
  h3-regular-2:
    fontFamily: "aBCFavorit"
    fontSize: 16px
    fontWeight: 400
    lineHeight: 1.5
    letterSpacing: -0.05em
  title-regular:
    fontFamily: "inter"
    fontSize: 16px
    fontWeight: 400
    lineHeight: 1.5
    letterSpacing: 0em
rounded:
  full: 9999px
  md: 16px
  lg: 6px
  xl: 8px
  2xl: 24px
  3xl: 12px
spacing:
  "1": 2px
  "2": 4px
  "3": 6px
  "4": 8px
  "5": 12px
  "6": 16px
  "7": 24px
  "8": 32px
components:
  card:
    backgroundColor: "linear-gradient(rgba(80, 80, 80, 0.15) 0%, rgba(0, 0, 0, 0) 70%)"
    textColor: "#f0f0f0"
    rounded: 16px
    padding: 24px 32px 24px 32px
  card-2:
    backgroundColor: "linear-gradient(to right bottom, rgb(255, 255, 255) 30%, rgba(255, 255, 255, 0.5"
    textColor: "#f0f0f0"
    padding: 0px 0px 12px 0px
  card-3:
    backgroundColor: "linear-gradient(rgba(0, 0, 0, 0) 0%, rgb(0, 0, 0) 50%, rgb(0, 0, 0) 100%)"
    textColor: "#f0f0f0"
    padding: 0px 0px 0px 0px
  card-4:
    backgroundColor: "transparent"
    textColor: "#f0f0f0"
    rounded: 24px
    padding: 96px 24px 96px 24px
  card-5:
    backgroundColor: "radial-gradient(114.08% 50% at 50.2% 0.07%, rgb(0 0 0 / 0.1) 0%, rgba(0, 0, 0, 0"
    textColor: "#ffffff"
    rounded: 16px
    padding: 20px 20px 20px 20px
  card-6:
    backgroundColor: "conic-gradient(from 90deg, rgba(0, 0, 0, 0) 50%, rgb(0, 0, 0) 50%), radial-gradi"
    textColor: "#f0f0f0"
    padding: 0px 0px 0px 0px
---

# resend.com

## Overview
Dark interface, almost entirely neutral — colour is rationed (chromatic share 0.7%). Maximum-contrast text (18.4:1). Headlines 96px / 400; body 14px at 1.6 leading. Soft, rounded surfaces (16px). Layered shadows carry depth. Translucent, blurred (glass) layers are part of the language. Generous vertical rhythm: sections breathe with ~96px padding on desktop. Entrances run ~512ms, with spring physics (4 spring curves); native scrolling.

## Colors
- **background** `#000000` — background
- **surface** `#161618` — surface
- **text-quaternary** `#a1a4a5` — text-quaternary
- **text** `#f0f0f0` — text
- **gray-a15** `rgb(80 80 80 / 0.15)` — palette
- **accent** `#6565ec` — accent
- **black-100** `#111111` — palette
- **surface-2** `#ffffff` — surface-2
- **black-a50** `rgb(0 0 0 / 0.5)` — palette
- **border** `rgb(214 235 253 / 0.19)` — border

## Typography
- inter
- commitMono (open substitute: Geist Mono)
- aBCFavorit (open substitute: Inter)
- interLatin (open substitute: Inter)
- Helvetica (open substitute: Inter)
- domaine (open substitute: Playfair Display)

## Motion
Durations 200ms, 150ms, 350ms, 300ms, 250ms; curves cubic-bezier(0.4, 0, 0.2, 1), cubic-bezier(0.22, 1, 0.36, 1), cubic-bezier(0, 0, 0.2, 1).

## Do's and Don'ts
- Use the tokens above only.
- Keep motion within the measured durations and curves.
- Never reuse the source brand’s logo, imagery or copy.
