# Tokens

## Colour (dark scheme)
Ordered by painted weight (area × use). `aliases` are the source's own custom properties holding the same value.

| token | value | role | share | used for | dark | source aliases |
|---|---|---|---|---|---|---|
| background | `#000000` | background | 88.2% | bg, gradient | — | --bg-base --text-on-accent --agent-orb-backing |
| surface | `#161618` | surface | 2.2% | bg | — | --color-gray-1 --gray-1 |
| text-quaternary | `#a1a4a5` | text-quaternary | 1.6% | text | — | --color-gray-11 --gray-11 |
| text | `#f0f0f0` | text | 1.2% | text, accent-fill | — | --color-light-gray-2 --bg-accent-hover --color-gray-12 |
| gray-a15 | `rgb(80 80 80 / 0.15)` | palette | 0.8% | gradient | — | — |
| accent | `#6565ec` | accent | 0.7% | bg | — | — |
| black-100 | `#111111` | palette | 0.7% | gradient | — | — |
| surface-2 | `#ffffff` | surface-2 | 0.6% | gradient, bg | — | --color-white --bg-accent --tw-ring-offset-color |
| black-a50 | `rgb(0 0 0 / 0.5)` | palette | 0.6% | gradient | — | --black-a7 |
| border | `rgb(214 235 253 / 0.19)` | border | 0.5% | border | — | --slate-a6 --color-slate-6 |
| surface-3 | `rgb(255 255 255 / 0.05)` | surface-3 | 0.5% | border, bg, gradient | — | — |
| black-a80 | `rgb(0 0 0 / 0.8)` | palette | 0.4% | gradient | — | --black-a10 |
| border-2 | `rgb(217 237 254 / 0.145)` | border-2 | 0.3% | border | — | --slate-a5 --color-slate-5 |
| white-a50 | `rgb(255 255 255 / 0.5)` | palette | 0.2% | gradient | — | — |
| border-3 | `#e5e7eb` | border-3 | 0.2% | border | — | --color-gray-200 |
| white-a10 | `rgb(255 255 255 / 0.1)` | palette | 0.2% | gradient, border | — | — |
| gray-100 | `#212629` | palette | 0.2% | border | — | --color-gray-3 --gray-3 --scroll-shadow-line-color |
| text-secondary | `rgb(252 253 255 / 0.937)` | text-secondary | 0.1% | text | — | --mauve-a12 --slate-a12 --color-slate-12 |
| text-tertiary | `rgb(241 247 254 / 0.71)` | text-tertiary | 0.1% | text, accent-fill | — | --slate-a11 --color-slate-11 |
| surface-4 | `rgb(221 234 248 / 0.08)` | surface-4 | 0.1% | bg | — | --slate-a3 --color-slate-3 |
| gray-a10 | `rgb(200 200 200 / 0.1)` | palette | 0.1% | gradient | — | — |
| black-a10 | `rgb(0 0 0 / 0.1)` | palette | 0.1% | gradient | — | --color-black-2 --black-a2 |
| gray-200 | `#39393f` | palette | 0.1% | border, bg | — | — |
| gray-a88 | `rgb(24 25 28 / 0.88)` | palette | 0% | gradient, shadow | — | --color-gray-a2 --gray-a2 |
| gray-600 | `#8c8c8c` | palette | 0% | text, accent-fill | — | — |
| green-200 | `#183226` | palette | 0% | bg | — | — |
| black-50 | `#0b0e14` | palette | 0% | accent-fill | — | — |
| indigo-600 | `#00a3ff` | palette | 0% | accent-fill | — | — |
| indigo-200 | `#102b4a` | palette | 0% | accent-fill | — | — |
| red-100 | `#3d151e` | palette | 0% | accent-fill | — | — |
| amber-400 | `#8f3e1e` | palette | 0% | gradient, accent-fill | — | — |
| green-700 | `#00c950` | palette | 0% | accent-fill | — | --color-green-500 |

### Gradients
- `linear-gradient(rgba(0, 0, 0, 0) 60%, rgb(0, 0, 0) 100%, rgb(0, 0, 0) 100%)`
- `linear-gradient(rgba(80, 80, 80, 0.15) 0%, rgba(0, 0, 0, 0) 70%)`
- `linear-gradient(rgb(17, 17, 17) 0%, rgb(0 0 0 / 0.5) 100%)`
- `linear-gradient(rgba(0, 0, 0, 0) 0%, rgb(0, 0, 0) 50%, rgb(0, 0, 0) 100%)`
- `linear-gradient(rgba(0, 0, 0, 0) 0%, rgb(0 0 0 / 0.8) 50%, rgb(0, 0, 0) 100%)`
- `linear-gradient(to right bottom, rgb(255, 255, 255) 30%, rgba(255, 255, 255, 0.5))`
- `linear-gradient(rgba(0, 0, 0, 0) 0%, rgb(0, 0, 0) 100%, rgb(0, 0, 0) 100%)`
- `conic-gradient(from 90deg, rgba(0, 0, 0, 0) 50%, rgb(0, 0, 0) 50%), radial-gradient(rgba(200, 200, 200, 0.1) 0%, rgba(0, 0, 0, 0) 80%)`

## Typography
| family | share | weights | source | licence | substitute |
|---|---|---|---|---|---|
| inter | 85.1% | 400 500 600 | self-hosted | open (Google Fonts) — load it from Google Fonts or self-host | — |
| commitMono | 8.1% | 400 | self-hosted | likely commercial — do not copy the font files; license it or use the substitute | Geist Mono |
| aBCFavorit | 3.2% | 400 | self-hosted | likely commercial — do not copy the font files; license it or use the substitute | Inter |
| interLatin | 2.3% | 400 500 | self-hosted | likely commercial — do not copy the font files; license it or use the substitute | Inter |
| Helvetica | 0.7% | 400 | system | system | Inter |
| domaine | 0.3% | 400 | self-hosted | likely commercial — do not copy the font files; license it or use the substitute | Playfair Display |

| style | family | size | weight | line-height | tracking | case | share | responsive | sample |
|---|---|---|---|---|---|---|---|---|---|
| h1 | domaine | 96px | 400 | 96px (1) | -0.01em | none | 0.1% | 64→96→96px | Email for developers |
| h1-regular | domaine | 76.8px | 400 | 76.8px (1) | -0.01em | none | 0.2% | 64→76.8→76.8px | Email reimagined. Available today. |
| h2 | aBCFavorit | 56px | 400 | 67.2px (1.2) | -0.05em | none | 1.3% | 48→56→56px | Granular visibility of all runs and step |
| h2-regular | aBCFavorit | 36px | 400 | 46.8px (1.3) | -0.05em | none | 0.4% | — | Deliverability & reliability |
| title-lg | inter | 24px | 500 | 36px (1.5) | 0em | none | 0.8% | — | Resend is transforming email for develop |
| h2-regular-2 | Helvetica | 24px | 400 | 33.6px (1.4) | 0em | none | 0.1% | — | Welcome to , user! |
| h3 | aBCFavorit | 20px | 400 | 20px (1) | 0em | none | 1.1% | — | Proactive blocklist tracking |
| h3-regular | inter | 20px | 400 | 28px (1.4) | 0em | none | 0.1% | — | Conditional Paths |
| title | inter | 18px | 400 | 27px (1.5) | 0em | none | 6.1% | 16→18→18px | A simple, elegant interface so you can s |
| title-semibold | inter | 16px | 600 | 24px (1.5) | 0em | none | 0.5% | — | Explore Enterprise |
| title-medium | interLatin | 16px | 500 | 24px (1.5) | -0.013em | none | 0.1% | — | We’re fully operational |
| mono | commitMono | 16px | 400 | 24px (1.5) | 0em | none | 1.4% | — | "f21995fa-89d4-4530-8707-f094f38a0f8c" |
| h3-regular-2 | aBCFavorit | 16px | 400 | 24px (1.5) | -0.05em | none | 0.4% | — | Domain authentication |
| title-regular | inter | 16px | 400 | 24px (1.5) | 0em | none | 13.3% | — | With pay-as-you-go pricing, you can cont |
| label | inter | 14px | 600 | 20px (1.429) | 0em | none | 0.6% | 16→16→14px | Are you an AI agent? See pricing |
| label-medium | inter | 14px | 500 | 20px (1.429) | 0em | none | 0.5% | — | Enterprise |
| body-medium | interLatin | 14px | 500 | 20px (1.429) | -0.007em | none | 0.4% | — | Subscribe to updates |
| body | inter | 14px | 400 | 22.4px (1.6) | 0em | none | 60.2% | — | Receive real-time notifications directly |
| mono-regular | commitMono | 14px | 400 | 20px (1.429) | 0em | none | 1.6% | — | '<strong>it works!</strong>' |
| body-regular | Helvetica | 14px | 400 | 24px (1.714) | 0em | none | 0.6% | — | We're excited to have you onboard at . W |
| body-regular-2 | interLatin | 14px | 400 | 20px (1.429) | -0.007em | none | 1.8% | — | We’re not aware of any issues affecting  |
| small | inter | 12px | 600 | 16px (1.333) | 0em | none | 0.4% | — | Enterprise |
| small-medium | inter | 12px | 500 | 12px (1) | 0em | none | 0.4% | — | order.created |
| small-regular | inter | 12px | 400 | 16px (1.333) | 0em | none | 2.2% | — | 2261 Market Street #5039 San Francisco,  |
| mono-sm | commitMono | 12px | 400 | 16px (1.333) | 0em | none | 5.1% | 14→12→12px | . We hope you enjoy your journey with us |

Scale: ratio 1.071 (minor second), base 14px, fit 0.78. Sizes in use: 12, 14, 16, 18, 20, 24, 36, 56, 76.8, 96.

## Spacing
Grid 4px (84.1% of measured paddings, margins and gaps sit on it; common off-grid values: 2, 6, 14).

| value | share |
|---|---|
| 12px | 20.2% |
| 4px | 16% |
| 16px | 15.2% |
| 8px | 11.5% |
| 24px | 8.2% |
| 2px | 6.6% |
| 32px | 5.7% |
| 6px | 3.4% |
| 14px | 3.3% |
| 20px | 2.5% |
| 1px | 1.6% |
| 96px | 1.4% |
| 48px | 1.1% |
| 40px | 0.9% |
| 10px | 0.6% |
| 28px | 0.4% |

## Radii
| radius | count | on |
|---|---|---|
| 9999px | 326 | small, button, surface, media |
| 16px | 147 | button, surface, media |
| 6px | 51 | small, button, surface |
| 8px | 37 | button, surface, small |
| 24px | 21 | surface |
| 12px | 21 | surface, small, button |
| 4px | 15 | small, surface, button, media |
| 10px | 6 | small |

## Borders
| border | count |
|---|---|
| `1px solid rgb(214 235 253 / 0.19)` | 581 |
| `1px solid rgb(217 237 254 / 0.145)` | 213 |
| `2px solid rgb(255 255 255 / 0.05)` | 68 |
| `1px solid #212629` | 64 |
| `1px solid #39393f` | 60 |
| `1px solid #e5e7eb` | 45 |
| `1px solid rgb(255 255 255 / 0.05)` | 12 |
| `1px solid rgb(255 255 255 / 0.2)` | 12 |

## Shadows
| shadow | count | on |
|---|---|---|
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(24, 25, 28, 0.88) 0px 0px 0px 1px, rgba(0, 0, 0, 0) 0px 0px 0px 0px` | 120 | img |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.1) 0px 1px 3px 0px, rgba(0, 0, 0, 0.1) 0px 1px 2px -1px` | 17 | a |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(255 255 255 / 0.1) 0px 0px 0px 1px inset, rgba(0, 0, 0, 0) 0px 0px 0px 0px` | 16 | div, span |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px` | 15 | div |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(255 255 255 / 0.05) 0px 0px 0px 1px inset, rgba(0, 0, 0, 0) 0px 0px 0px 0px` | 7 | div |
| `rgb(0, 0, 0) 0px 0px 0px 8px` | 5 | div |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(255, 255, 255) 0px 1px 1px 0px inset` | 3 | div |
| `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(255 255 255 / 0.1) 0px 0px 0px 2px inset, rgba(0, 0, 0, 0) 0px 0px 0px 0px` | 3 | div |

## Backdrop
- `blur(25px)` (×17)
