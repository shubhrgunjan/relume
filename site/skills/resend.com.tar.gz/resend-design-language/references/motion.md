# Motion

## Scroll feel
Native scrolling: one wheel notch moves 100px instantly. Do not add smoothing.

## Tokens
| duration | uses |
|---|---|
| 200ms | 180 |
| 150ms | 138 |
| 350ms | 83 |
| 300ms | 31 |
| 250ms | 26 |
| 500ms | 22 |
| 650ms | 16 |
| 1050ms | 14 |
| 80ms | 10 |
| 395ms | 9 |

| curve | uses | kind |
|---|---|---|
| `cubic-bezier(0.4, 0, 0.2, 1)` | 231 | bezier |
| `cubic-bezier(0.22, 1, 0.36, 1)` | 136 | bezier |
| `cubic-bezier(0, 0, 0.2, 1)` | 44 | bezier |
| `cubic-bezier(0.4, 0, 1, 1)` | 42 | bezier |
| `cubic-bezier(0.36, 0.66, 0.6, 1)` | 31 | bezier |
| `ease-out` | 26 | bezier |
| `linear` | 22 | bezier |
| `cubic-bezier(0.215, 0.61, 0.355, 1)` | 21 | bezier |
| `linear(0 0%, 0.0144 1.56%, 0.0538 3.13%, 0.1123 4.69%, 0.1848 6.25%, 0.2668 7.81…` | 16 | spring (CSS linear()) |
| `linear(0 0%, 0.0089 0.96%, 0.0315 1.92%, 0.0628 2.88%, 0.0994 3.85%, 0.1389 4.81…` | 14 | spring (CSS linear()) |

Spring curves, exact (paste as-is; supported in all evergreen browsers):
```css
linear(0 0%, 0.0144 1.56%, 0.0538 3.13%, 0.1123 4.69%, 0.1848 6.25%, 0.2668 7.81%, 0.3542 9.38%, 0.4436 10.94%, 0.5321 12.5%, 0.6174 14.06%, 0.6977 15.63%, 0.7716 17.19%, 0.8384 18.75%, 0.8974 20.31%, 0.9484 21.88%, 0.9915 23.44%, 1.0269 25%, 1.0551 26.56%, 1.0765 28.13%, 1.0918 29.69%, 1.1018 31.25%, 1.1071 32.81%, 1.1084 34.38%, 1.1065 35.94%, 1.1019 37.5%, 1.0953 39.06%, 1.0873 40.63%, 1.0783 42.19%, 1.0688 43.75%, 1.0591 45.31%, 1.0495 46.88%, 1.0404 48.44%, 1.0317 50%, 1.0238 51.56%, 1.0167 53.13%, 1.0104 54.69%, 1.005 56.25%, 1.0004 57.81%, 0.9967 59.38%, 0.9937 60.94%, 0.9915 62.5%, 0.9899 64.06%, 0.9889 65.63%, 0.9883 67.19%, 0.9882 68.75%, 0.9885 70.31%, 0.989 71.88%, 0.9898 73.44%, 0.9906 75%, 0.9916 76.56%, 0.9927 78.13%, 0.9937 79.69%, 0.9948 81.25%, 0.9957 82.81%, 0.9967 84.38%, 0.9975 85.94%, 0.9983 87.5%, 0.999 89.06%, 0.9995 90.63%, 1 92.19%, 1.0004 93.75%, 1.0007 95.31%, 1 96.88%, 1 98.44%, 1 100%)
```
```css
linear(0 0%, 0.0089 0.96%, 0.0315 1.92%, 0.0628 2.88%, 0.0994 3.85%, 0.1389 4.81%, 0.1797 5.77%, 0.2206 6.73%, 0.2611 7.69%, 0.3004 8.65%, 0.3384 9.62%, 0.3749 10.58%, 0.4097 11.54%, 0.4428 12.5%, 0.4742 13.46%, 0.504 14.42%, 0.5323 15.38%, 0.5589 16.35%, 0.5841 17.31%, 0.6079 18.27%, 0.6303 19.23%, 0.6515 20.19%, 0.6715 21.15%, 0.6903 22.12%, 0.7081 23.08%, 0.7249 24.04%, 0.7406 25%, 0.7555 25.96%, 0.7696 26.92%, 0.7828 27.88%, 0.7953 28.85%, 0.807 29.81%, 0.8181 30.77%, 0.8286 31.73%, 0.8384 32.69%, 0.8477 33.65%, 0.8564 34.62%, 0.8647 35.58%, 0.8724 36.54%, 0.8798 37.5%, 0.8867 38.46%, 0.8932 39.42%, 0.8993 40.38%, 0.9051 41.35%, 0.9105 42.31%, 0.9157 43.27%, 0.9205 44.23%, 0.9251 45.19%, 0.9294 46.15%, 0.9334 47.12%, 0.9373 48.08%, 0.9409 49.04%, 0.9443 50%, 0.9475 50.96%, 0.9505 51.92%, 0.9533 52.88%, 0.956 53.85%, 0.9585 54.81%, 0.9609 55.77%, 0.9632 56.73%, 0.9653 57.69%, 0.9673 58.65%, 0.9691 59.62%, 0.9709 60.58%, 0.9726 61.54%, 0.9742 62.5%, 0.9756 63.46%, 0.977 64.42%, 0.9784 65.38%, 0.9796 66.35%, 0.9808 67.31%, 0.9819 68.27%, 0.9829 69.23%, 0.9839 70.19%, 0.9848 71.15%, 0.9857 72.12%, 0.9865 73.08%, 0.9873 74.04%, 0.988 75%, 0.9887 75.96%, 0.9894 76.92%, 0.99 77.88%, 0.9905 78.85%, 0.9911 79.81%, 0.9916 80.77%, 0.9921 81.73%, 0.9925 82.69%, 0.993 83.65%, 0.9934 84.62%, 0.9938 85.58%, 0.9941 86.54%, 0.9944 87.5%, 0.9948 88.46%, 0.9951 89.42%, 0.9954 90.38%, 0.9956 91.35%, 0.9959 92.31%, 0.9961 93.27%, 0.9963 94.23%, 0.9965 95.19%, 1 96.15%, 1 97.12%, 1 98.08%, 1 99.04%, 1 100%)
```

Libraries detected: three, canvas, next, tailwindLike.

## Intro choreography (ms after load)
- 0ms — div.origin-center-left.order-2 544×410 (intro-fade-up-3)
- 8498ms — div.mb-2.flex (intro-fade-1)
- 8498ms — div 1232×659 (intro-fade-5)
- 8598ms — div (intro-fade-2)
- 9054ms — ? (intro-fade-up-scale-6)
- 9054ms — ? (intro-fade-scale-7)
- 9080ms — div.relative.rounded-full 8×8 (intro-tint-4)

## Load / intro
Plays once when the page loads. Use `data-intro="<name>"` with motion.css; set `--i` for stagger order.

### intro-fade-1 — ×7
Seen on: div.mb-2.flex
- from `opacity: 0;` to `opacity: 1;`
- 650ms, `linear(0 0%, 0.0144 1.56%, 0.0538 3.13%, 0.1123 4.69%, 0.1848 6.25%, 0…` (bezier fallback `cubic-bezier(0.36,0.8,0.29,1.35)`) — source: waapi
```css
@keyframes intro-fade-1 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-2 — ×5
Seen on: div
- from `opacity: 0;` to `opacity: 1;`
- 1050ms, `linear(0 0%, 0.0089 0.96%, 0.0315 1.92%, 0.0628 2.88%, 0.0994 3.85%, 0…` (bezier fallback `cubic-bezier(0.17,1.05,0.21,1)`), delay 100ms — source: waapi
```css
@keyframes intro-fade-2 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-up-3 — ×4
Seen on: div.origin-center-left.order-2 544×410; div.animate-hero-text-slide-up-fade.z-10 533×474; h1.effect-font-styling.font-domaine “Automations for modern e” 533×166; p.text-base.md:text-[1.125rem] “Send emails based on cus” 408×54
- from `transform: translateY(16px); opacity: 0;` to `transform: translateY(0px); opacity: 1;`
- 1000ms, `ease-in-out` — source: css-animation
```css
@keyframes intro-fade-up-3 { 0%{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
```
### intro-tint-4 — ×3
Seen on: div.relative.rounded-full 8×8
- from `background-color: #6a7282;` to `background-color: #00c950;`
- 150ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
@keyframes intro-tint-4 {
  from { background-color: #6a7282; }
  to { background-color: #00c950; }
}
```
### intro-fade-5 — ×2
Seen on: div 1232×659; div 1232×992
- from `opacity: 0;` to `opacity: 1;`
- 500ms, `ease-out` — source: waapi
```css
@keyframes intro-fade-5 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-fade-up-scale-6 — ×1
Seen on: ?
- from `transform: scale(0.98) translateY(5px); opacity: 0;` to `transform: scale(1) translateY(0px); opacity: 1;`
- 1500ms, `ease-in-out` — source: css-animation
```css
@keyframes intro-fade-up-scale-6 { 0%{opacity:0;transform:scale(.98)translateY(5px)} to{opacity:1;transform:scale(1)translateY(0)} }
```
### intro-fade-scale-7 — ×1
Seen on: ?
- from `transform: scale(0.7); opacity: 0;` to `transform: scale(1); opacity: 1;`
- 1000ms, `ease-in-out` — source: css-animation
```css
@keyframes intro-fade-scale-7 { 0%{opacity:0;transform:scale(.7)} to{opacity:1;transform:scale(1)} }
```
### intro-fade-8 — ×1
Seen on: div
- from `opacity: 0;` to `opacity: 1;`
- 240ms, `cubic-bezier(0.36, 0.66, 0.6, 1)` — source: waapi
```css
@keyframes intro-fade-8 {
  from { opacity: 0; }
  to { opacity: 1; }
}
```
### intro-tint-9 — ×1
Seen on: div.mb-4.rounded-2xl 1024×98
- from `background-color: rgb(25, 27, 30);` to `background-color: rgb(20, 21, 23);`
- 150ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
@keyframes intro-tint-9 {
  from { background-color: rgb(25, 27, 30); }
  to { background-color: rgb(20, 21, 23); }
}
```
### intro-spin-10 — ×1
Seen on: svg.mr-2.inline-block 14×14
- from `transform: rotate(nonedeg);` to `transform: rotate(90degdeg);`
- 300ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
@keyframes intro-spin-10 {
  from { transform: rotate(nonedeg); }
  to { transform: rotate(90degdeg); }
}
```
### intro-fade-11 — ×1
Seen on: div.h-(--accordion-panel-height).overflow-hidden 1022×40
- from `opacity: 0; height: 0px;` to `opacity: 1; height: 40px;`
- 300ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
@keyframes intro-fade-11 {
  from { opacity: 0; height: 0px; }
  to { opacity: 1; height: 40px; }
}
```
### intro-height-12 — ×1
Seen on: div.bg-black.isolate 1440×8678
- from `height: 4247.3px;` to `height: 9513.1px;`
- 396ms, `cubic-bezier(0.04,1.46,1,0.1)` — source: js
```css
@keyframes intro-height-12 {
  from { height: 4247.3px; }
  to { height: 9513.1px; }
}
```
### intro-height-13 — ×1
Seen on: div.mx-auto.w-full 1280×6893
- from `height: 3993.5px;` to `height: 7728px;`
- 397ms, `cubic-bezier(0.2,1.36,1,-0.16)` — source: js
```css
@keyframes intro-height-13 {
  from { height: 3993.5px; }
  to { height: 7728px; }
}
```
### intro-height-14 — ×1
Seen on: div.mx-auto.w-full 1024×5956
- from `height: 3881.5px;` to `height: 6793.6px;`
- 396ms, `cubic-bezier(0.01,1.48,1,0.14)` — source: js
```css
@keyframes intro-height-14 {
  from { height: 3881.5px; }
  to { height: 6793.6px; }
}
```

## Scroll reveals
Triggered as elements enter the viewport. Use `data-reveal="<name>"`; motion.js observes them at the measured entry point.

### reveal-fade-17 — ×9
Seen on: div.flex.w-full 357×135
- from `opacity: 0;` to `opacity: 1;`
- 300ms, `cubic-bezier(0.25, 0.1, 0.35, 1)`, stagger 559ms between siblings, starts at 91% viewport — source: waapi
```css
[data-reveal="reveal-fade-17"] { opacity: 0; transition: opacity 300ms cubic-bezier(0.25, 0.1, 0.35, 1); }
[data-reveal="reveal-fade-17"].is-in { opacity: 1; }
```
### reveal-fade-18 — ×2
Seen on: ?
- from `opacity: 0;` to `opacity: 1;`
- 1050ms, `linear(0 0%, 0.0089 0.96%, 0.0315 1.92%, 0.0628 2.88%, 0.0994 3.85%, 0…` (bezier fallback `cubic-bezier(0.17,1.05,0.21,1)`), delay 100ms — source: waapi
```css
[data-reveal="reveal-fade-18"] { opacity: 0; transition: opacity 1050ms linear(0 0%, 0.0089 0.96%, 0.0315 1.92%, 0.0628 2.88%, 0.0994 3.85%, 0.1389 4.81%, 0.1797 5.77%, 0.2206 6.73%, 0.2611 7.69%, 0.3004 8.65%, 0.3384 9.62%, 0.3749 10.58%, 0.4097 11.54%, 0.4428 12.5%, 0.4742 13.46%, 0.504 14.42%, 0.5323 15.38%, 0.5589 16.35%, 0.5841 17.31%, 0.6079 18.27%, 0.6303 19.23%, 0.6515 20.19%, 0.6715 21.15%, 0.6903 22.12%, 0.7081 23.08%, 0.7249 24.04%, 0.7406 25%, 0.7555 25.96%, 0.7696 26.92%, 0.7828 27.88%, 0.7953 28.85%, 0.807 29.81%, 0.8181 30.77%, 0.8286 31.73%, 0.8384 32.69%, 0.8477 33.65%, 0.8564 34.62%, 0.8647 35.58%, 0.8724 36.54%, 0.8798 37.5%, 0.8867 38.46%, 0.8932 39.42%, 0.8993 40.38%, 0.9051 41.35%, 0.9105 42.31%, 0.9157 43.27%, 0.9205 44.23%, 0.9251 45.19%, 0.9294 46.15%, 0.9334 47.12%, 0.9373 48.08%, 0.9409 49.04%, 0.9443 50%, 0.9475 50.96%, 0.9505 51.92%, 0.9533 52.88%, 0.956 53.85%, 0.9585 54.81%, 0.9609 55.77%, 0.9632 56.73%, 0.9653 57.69%, 0.9673 58.65%, 0.9691 59.62%, 0.9709 60.58%, 0.9726 61.54%, 0.9742 62.5%, 0.9756 63.46%, 0.977 64.42%, 0.9784 65.38%, 0.9796 66.35%, 0.9808 67.31%, 0.9819 68.27%, 0.9829 69.23%, 0.9839 70.19%, 0.9848 71.15%, 0.9857 72.12%, 0.9865 73.08%, 0.9873 74.04%, 0.988 75%, 0.9887 75.96%, 0.9894 76.92%, 0.99 77.88%, 0.9905 78.85%, 0.9911 79.81%, 0.9916 80.77%, 0.9921 81.73%, 0.9925 82.69%, 0.993 83.65%, 0.9934 84.62%, 0.9938 85.58%, 0.9941 86.54%, 0.9944 87.5%, 0.9948 88.46%, 0.9951 89.42%, 0.9954 90.38%, 0.9956 91.35%, 0.9959 92.31%, 0.9961 93.27%, 0.9963 94.23%, 0.9965 95.19%, 1 96.15%, 1 97.12%, 1 98.08%, 1 99.04%, 1 100%) 100ms; }
[data-reveal="reveal-fade-18"].is-in { opacity: 1; }
```
### reveal-fade-19 — ×2
Seen on: ?
- from `opacity: 0;` to `opacity: 1;`
- 650ms, `linear(0 0%, 0.0144 1.56%, 0.0538 3.13%, 0.1123 4.69%, 0.1848 6.25%, 0…` (bezier fallback `cubic-bezier(0.36,0.8,0.29,1.35)`) — source: waapi
```css
[data-reveal="reveal-fade-19"] { opacity: 0; transition: opacity 650ms linear(0 0%, 0.0144 1.56%, 0.0538 3.13%, 0.1123 4.69%, 0.1848 6.25%, 0.2668 7.81%, 0.3542 9.38%, 0.4436 10.94%, 0.5321 12.5%, 0.6174 14.06%, 0.6977 15.63%, 0.7716 17.19%, 0.8384 18.75%, 0.8974 20.31%, 0.9484 21.88%, 0.9915 23.44%, 1.0269 25%, 1.0551 26.56%, 1.0765 28.13%, 1.0918 29.69%, 1.1018 31.25%, 1.1071 32.81%, 1.1084 34.38%, 1.1065 35.94%, 1.1019 37.5%, 1.0953 39.06%, 1.0873 40.63%, 1.0783 42.19%, 1.0688 43.75%, 1.0591 45.31%, 1.0495 46.88%, 1.0404 48.44%, 1.0317 50%, 1.0238 51.56%, 1.0167 53.13%, 1.0104 54.69%, 1.005 56.25%, 1.0004 57.81%, 0.9967 59.38%, 0.9937 60.94%, 0.9915 62.5%, 0.9899 64.06%, 0.9889 65.63%, 0.9883 67.19%, 0.9882 68.75%, 0.9885 70.31%, 0.989 71.88%, 0.9898 73.44%, 0.9906 75%, 0.9916 76.56%, 0.9927 78.13%, 0.9937 79.69%, 0.9948 81.25%, 0.9957 82.81%, 0.9967 84.38%, 0.9975 85.94%, 0.9983 87.5%, 0.999 89.06%, 0.9995 90.63%, 1 92.19%, 1.0004 93.75%, 1.0007 95.31%, 1 96.88%, 1 98.44%, 1 100%); }
[data-reveal="reveal-fade-19"].is-in { opacity: 1; }
```
### reveal-fade-down-20 — ×1
Seen on: header.sticky.top-0 1440×58
- from `transform: translateY(-16px); opacity: 0;` to `transform: translateY(0px); opacity: 1;`
- 1000ms, `ease-in-out` — source: css-animation
```css
[data-reveal="reveal-fade-down-20"] { transform: translateY(-16px); opacity: 0; transition: transform 1000ms ease-in-out,
    opacity 1000ms ease-in-out; }
[data-reveal="reveal-fade-down-20"].is-in { transform: translateY(0px); opacity: 1; }
```
### reveal-fade-21 — ×1
Seen on: div.relative.hidden 1232×265
- from `opacity: 0;` to `opacity: 1;`
- 2000ms, `ease-out`, starts at 93% viewport — source: waapi
```css
[data-reveal="reveal-fade-21"] { opacity: 0; transition: opacity 2000ms ease-out; }
[data-reveal="reveal-fade-21"].is-in { opacity: 1; }
```
### reveal-tint-22 — ×1
Seen on: button.flex.w-full 562×48
- from `background-color: rgb(255 255 255 / 0.05); color: rgb(255 255 255 / 0.6);` to `background-color: rgba(0, 0, 0, 0); color: rgb(74, 74, 74);`
- 250ms, `cubic-bezier(0.215, 0.61, 0.355, 1)`, starts at 71% viewport — source: css-transition
```css
[data-reveal="reveal-tint-22"] { background-color: rgb(255 255 255 / 0.05); color: rgb(255 255 255 / 0.6); transition: background-color 250ms cubic-bezier(0.215, 0.61, 0.355, 1),
    color 250ms cubic-bezier(0.215, 0.61, 0.355, 1); }
[data-reveal="reveal-tint-22"].is-in { background-color: rgba(0, 0, 0, 0); color: rgb(74, 74, 74); }
```
### reveal-boxshadow-23 — ×1
Seen on: div.flex.h-fit 393×136
- from `box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(63 219 143 / 0.4) 0px 0px 0px 1px inset, rgba(0, 0, 0, 0) 0px 0px 0px 0px;` to `box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(112 184 255 / 0.4) 0px 0px 0px 1px inset, rgba(0, 0, 0, 0) 0px 0px 0px 0px;`
- 100ms, `cubic-bezier(0.16, 1, 0.3, 1)`, starts at 91% viewport — source: css-transition
```css
[data-reveal="reveal-boxshadow-23"] { box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(63 219 143 / 0.4) 0px 0px 0px 1px inset, rgba(0, 0, 0, 0) 0px 0px 0px 0px; transition: box-shadow 100ms cubic-bezier(0.16, 1, 0.3, 1); }
[data-reveal="reveal-boxshadow-23"].is-in { box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(112 184 255 / 0.4) 0px 0px 0px 1px inset, rgba(0, 0, 0, 0) 0px 0px 0px 0px; }
```
### reveal-tint-24 — ×1
Seen on: span.inline-flex.min-h-6 “Completed” 67×24
- from `background-color: rgb(24, 50, 38); color: rgb(63, 219, 143);` to `background-color: rgb(0, 0, 0); color: rgb(255 255 255 / 0.7);`
- 100ms, `cubic-bezier(0.16, 1, 0.3, 1)`, starts at 101% viewport — source: css-transition
```css
[data-reveal="reveal-tint-24"] { background-color: rgb(24, 50, 38); color: rgb(63, 219, 143); transition: background-color 100ms cubic-bezier(0.16, 1, 0.3, 1),
    color 100ms cubic-bezier(0.16, 1, 0.3, 1); }
[data-reveal="reveal-tint-24"].is-in { background-color: rgb(0, 0, 0); color: rgb(255 255 255 / 0.7); }
```
### reveal-boxshadow-25 — ×1
Seen on: div.flex.h-fit 344×118
- from `box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(63 219 143 / 0.4) 0px 0px 0px 1px inset, rgba(0, 0, 0, 0) 0px 0px 0px 0px;` to `box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(255 255 255 / 0.1) 0px 0px 0px 1px inset, rgba(0, 0, 0, 0) 0px 0px 0px 0px;`
- 100ms, `cubic-bezier(0.16, 1, 0.3, 1)`, starts at 122% viewport — source: css-transition
```css
[data-reveal="reveal-boxshadow-25"] { box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(63 219 143 / 0.4) 0px 0px 0px 1px inset, rgba(0, 0, 0, 0) 0px 0px 0px 0px; transition: box-shadow 100ms cubic-bezier(0.16, 1, 0.3, 1); }
[data-reveal="reveal-boxshadow-25"].is-in { box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(255 255 255 / 0.1) 0px 0px 0px 1px inset, rgba(0, 0, 0, 0) 0px 0px 0px 0px; }
```
### reveal-fade-up-scale-26 — ×1
Seen on: li.w-full 562×48
- from `transform: translateY(0.5rem) scale(0.985); opacity: 0;` to `transform: translateY(0rem) scale(1); opacity: 1;`
- 250ms, `ease-out`, starts at 66% viewport — source: waapi
```css
[data-reveal="reveal-fade-up-scale-26"] { transform: translateY(0.5rem) scale(0.985); opacity: 0; transition: transform 250ms ease-out,
    opacity 250ms ease-out; }
[data-reveal="reveal-fade-up-scale-26"].is-in { transform: translateY(0rem) scale(1); opacity: 1; }
```
### reveal-down-27 — ×1
Seen on: ul.w-full.max-h-[23rem] 562×672
- from `transform: translate(0px, -24px); height: 624px;` to `transform: translate(0px, 0px); height: 672px;`
- 391ms, `cubic-bezier(0.38,0.15,0.09,0.92)`, starts at 66% viewport — source: js
```css
[data-reveal="reveal-down-27"] { transform: translate(0px, -24px); height: 624px; transition: transform 391ms cubic-bezier(0.38,0.15,0.09,0.92),
    height 391ms cubic-bezier(0.38,0.15,0.09,0.92); }
[data-reveal="reveal-down-27"].is-in { transform: translate(0px, 0px); height: 672px; }
```
### reveal-down-28 — ×1
Seen on: li.w-full 562×48
- from `transform: translate(0px, -46.15px);` to `transform: translate(0px, 0px);`
- 395ms, `cubic-bezier(0.38,0.14,0.08,0.93)`, starts at 66% viewport — source: js
```css
[data-reveal="reveal-down-28"] { transform: translate(0px, -46.15px); transition: transform 395ms cubic-bezier(0.38,0.14,0.08,0.93); }
[data-reveal="reveal-down-28"].is-in { transform: translate(0px, 0px); }
```
### reveal-down-29 — ×1
Seen on: li.w-full 562×48
- from `transform: translate(0px, -42.46px);` to `transform: translate(0px, 0px);`
- 392ms, `cubic-bezier(0.38,0.14,0.08,0.93)`, starts at 71% viewport — source: js
```css
[data-reveal="reveal-down-29"] { transform: translate(0px, -42.46px); transition: transform 392ms cubic-bezier(0.38,0.14,0.08,0.93); }
[data-reveal="reveal-down-29"].is-in { transform: translate(0px, 0px); }
```
### reveal-down-30 — ×1
Seen on: li.w-full 562×48
- from `transform: translate(0px, -38.77px);` to `transform: translate(0px, 0px);`
- 395ms, `cubic-bezier(0.38,0.14,0.08,0.93)`, starts at 77% viewport — source: js
```css
[data-reveal="reveal-down-30"] { transform: translate(0px, -38.77px); transition: transform 395ms cubic-bezier(0.38,0.14,0.08,0.93); }
[data-reveal="reveal-down-30"].is-in { transform: translate(0px, 0px); }
```

## Hover
Measured by hovering every distinct interactive element.

### hover-fade-scale-41 — ×28
Seen on: ?; nav.relative.h-[var(--popup-height)]; div.transition-[opacity,transform,translate].duration-[350ms]
- from `transform: scale(0.9); opacity: 0;` to `transform: scale(none); opacity: 1;`
- 350ms, `cubic-bezier(0.22, 1, 0.36, 1)`, stagger 141ms between siblings — source: css-transition
```css
transition: transform 350ms cubic-bezier(0.22, 1, 0.36, 1),
    opacity 350ms cubic-bezier(0.22, 1, 0.36, 1);
```
### hover-tint-42 — ×17
Seen on: a.outline-hidden.relative “Log in” 77×40; a.outline-hidden.relative “Get started” 116×40; a.relative.inline-flex “Get started” 133×48; a.relative.inline-flex “Documentation” 163×48
- from `color: rgb(161, 164, 165);` to `color: rgb(240, 240, 240);`
- 200ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
transition: color 200ms cubic-bezier(0.4, 0, 0.2, 1);
```
### hover-translate-43 — ×16
Seen on: svg.opacity-70.-ml-0.5 14×14
- from `translate: none;` to `translate: 0px 2px;`
- 200ms, `cubic-bezier(0.4, 0, 1, 1)` — source: css-transition
```css
transition: translate 200ms cubic-bezier(0.4, 0, 1, 1);
```
### hover-tint-44 — ×11
Seen on: a.outline-hidden.transition 32×32; div.mb-4.rounded-2xl 1024×58; button.transition.text-sm “Report a problem”; button.transition.text-sm 136×36
- from `background-color: rgba(0, 0, 0, 0);` to `background-color: rgba(221, 234, 248, 0.08);`
- 150ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
transition: background-color 150ms cubic-bezier(0.4, 0, 0.2, 1);
```
### hover-tint-45 — ×10
Seen on: a.outline-hidden.relative “Get started” 116×40; a.relative.inline-flex “Get started” 133×48; button.inline-flex.items-center 32×32; button.inline-flex.shrink-0 “user-welcome.tsx” 183×32
- from `background-color: rgba(0, 0, 0, 0); box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.1) 0px 1px 3px 0px, rgba(0, 0, 0, 0.1) 0px 1px 2px -1px;` to `background-color: rgb(255 255 255 / 0.9); box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(255, 255, 255, 0.06) 0px 0px 4px 0px, rgba(255, 255, 255, 0.12) 0px 1px 14px 0px, rgba(255, 255, 255, 0.18) 0px 3px 32px 0px;`
- 200ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
transition: background-color 200ms cubic-bezier(0.4, 0, 0.2, 1),
    box-shadow 200ms cubic-bezier(0.4, 0, 0.2, 1);
```
### hover-tint-46 — ×10
Seen on: a.outline-hidden.transition 114×20; a.outline-hidden.transition “Learn more” 300×20; a.transition.duration-150 “Automations” 88×21; svg.text-slate-300.dark:text-slate-500 16×16
- from `color: rgb(161, 164, 165);` to `color: rgb(240, 240, 240);`
- 150ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
transition: color 150ms cubic-bezier(0.4, 0, 0.2, 1);
```
### hover-translate-47 — ×8
Seen on: div.transition-[opacity,transform,translate].duration-[350ms]
- from `translate: none;` to `translate: -50%;`
- 350ms, `cubic-bezier(0.22, 1, 0.36, 1)`, stagger 27ms between siblings — source: css-transition
```css
transition: translate 350ms cubic-bezier(0.22, 1, 0.36, 1);
```
### hover-fade-48 — ×6
Seen on: ?; div.bg-background.border; div.bg-background.border “Maximum emails sent per ”
- from `opacity: 0; translate: 0px -4px;` to `opacity: 1; translate: none;`
- 200ms, `cubic-bezier(0, 0, 0.2, 1)` — source: css-transition
```css
transition: opacity 200ms cubic-bezier(0, 0, 0.2, 1),
    translate 200ms cubic-bezier(0, 0, 0.2, 1);
```
### hover-fade-49 — ×6
Seen on: div.absolute.inset-0 186×32
- from `opacity: 0.1;` to `opacity: 0.15;`
- 300ms, `cubic-bezier(0.36, 0.66, 0.6, 1)` — source: css-transition
```css
transition: opacity 300ms cubic-bezier(0.36, 0.66, 0.6, 1);
```
### hover-fade-50 — ×6
Seen on: div.absolute.inset-0 186×32
- from `opacity: 0.05;` to `opacity: 0.1;`
- 150ms, `linear` — source: css-transition
```css
transition: opacity 150ms linear;
```
### hover-tint-51 — ×6
Seen on: button.transition.text-sm “Report a problem”; button.transition.text-sm 136×36
- from `border-bottom-color: rgb(57, 57, 63);` to `border-bottom-color: rgb(95, 95, 104);`
- 150ms, `cubic-bezier(0.4, 0, 0.2, 1)` — source: css-transition
```css
transition: border-bottom-color 150ms cubic-bezier(0.4, 0, 0.2, 1);
```
