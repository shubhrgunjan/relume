# Components

Each variant is the clustered style of every element that looked the same across the crawled pages. Classes of the same name are in `assets/tokens.css`. Crops are in `assets/reference/`.

## link (link, ×90)
![link](../assets/reference/link.jpg)
Examples: “Automations”, “Audiences”, “Broadcasts”, “Inbound”

| property | value |
|---|---|
| background | `transparent` |
| color | `rgb(241 247 254 / 0.71)` |
| radius | `6px` |
| font | `400 14px/20px` |
| family | `inter` |
| padding | `2px 4px 2px 4px` |
| transition | `color 0.15s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), outline-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), text-decoration-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), fill 0.15s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-from 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-via 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-to 0.15s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.15s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.15s cubic-bezier(0.4, 0, 0.2, 1), transform 0.15s cubic-bezier(0.4, 0, 0.2, 1), translate 0.15s cubic-bezier(0.4, 0, 0.2, 1), scale 0.15s cubic-bezier(0.4, 0, 0.2, 1), rotate 0.15s cubic-bezier(0.4, 0, 0.2, 1), filter 0.15s cubic-bezier(0.4, 0, 0.2, 1), -webkit-backdrop-filter 0.15s cubic-bezier(0.4, 0, 0.2, 1), backdrop-filter 0.15s cubic-bezier(0.4, 0, 0.2, 1), display 0.15s cubic-bezier(0.4, 0, 0.2, 1), content-visibility 0.15s cubic-bezier(0.4, 0, 0.2, 1), overlay 0.15s cubic-bezier(0.4, 0, 0.2, 1), pointer-events 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 21px tall, from 38px wide, padding 2px × 4px.

**Hover**
| property | rest | hover |
|---|---|---|
| color | `rgba(241, 247, 254, 0.71)` | `rgba(247, 250, 255, 0.816)` |
| borderTopColor | `rgba(241, 247, 254, 0.71)` | `rgba(247, 250, 255, 0.816)` |
| outlineColor | `rgba(241, 247, 254, 0.71)` | `rgba(247, 250, 255, 0.816)` |
Transitions: color 150ms cubic-bezier(0.4, 0, 0.2, 1)
Inside it: ? — opacity 500ms cubic-bezier(0, 0, 0.2, 1)

**Focus-visible**: outline `1px none rgba(241, 247, 254, 0.71)`, offset 1px, shadow `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px`

## link-2 (link, ×3)
![link-2](../assets/reference/link-2.jpg)
Examples: “Pricing”

| property | value |
|---|---|
| background | `transparent` |
| color | `#a1a4a5` |
| font | `500 14px/20px` |
| family | `inter` |
| padding | `4px 16px 4px 16px` |
| transition | `color 0.15s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), outline-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), text-decoration-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), fill 0.15s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-from 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-via 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-to 0.15s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.15s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.15s cubic-bezier(0.4, 0, 0.2, 1), transform 0.15s cubic-bezier(0.4, 0, 0.2, 1), translate 0.15s cubic-bezier(0.4, 0, 0.2, 1), scale 0.15s cubic-bezier(0.4, 0, 0.2, 1), rotate 0.15s cubic-bezier(0.4, 0, 0.2, 1), filter 0.15s cubic-bezier(0.4, 0, 0.2, 1), -webkit-backdrop-filter 0.15s cubic-bezier(0.4, 0, 0.2, 1), backdrop-filter 0.15s cubic-bezier(0.4, 0, 0.2, 1), display 0.15s cubic-bezier(0.4, 0, 0.2, 1), content-visibility 0.15s cubic-bezier(0.4, 0, 0.2, 1), overlay 0.15s cubic-bezier(0.4, 0, 0.2, 1), pointer-events 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 58px tall, from 80px wide, padding 4px × 16px.

**Hover**
| property | rest | hover |
|---|---|---|

Inside it: svg.opacity-70.-ml-0.5 14×14 — translate 200ms cubic-bezier(0.4, 0, 1, 1); ? — opacity 350ms cubic-bezier(0.22, 1, 0.36, 1); ? — scale 350ms cubic-bezier(0.22, 1, 0.36, 1); ? — opacity 350ms cubic-bezier(0.22, 1, 0.36, 1); svg.opacity-70.-ml-0.5 14×14 — translate 65ms cubic-bezier(0.4, 0, 1, 1); ? — opacity 122ms cubic-bezier(0.22, 1, 0.36, 1)

**Focus-visible**: outline `1px none rgb(161, 164, 165)`, offset 1px, shadow `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px`

## card (card, ×60)
![card](../assets/reference/card.jpg)

| property | value |
|---|---|
| background | `linear-gradient(rgba(80, 80, 80, 0.15) 0%, rgba(0, 0, 0, 0) 70%)` |
| color | `#f0f0f0` |
| border | `1px solid rgb(217 237 254 / 0.145)` |
| radius | `16px` |
| font | `400 16px/24px` |
| family | `inter` |
| padding | `24px 32px 24px 32px` |
| cursor | `grab` |
Size: 219px tall, from 450px wide, padding 24px × 32px.

## card-2 (card, ×10)
![card-2](../assets/reference/card-2.jpg)
Examples: “Email for developers”, “First-class developer experience”, “Reach humans, not spam folders”, “Email reimagined. Available today.”

| property | value |
|---|---|
| background | `linear-gradient(to right bottom, rgb(255, 255, 255) 30%, rgba(255, 255, 255, 0.5))` |
| color | `#f0f0f0` |
| font | `400 96px/96px` |
| family | `domaine` |
| letterSpacing | `-0.96px` |
| padding | `0px 0px 12px 0px` |
Size: 204px tall, from 383px wide, padding 0px × 0px.

## card-3 (card, ×10)
![card-3](../assets/reference/card-3.jpg)

| property | value |
|---|---|
| background | `linear-gradient(rgba(0, 0, 0, 0) 0%, rgb(0, 0, 0) 50%, rgb(0, 0, 0) 100%)` |
| color | `#f0f0f0` |
| font | `400 16px/24px` |
| family | `inter` |
| padding | `0px 0px 0px 0px` |
Size: 529px tall, from 405px wide, padding 0px × 0px.

## card-4 (card, ×9)
![card-4](../assets/reference/card-4.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#f0f0f0` |
| border | `1px solid rgb(214 235 253 / 0.19)` |
| radius | `24px` |
| font | `400 16px/24px` |
| family | `inter` |
| padding | `96px 24px 96px 24px` |
Size: 567px tall, from 600px wide, padding 96px × 24px.

## card-5 (card, ×8)
![card-5](../assets/reference/card-5.jpg)

| property | value |
|---|---|
| background | `radial-gradient(114.08% 50% at 50.2% 0.07%, rgb(0 0 0 / 0.1) 0%, rgba(0, 0, 0, 0) 100%)` |
| color | `#ffffff` |
| radius | `16px` |
| shadow | `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(255 255 255 / 0.1) 0px 0px 0px 1px inset, rgba(0, 0, 0, 0) 0px 0px 0px 0px` |
| font | `400 12px/17.04px` |
| family | `inter` |
| padding | `20px 20px 20px 20px` |
| gap | `12px` |
| transition | `padding 0.05s cubic-bezier(0.16, 1, 0.3, 1), border-radius 0.05s cubic-bezier(0.16, 1, 0.3, 1), width 0.05s cubic-bezier(0.16, 1, 0.3, 1), min-height 0.05s cubic-bezier(0.16, 1, 0.3, 1)` |
Size: 103px tall, from 256px wide, padding 20px × 20px.

## card-6 (card, ×6)
![card-6](../assets/reference/card-6.jpg)

| property | value |
|---|---|
| background | `conic-gradient(from 90deg, rgba(0, 0, 0, 0) 50%, rgb(0, 0, 0) 50%), radial-gradient(rgba(200, 200, 200, 0.1) 0%, rgba(0, 0, 0, 0) 80%)` |
| color | `#f0f0f0` |
| font | `400 16px/24px` |
| family | `inter` |
| padding | `0px 0px 0px 0px` |
Size: 200px tall, from 320px wide, padding 0px × 0px.

## card-7 (card, ×6)
![card-7](../assets/reference/card-7.jpg)

| property | value |
|---|---|
| background | `rgb(214 235 253 / 0.19)` |
| color | `#f0f0f0` |
| radius | `16px` |
| font | `400 16px/24px` |
| family | `inter` |
| padding | `0px 0px 0px 0px` |
| cursor | `pointer` |
Size: 90px tall, from 389px wide, padding 0px × 0px.

**Focus-visible**: outline `1px none rgb(238, 238, 238)`, offset 0px, shadow `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(214, 235, 253, 0.19) 0px 0px 0px 2px, rgba(0, 0, 0, 0) 0px 0px 0px 0px`

## card-8 (card, ×3)
![card-8](../assets/reference/card-8.jpg)

| property | value |
|---|---|
| background | `linear-gradient(0deg, rgb(0, 0, 0) 0%, rgba(0, 0, 0, 0) 40%, rgba(0, 0, 0, 0) 100%, rgb(0, 0, 0) 100%)` |
| color | `#f0f0f0` |
| font | `400 16px/24px` |
| family | `inter` |
| padding | `0px 0px 0px 0px` |
Size: 324px tall, from 598px wide, padding 0px × 0px.

## badge (badge, ×20)
![badge](../assets/reference/badge.jpg)
Examples: “melia@gmail.com”, “Spam”, “Gmail”, “Windows”

| property | value |
|---|---|
| background | `linear-gradient(in oklab, rgba(217, 237, 254, 0.145) 0%, rgba(221, 234, 248, 0.08) 50%, rgba(0, 0, 0, 0) 100%)` |
| color | `#ffffff` |
| border | `1px solid rgb(214 235 253 / 0.19)` |
| radius | `6px` |
| font | `400 14px/20px` |
| family | `inter` |
| padding | `2px 6px 2px 6px` |
| gap | `8px` |
Size: 26px tall, from 51px wide, padding 2px × 6px.

## badge-2 (badge, ×11)
![badge-2](../assets/reference/badge-2.jpg)
Examples: “Completed”

| property | value |
|---|---|
| background | `#183226` |
| color | `#3fdb8f` |
| radius | `8px` |
| font | `500 12px/12px` |
| family | `inter` |
| padding | `0px 8px 0px 8px` |
| cursor | `not-allowed` |
Size: 24px tall, from 83px wide, padding 0px × 8px.

## badge-3 (badge, ×2)
![badge-3](../assets/reference/badge-3.jpg)
Examples: “delivered”

| property | value |
|---|---|
| background | `rgb(34 255 153 / 0.118)` |
| color | `rgb(70 254 165 / 0.83)` |
| border | `1px solid transparent` |
| radius | `10px` |
| font | `500 12px/16px` |
| family | `inter` |
| textTransform | `capitalize` |
| padding | `0px 8px 0px 8px` |
| cursor | `default` |
Size: 28px tall, from 77px wide, padding 0px × 8px.

## badge-4 (badge, ×2)
![badge-4](../assets/reference/badge-4.jpg)
Examples: “complained”

| property | value |
|---|---|
| background | `rgb(250 130 0 / 0.133)` |
| color | `#ffca16` |
| border | `1px solid transparent` |
| radius | `10px` |
| font | `500 12px/16px` |
| family | `inter` |
| textTransform | `capitalize` |
| padding | `0px 8px 0px 8px` |
Size: 28px tall, from 90px wide, padding 0px × 8px.

## badge-5 (badge, ×1)
![badge-5](../assets/reference/badge-5.jpg)
Examples: “bounced”

| property | value |
|---|---|
| background | `rgb(255 23 63 / 0.176)` |
| color | `#ff9592` |
| border | `1px solid transparent` |
| radius | `10px` |
| font | `500 12px/16px` |
| family | `inter` |
| textTransform | `capitalize` |
| padding | `0px 8px 0px 8px` |
Size: 28px tall, from 71px wide, padding 0px × 8px.

## badge-6 (badge, ×1)
![badge-6](../assets/reference/badge-6.jpg)
Examples: “opened”

| property | value |
|---|---|
| background | `rgb(0 119 255 / 0.227)` |
| color | `#70b8ff` |
| border | `1px solid transparent` |
| radius | `10px` |
| font | `500 12px/16px` |
| family | `inter` |
| textTransform | `capitalize` |
| padding | `0px 8px 0px 8px` |
Size: 28px tall, from 67px wide, padding 0px × 8px.

## button-secondary (button, ×9)
![button-secondary](../assets/reference/button-secondary.jpg)
Examples: “Get started”, “Contact us”, “Add domains”, “Request dedicated IP”

| property | value |
|---|---|
| background | `linear-gradient(104deg, rgba(253, 253, 253, 0.05) 5%, rgba(240, 240, 228, 0.1) 100%)` |
| color | `#ffffff` |
| border | `2px solid rgb(255 255 255 / 0.05)` |
| radius | `16px` |
| shadow | `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.1) 0px 1px 3px 0px, rgba(0, 0, 0, 0.1) 0px 1px 2px -1px` |
| font | `600 14px/20px` |
| family | `inter` |
| padding | `0px 16px 0px 16px` |
| transition | `all 0.2s cubic-bezier(0.4, 0, 0.2, 1)` |
| backdrop | `blur(25px)` |
| cursor | `pointer` |
| ::after | `{"content":"\"\"","backgroundColor":"rgba(0, 0, 0, 0)","width":"116px","height":"40px","position":"absolute","transform":"none","transitionProperty":"all","transitionDuration":"0s","transitionTimingFunction":"ease","borderRadius":"16px","opacity":"1","backgroundImage":"url(\"https://resend.com/stati` |
Size: 40px tall, from 116px wide, padding 0px × 16px.

**Hover**
| property | rest | hover |
|---|---|---|
| color | `rgb(255, 255, 255)` | `rgb(0, 0, 0)` |
| backgroundColor | `rgba(0, 0, 0, 0)` | `rgb(255 255 255 / 0.9)` |
| boxShadow | `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.1) 0px 1px 3px 0px, rgba(0, 0, 0, 0.1) 0px 1px 2px -1px` | `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(255, 255, 255, 0.06) 0px 0px 4px 0px, rgba(255, 255, 255, 0.12) 0px 1px 14px 0px, rgba(255, 255, 255, 0.18) 0px 3px 32px 0px` |
| outlineColor | `rgb(255, 255, 255)` | `rgb(0, 0, 0)` |
Transitions: backgroundColor 200ms cubic-bezier(0.4, 0, 0.2, 1); boxShadow 200ms cubic-bezier(0.4, 0, 0.2, 1); color 200ms cubic-bezier(0.4, 0, 0.2, 1)
Inside it: svg.opacity-70.-ml-0.5 14×14 — translate 200ms cubic-bezier(0.4, 0, 1, 1); ? — opacity 350ms cubic-bezier(0.22, 1, 0.36, 1); ? — scale 350ms cubic-bezier(0.22, 1, 0.36, 1); ? — opacity 350ms cubic-bezier(0.22, 1, 0.36, 1); svg.opacity-70.-ml-0.5 14×14 — translate 104ms cubic-bezier(0.4, 0, 1, 1); ? — opacity 136ms cubic-bezier(0.22, 1, 0.36, 1)

**Focus-visible**: outline `3px none rgb(255, 255, 255)`, offset 0px, shadow `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(0 0 0 / 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.1) 0px 1px 3px 0px, rgba(0, 0, 0, 0.1) 0px 1px 2px -1px`

## button-secondary-2 (button, ×8)
![button-secondary-2](../assets/reference/button-secondary-2.jpg)
Examples: “Get started”, “Sign up for free”, “View pricing”

| property | value |
|---|---|
| background | `linear-gradient(104deg, rgba(253, 253, 253, 0.05) 5%, rgba(240, 240, 228, 0.1) 100%)` |
| color | `#ffffff` |
| border | `2px solid rgb(255 255 255 / 0.05)` |
| radius | `16px` |
| shadow | `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.1) 0px 1px 3px 0px, rgba(0, 0, 0, 0.1) 0px 1px 2px -1px` |
| font | `600 16px/24px` |
| family | `inter` |
| padding | `0px 20px 0px 20px` |
| gap | `4px` |
| transition | `all 0.2s cubic-bezier(0.4, 0, 0.2, 1)` |
| backdrop | `blur(25px)` |
| cursor | `pointer` |
| ::after | `{"content":"\"\"","backgroundColor":"rgba(0, 0, 0, 0)","width":"133px","height":"48px","position":"absolute","transform":"none","transitionProperty":"all","transitionDuration":"0s","transitionTimingFunction":"ease","borderRadius":"16px","opacity":"1","backgroundImage":"url(\"https://resend.com/stati` |
Size: 48px tall, from 133px wide, padding 0px × 20px.

**Hover**
| property | rest | hover |
|---|---|---|
| color | `rgb(255, 255, 255)` | `rgb(0, 0, 0)` |
| backgroundColor | `rgba(0, 0, 0, 0)` | `rgb(255 255 255 / 0.9)` |
| boxShadow | `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.1) 0px 1px 3px 0px, rgba(0, 0, 0, 0.1) 0px 1px 2px -1px` | `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(255, 255, 255, 0.06) 0px 0px 4px 0px, rgba(255, 255, 255, 0.12) 0px 1px 14px 0px, rgba(255, 255, 255, 0.18) 0px 3px 32px 0px` |
| outlineColor | `rgb(255, 255, 255)` | `rgb(0, 0, 0)` |
Transitions: backgroundColor 200ms cubic-bezier(0.4, 0, 0.2, 1); boxShadow 200ms cubic-bezier(0.4, 0, 0.2, 1); color 200ms cubic-bezier(0.4, 0, 0.2, 1)

**Focus-visible**: outline `3px none rgb(255, 255, 255)`, offset 0px, shadow `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgb(0 0 0 / 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0.1) 0px 1px 3px 0px, rgba(0, 0, 0, 0.1) 0px 1px 2px -1px`

## button-outline (button, ×5)
![button-outline](../assets/reference/button-outline.jpg)
Examples: “Documentation”, “Explore Enterprise”, “Check the docs”

| property | value |
|---|---|
| background | `transparent` |
| color | `#a1a4a5` |
| border | `1px solid transparent` |
| radius | `16px` |
| font | `600 16px/24px` |
| family | `inter` |
| padding | `0px 20px 0px 20px` |
| gap | `4px` |
| transition | `color 0.2s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.2s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1), outline-color 0.2s cubic-bezier(0.4, 0, 0.2, 1), text-decoration-color 0.2s cubic-bezier(0.4, 0, 0.2, 1), fill 0.2s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.2s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-from 0.2s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-via 0.2s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-to 0.2s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.2s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.2s cubic-bezier(0.4, 0, 0.2, 1), transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), translate 0.2s cubic-bezier(0.4, 0, 0.2, 1), scale 0.2s cubic-bezier(0.4, 0, 0.2, 1), rotate 0.2s cubic-bezier(0.4, 0, 0.2, 1), filter 0.2s cubic-bezier(0.4, 0, 0.2, 1), -webkit-backdrop-filter 0.2s cubic-bezier(0.4, 0, 0.2, 1), backdrop-filter 0.2s cubic-bezier(0.4, 0, 0.2, 1), display 0.2s cubic-bezier(0.4, 0, 0.2, 1), content-visibility 0.2s cubic-bezier(0.4, 0, 0.2, 1), overlay 0.2s cubic-bezier(0.4, 0, 0.2, 1), pointer-events 0.2s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 48px tall, from 163px wide, padding 0px × 20px.

**Hover**
| property | rest | hover |
|---|---|---|
| color | `rgb(161, 164, 165)` | `rgb(240, 240, 240)` |
| outlineColor | `rgb(161, 164, 165)` | `rgb(240, 240, 240)` |
Transitions: color 200ms cubic-bezier(0.4, 0, 0.2, 1)

**Focus-visible**: outline `1px none rgb(161, 164, 165)`, offset 1px, shadow `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px`

## button-outline-2 (button, ×4)
![button-outline-2](../assets/reference/button-outline-2.jpg)
Examples: “Log in”, “Are you an AI agent? See pricing”

| property | value |
|---|---|
| background | `transparent` |
| color | `#a1a4a5` |
| border | `1px solid transparent` |
| radius | `16px` |
| font | `600 14px/20px` |
| family | `inter` |
| padding | `0px 16px 0px 16px` |
| transition | `color 0.2s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.2s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1), outline-color 0.2s cubic-bezier(0.4, 0, 0.2, 1), text-decoration-color 0.2s cubic-bezier(0.4, 0, 0.2, 1), fill 0.2s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.2s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-from 0.2s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-via 0.2s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-to 0.2s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.2s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.2s cubic-bezier(0.4, 0, 0.2, 1), transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), translate 0.2s cubic-bezier(0.4, 0, 0.2, 1), scale 0.2s cubic-bezier(0.4, 0, 0.2, 1), rotate 0.2s cubic-bezier(0.4, 0, 0.2, 1), filter 0.2s cubic-bezier(0.4, 0, 0.2, 1), -webkit-backdrop-filter 0.2s cubic-bezier(0.4, 0, 0.2, 1), backdrop-filter 0.2s cubic-bezier(0.4, 0, 0.2, 1), display 0.2s cubic-bezier(0.4, 0, 0.2, 1), content-visibility 0.2s cubic-bezier(0.4, 0, 0.2, 1), overlay 0.2s cubic-bezier(0.4, 0, 0.2, 1), pointer-events 0.2s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 40px tall, from 77px wide, padding 0px × 16px.

**Hover**
| property | rest | hover |
|---|---|---|
| color | `rgb(161, 164, 165)` | `rgb(240, 240, 240)` |
| outlineColor | `rgb(161, 164, 165)` | `rgb(240, 240, 240)` |
Transitions: color 200ms cubic-bezier(0.4, 0, 0.2, 1)
Inside it: svg.opacity-70.-ml-0.5 14×14 — translate 200ms cubic-bezier(0.4, 0, 1, 1); ? — opacity 350ms cubic-bezier(0.22, 1, 0.36, 1); ? — scale 350ms cubic-bezier(0.22, 1, 0.36, 1); ? — opacity 350ms cubic-bezier(0.22, 1, 0.36, 1); svg.opacity-70.-ml-0.5 14×14 — translate 65ms cubic-bezier(0.4, 0, 1, 1); ? — opacity 285ms cubic-bezier(0.22, 1, 0.36, 1)

**Focus-visible**: outline `1px none rgb(161, 164, 165)`, offset 1px, shadow `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px`

## button-primary (button, ×4)
![button-primary](../assets/reference/button-primary.jpg)

| property | value |
|---|---|
| background | `linear-gradient(to left bottom, rgb(255 255 255 / 0.06) 0%, rgba(0, 0, 0, 0) 100%)` |
| color | `rgb(252 253 255 / 0.937)` |
| border | `1px solid rgb(214 235 253 / 0.19)` |
| radius | `12px` |
| font | `400 16px/24px` |
| family | `inter` |
| padding | `8px 8px 8px 8px` |
| transition | `all 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 40px tall, from 40px wide, padding 8px × 8px.

## button-outline-3 (button, ×3)
![button-outline-3](../assets/reference/button-outline-3.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#f0f0f0` |
| border | `1px solid rgb(255 255 255 / 0.05)` |
| radius | `9999px` |
| font | `400 12px/16px` |
| family | `inter` |
| padding | `8px 16px 8px 14px` |
| gap | `10px` |
| transition | `color 0.15s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), outline-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), text-decoration-color 0.15s cubic-bezier(0.4, 0, 0.2, 1), fill 0.15s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-from 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-via 0.15s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-to 0.15s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.15s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.15s cubic-bezier(0.4, 0, 0.2, 1), transform 0.15s cubic-bezier(0.4, 0, 0.2, 1), translate 0.15s cubic-bezier(0.4, 0, 0.2, 1), scale 0.15s cubic-bezier(0.4, 0, 0.2, 1), rotate 0.15s cubic-bezier(0.4, 0, 0.2, 1), filter 0.15s cubic-bezier(0.4, 0, 0.2, 1), -webkit-backdrop-filter 0.15s cubic-bezier(0.4, 0, 0.2, 1), backdrop-filter 0.15s cubic-bezier(0.4, 0, 0.2, 1), display 0.15s cubic-bezier(0.4, 0, 0.2, 1), content-visibility 0.15s cubic-bezier(0.4, 0, 0.2, 1), overlay 0.15s cubic-bezier(0.4, 0, 0.2, 1), pointer-events 0.15s cubic-bezier(0.4, 0, 0.2, 1)` |
| cursor | `pointer` |
Size: 34px tall, from 188px wide, padding 8px × 14px.

**Hover**
| property | rest | hover |
|---|---|---|

Inside it: div.absolute.inset-0 186×32 — opacity 300ms cubic-bezier(0.36, 0.66, 0.6, 1); div.absolute.inset-0 186×32 — opacity 150ms linear

**Focus-visible**: outline `1px none rgb(240, 240, 240)`, offset 1px, shadow `rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px`

## navbar (navbar, ×3)
![navbar](../assets/reference/navbar.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#f0f0f0` |
| font | `400 16px/24px` |
| family | `inter` |
| padding | `0px 0px 0px 0px` |
| transition | `color 0.2s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.2s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1), outline-color 0.2s cubic-bezier(0.4, 0, 0.2, 1), text-decoration-color 0.2s cubic-bezier(0.4, 0, 0.2, 1), fill 0.2s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.2s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-from 0.2s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-via 0.2s cubic-bezier(0.4, 0, 0.2, 1), --tw-gradient-to 0.2s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.2s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.2s cubic-bezier(0.4, 0, 0.2, 1), transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), translate 0.2s cubic-bezier(0.4, 0, 0.2, 1), scale 0.2s cubic-bezier(0.4, 0, 0.2, 1), rotate 0.2s cubic-bezier(0.4, 0, 0.2, 1), filter 0.2s cubic-bezier(0.4, 0, 0.2, 1), -webkit-backdrop-filter 0.2s cubic-bezier(0.4, 0, 0.2, 1), backdrop-filter 0.2s cubic-bezier(0.4, 0, 0.2, 1), display 0.2s cubic-bezier(0.4, 0, 0.2, 1), content-visibility 0.2s cubic-bezier(0.4, 0, 0.2, 1), overlay 0.2s cubic-bezier(0.4, 0, 0.2, 1), pointer-events 0.2s cubic-bezier(0.4, 0, 0.2, 1)` |
| ::before | `{"content":"\"\"","backgroundColor":"rgba(0, 0, 0, 0)","width":"1440px","height":"178px","position":"absolute","transform":"none","transitionProperty":"all","transitionDuration":"0s","transitionTimingFunction":"ease","borderRadius":"0px","opacity":"0","backgroundImage":"none"}` |
| ::after | `{"content":"\"\"","backgroundColor":"rgb(0 0 0 / 0.6)","width":"1440px","height":"58px","position":"absolute","transform":"none","transitionProperty":"opacity","transitionDuration":"0.15s","transitionTimingFunction":"cubic-bezier(0.4, 0, 0.2, 1)","borderRadius":"0px","opacity":"1","backgroundImage` |
Size: 58px tall, from 1440px wide, padding 0px × 0px.

## footer (footer, ×3)
![footer](../assets/reference/footer.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#f0f0f0` |
| font | `400 16px/24px` |
| family | `inter` |
| padding | `144px 24px 144px 24px` |
| gap | `32px` |
Size: 596px tall, from 1280px wide, padding 144px × 24px.

## footer-2 (footer, ×1)
![footer-2](../assets/reference/footer-2.jpg)

| property | value |
|---|---|
| background | `linear-gradient(to top in oklab, rgb(0, 0, 0) 0%, rgb(0, 0, 0) 50%, rgba(0, 0, 0, 0) 100%)` |
| color | `#f0f0f0` |
| font | `400 16px/24px` |
| family | `inter` |
| padding | `20px 16px 12px 16px` |
| gap | `16px` |
Size: 52px tall, from 1004px wide, padding 20px × 16px.

## input (input, ×1)
![input](../assets/reference/input.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#f0f0f0` |
| font | `400 16px/24px` |
| family | `inter` |
| padding | `0px 0px 0px 0px` |
| cursor | `text` |
Size: 1px tall, from 1px wide, padding 0px × 0px.

## input-2 (input, ×1)
![input-2](../assets/reference/input-2.jpg)

| property | value |
|---|---|
| background | `transparent` |
| color | `#f0f0f0` |
| font | `400 14px/20px` |
| family | `inter` |
| padding | `0px 0px 0px 0px` |
| cursor | `text` |
Size: 1px tall, from 1px wide, padding 0px × 0px.
