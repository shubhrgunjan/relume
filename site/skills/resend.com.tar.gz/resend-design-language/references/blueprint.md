# Blueprint

Every section of the measured pages, top to bottom. Build the same kinds of sections in the same order for your product. "Made of" is what fills the section; recreate each block in kind (your content, the source's grammar). Crops are in `assets/reference/sections/`.

## UI grammar (product mock-ups)
Measured inside 5 product UI panels. Build mock-ups as real HTML with these numbers, never as a picture or an empty box.

| what | measured |
|---|---|
| panel surface | background rgba(0, 0, 0, 0), radius 24px, border 1px rgba(214, 235, 253, 0.19) |
| label sizes (px, count) | 12 (294), 14 (155), 24 (2), 20 (1) |
| list row heights (px, count) | 28 (4), 32 (4), 26 (3), 34 (2), 52 (1), 45 (1) |
| icon sizes (px, count) | 14 (14), 16 (10), 24 (8), 18 (2) |
| avatar | — |
| chips | 28px tall, radius 10px, 500 12px; e.g. delivered · charlotte@gmail.com · Hello world · Gmail · macOS · opened |
| sidebar width | 200px |
| text colours (count) | #a0a0a0 (171), #ebeced (58), #464a4d (57), #ababab (46), #6c6c6c (44) |
| status colours | #ffc446, #46fea5, #70b8ff, #ffca16, #ff6465, #ffd60a, #43fea4, #3b9eff |

## home — 12320px, 13 sections, visuals 32%, 78 elements/screen

### 01 · hero + visual
![hero + visual](../assets/reference/sections/home-00.jpg)
- layout: **hero**; 900px tall; visuals cover 100%; 6 painted elements
- heading: “Email for developers” — 96px / 400, at x 168, 480px wide
- made of: **3d-scene** (live webgl2 canvas 648×550, at 688/193/648/550); **image** (1440×900, at 0/58/1440/900, opacity 0.8); **image** (1440×900, at 0/-22/1440/900)
- see each block: [image](../assets/reference/sections/home-00-image-0.jpg) · [image](../assets/reference/sections/home-00-image-1.jpg)
- image quality: 1920×1080 jpg, 1.33× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image quality: 1920×1080 avif, 1.33× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image pixels use: #040404 83%, #151515 11%
- image pixels use: #040404 80%, #151515 13%, #262627 3%
- this section's pixels: #040404 83%, #151515 11% (use these for painted or image art instead of inventing colours)

**Behaviour** — what this section does while you watch it ([filmstrip](../assets/reference/sections/home-behaviour-00.jpg), six moments of a still view):
- canvas 648×550 is a live 3D scene (webgl2, three.js r149). Rebuild it as real 3D (three.js), not a still image.
- Part of the view drifts right at ~22px/s on its own (painted motion: canvas, background or image).
- img.pointer-events-none.absolute (image) 1440×900 fades out through a gradient mask (linear-gradient(to top, rgba(0, 0, 0, 0) 15%, rgb(0, 0, 0) 25%)).

### 02 · logo strip
![logo strip](../assets/reference/sections/home-01.jpg)
- layout: **stacked**; 567px tall; visuals cover 14%; 15 painted elements
- made of: **logos** (6 marks in a row, at 207/1259/1010/37); **logos** (6 marks in a row, at 207/1355/997/36)
- this section's pixels: #010101 93% (use these for painted or image art instead of inventing colours)

### 03 · product UI showcase
![product UI showcase](../assets/reference/sections/home-02.jpg)
- layout: **centered**; 1296px tall; visuals cover 41%; 176 painted elements
- heading: “Integrate” — 56px / 400, at x 104, 1232px wide
- made of: **ui-mock** (110 UI labels, 12 icons, ~20 rows, at 208/2207/1024/598); **video** (video 170×170, at 635/1701/170/170)
- see each block: [ui-mock](../assets/reference/sections/home-02-ui-mock-0.jpg) · [video](../assets/reference/sections/home-02-video-1.jpg)
- video quality: 370×370 mp4, 2.18× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- video pixels use: #040303 40%, #292727 16%, #150d09 14%, #191615 12%, #18110d 5%, #25221e 3%, #231c1a 2%
- this section's pixels: #010101 93%, #171616 3% (use these for painted or image art instead of inventing colours)

### 04 · product UI showcase
![product UI showcase](../assets/reference/sections/home-03.jpg)
- layout: **stacked**; 967px tall; visuals cover 27%; 101 painted elements
- heading: “First-class developer experience” — 56px / 400, at x 104, 1232px wide
- made of: **ui-mock** (57 UI labels, 21 icons, ~23 rows, at 736/3245/600/526); **form** (inputs, at 80/2901/1280/967)
- see each block: [ui-mock](../assets/reference/sections/home-03-ui-mock-0.jpg)
- this section's pixels: #010101 90%, #171717 4%, #272727 2% (use these for painted or image art instead of inventing colours)

### 05 · product UI showcase
![product UI showcase](../assets/reference/sections/home-04.jpg)
- layout: **centered**; 1358px tall; visuals cover 41%; 22 painted elements
- heading: “Write using a delightful editor” — 56px / 400, at x 104, 1232px wide
- made of: **video** (video 170×170, at 635/3963/170/170); **image** (662×214, at 389/4599/662/214); **ui-mock** (7 UI labels (panel), at 388/4447/664/152); **ui-mock** (12 UI labels (panel), at 166/4342/1109/600)
- see each block: [video](../assets/reference/sections/home-04-video-0.jpg) · [image](../assets/reference/sections/home-04-image-1.jpg) · [ui-mock](../assets/reference/sections/home-04-ui-mock-2.jpg) · [ui-mock](../assets/reference/sections/home-04-ui-mock-3.jpg)
- video quality: 370×370 mp4, 2.18× its on-screen width; photographic or 3D render (many smooth tones); looping. Match this fidelity and pixel density with your own asset (a real 3D render or photograph, not a vector drawing).
- image quality: 1200×388 webp, 1.81× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- video pixels use: #070607 58%, #161616 14%, #0b0714 4%, #262527 2%
- image pixels use: #050505 27%, #161616 23%, #373737 20%, #282828 16%, #464646 9%, #535353 2%
- this section's pixels: #020202 75%, #ffffff 10%, #151516 6%, #272727 3%, #363636 2% (use these for painted or image art instead of inventing colours)

**Behaviour** — what this section does while you watch it ([filmstrip](../assets/reference/sections/home-behaviour-04.jpg), six moments of a still view):
- video.mx-auto.mb-4 (3d-broadcast.mp4) 170×170 is autoplaying video on a loop.
- div.relative.mt-16 1109×600 fades out through a gradient mask (linear-gradient(rgb(0, 0, 0) 40%, rgba(0, 0, 0, 0) 100%)).

### 06 · card row
![card row](../assets/reference/sections/home-05.jpg)
- layout: **stacked**, 2 columns; 899px tall; visuals cover 11%; 12 painted elements
- heading: “Go beyond editing” — 56px / 400, at x 104, 1232px wide
- made of: **image** (534×228, ×2 (carousel/loop), at 153/5568/534/228); **cards** (2 × 600×526, at 104/5503/1232/526)
- see each block: [image](../assets/reference/sections/home-05-image-0.jpg)
- image quality: 1444×616 avif, 2.7× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image pixels use: #050505 83%, #141414 5%, #272727 2%
- this section's pixels: #010101 90%, #161616 2% (use these for painted or image art instead of inventing colours)

**Behaviour** — what this section does while you watch it ([filmstrip](../assets/reference/sections/home-behaviour-05.jpg), six moments of a still view):
- img.block.w-full (image) 534×228 fades out through a gradient mask (linear-gradient(45deg, rgb(0, 0, 0) 50%, rgba(0, 0, 0, 0) 100%)).
- img.w-full.rounded-2xl (image) 534×228 fades out through a gradient mask (linear-gradient(45deg, rgb(0, 0, 0) 50%, rgba(0, 0, 0, 0) 100%)).

### 07 · product UI showcase
![product UI showcase](../assets/reference/sections/home-06.jpg)
- layout: **centered**; 1367px tall; visuals cover 53%; 354 painted elements
- heading: “Develop emails using React” — 56px / 400, at x 104, 1232px wide
- made of: **ui-mock** (414 UI labels, 9 icons, ~71 rows, at 104/6696/1232/700); **video** (video 170×170, at 635/6221/170/170); **form** (inputs, at 80/6125/1280/1367)
- see each block: [ui-mock](../assets/reference/sections/home-06-ui-mock-0.jpg) · [video](../assets/reference/sections/home-06-video-1.jpg)
- video quality: 370×370 mp4, 2.18× its on-screen width; flat illustration (limited palette, soft shading); looping. Match this fidelity and pixel density with your own asset.
- video pixels use: #060606 56%, #161717 16%, #0b1316 4%, #232424 4%, #182328 3%, #0a0d12 2%
- this section's pixels: #010101 87%, #171717 6%, #262626 3% (use these for painted or image art instead of inventing colours)

**Behaviour** — what this section does while you watch it ([filmstrip](../assets/reference/sections/home-behaviour-06.jpg), six moments of a still view):
- video.mx-auto.mb-4 (3d-react.mp4) 170×170 is autoplaying video on a loop.

### 08 · content
![content](../assets/reference/sections/home-07.jpg)
- layout: **stacked**; 941px tall; visuals cover 0%; 36 painted elements
- heading: “Reach humans, not spam folders” — 56px / 400, at x 104, 448px wide
- made of: text only (1383 characters)
- this section's pixels: #010101 85%, #171717 5%, #272727 5%, #363636 2% (use these for painted or image art instead of inventing colours)

### 09 · content
![content](../assets/reference/sections/home-08.jpg)
- layout: **centered**; 631px tall; visuals cover 0%; 3 painted elements
- heading: “Resend is transforming email for developers. Simple interface, easy integrations” — 24px / 500, at x 473, 495px wide
- made of: **avatar** (40px, at 625/8838/40/40)
- this section's pixels: #000000 96% (use these for painted or image art instead of inventing colours)

### 10 · content
![content](../assets/reference/sections/home-09.jpg)
- layout: **centered**; 1352px tall; visuals cover 51%; 19 painted elements
- heading: “Everything in your control” — 56px / 400, at x 104, 1232px wide
- made of: **video** (video 170×170, at 635/9160/170/170); **image** (1232×659, at 104/9661/1232/659)
- see each block: [video](../assets/reference/sections/home-09-video-0.jpg) · [image](../assets/reference/sections/home-09-image-1.jpg)
- video quality: 370×370 mp4, 2.18× its on-screen width; flat illustration (limited palette, soft shading); looping. Match this fidelity and pixel density with your own asset.
- image quality: 2560×1367 webp, 2.08× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- video pixels use: #060606 67%, #151515 16%, #022716 3%, #05150d 2%
- image pixels use: #050606 93%, #161616 3%
- this section's pixels: #030303 92%, #161616 3% (use these for painted or image art instead of inventing colours)

**Behaviour** — what this section does while you watch it ([filmstrip](../assets/reference/sections/home-behaviour-09.jpg), six moments of a still view):
- video.mx-auto.mb-4 (3d-control.mp4) 170×170 is autoplaying video on a loop.

### 11 · logo strip
![logo strip](../assets/reference/sections/home-10.jpg)
- layout: **centered**, 10 columns; 685px tall; visuals cover 13%; 272 painted elements
- heading: “Beyond expectations” — 56px / 400, at x 0, 1440px wide
- made of: **avatar** (40px, at -451/10888/40/40); **avatar** (40px, at -417/10888/40/40); **avatar** (40px, at 31/10888/40/40); **avatar** (40px, at 65/10888/40/40); **avatar** (40px, at 513/10937/40/40); **avatar** (40px, at 547/10937/40/40); **avatar** (40px, at 995/10888/40/40); **avatar** (40px, at 1029/10888/40/40); **avatar** (40px, at 1477/10888/40/40); **avatar** (40px, at 1511/10888/40/40); **avatar** (40px, at 1959/10875/40/40); **avatar** (40px, at 1993/10875/40/40); **avatar** (40px, at 2441/10864/40/40); **avatar** (40px, at 2475/10864/40/40); **avatar** (40px, at 2923/10840/40/40); **avatar** (40px, at 2957/10840/40/40); **avatar** (40px, at 3405/10864/40/40); **avatar** (40px, at 3439/10864/40/40); **avatar** (40px, at 3887/10840/40/40); **avatar** (40px, at 3921/10840/40/40); **avatar** (40px, at 4369/10888/40/40); **avatar** (40px, at 4403/10888/40/40); **avatar** (40px, at 4851/10888/40/40); **avatar** (40px, at 4885/10888/40/40); **avatar** (40px, at 5333/10937/40/40); **avatar** (40px, at 5367/10937/40/40); **avatar** (40px, at 5815/10888/40/40); **avatar** (40px, at 5849/10888/40/40); **avatar** (40px, at 6297/10888/40/40); **avatar** (40px, at 6331/10888/40/40); **avatar** (40px, at 6779/10875/40/40); **avatar** (40px, at 6813/10875/40/40); **avatar** (40px, at 7261/10864/40/40); **avatar** (40px, at 7295/10864/40/40); **avatar** (40px, at 7743/10840/40/40); **avatar** (40px, at 7777/10840/40/40); **avatar** (40px, at 8225/10864/40/40); **avatar** (40px, at 8259/10864/40/40); **avatar** (40px, at 8707/10840/40/40); **avatar** (40px, at 8741/10840/40/40); **avatar** (40px, at 9189/10888/40/40); **avatar** (40px, at 9223/10888/40/40); **avatar** (40px, at 9671/10888/40/40); **avatar** (40px, at 9705/10888/40/40); **avatar** (40px, at 10153/10937/40/40); **avatar** (40px, at 10187/10937/40/40); **avatar** (40px, at 10635/10888/40/40); **avatar** (40px, at 10669/10888/40/40); **avatar** (40px, at 11117/10888/40/40); **avatar** (40px, at 11151/10888/40/40); **avatar** (40px, at 11599/10875/40/40); **avatar** (40px, at 11633/10875/40/40); **avatar** (40px, at 12081/10864/40/40); **avatar** (40px, at 12115/10864/40/40); **avatar** (40px, at 12563/10840/40/40); **avatar** (40px, at 12597/10840/40/40); **avatar** (40px, at 13045/10864/40/40); **avatar** (40px, at 13079/10864/40/40); **avatar** (40px, at 13527/10840/40/40); **avatar** (40px, at 13561/10840/40/40); **logos** (24 marks in a row, at -451/10888/11642/40); **logos** (6 marks in a row, at 513/10937/9714/40); **logos** (18 marks in a row, at 1959/10864/11160/51); **logos** (12 marks in a row, at 2923/10840/10678/40); **testimonial** (10 × 450×219, quotes, at -484/10737/4788/268); **testimonial** (10 × 450×219, quotes, at 4336/10737/4788/268); **testimonial** (10 × 450×219, quotes, at 9156/10737/4788/268)
- see each block: [testimonial](../assets/reference/sections/home-10-testimonial-0.jpg)
- this section's pixels: #010101 87%, #282828 4%, #363636 3%, #161616 3% (use these for painted or image art instead of inventing colours)

**Behaviour** — what this section does while you watch it ([filmstrip](../assets/reference/sections/home-behaviour-10.jpg), six moments of a still view):
- ul.flex.shrink-0 4788×268 moves between 49 positions (up to 4817px).

### 12 · call to action
![call to action](../assets/reference/sections/home-11.jpg)
- layout: **centered**; 702px tall; visuals cover 0%; 5 painted elements
- heading: “Email reimagined. Available today.” — 76.8px / 400, at x 104, 1232px wide
- made of: text only (44 characters)
- this section's pixels: #010101 93% (use these for painted or image art instead of inventing colours)

### 13 · footer
![footer](../assets/reference/sections/home-12.jpg)
- layout: **stacked**; 597px tall; visuals cover 0%; 41 painted elements; background rgb(0, 0, 0)
- made of: **avatar** (32px, at 104/11932/32/32); **avatar** (32px, at 152/11932/32/32); **avatar** (32px, at 200/11932/32/32); **avatar** (32px, at 248/11932/32/32)
- this section's pixels: #010101 94%, #151515 3% (use these for painted or image art instead of inventing colours)

## pricing — 8678px, 15 sections, visuals 4%, 74 elements/screen

### 01 · hero
![hero](../assets/reference/sections/pricing-00.jpg)
- layout: **hero**; 196px tall; visuals cover 0%; 2 painted elements
- heading: “Pricing” — 76.8px / 400, at x 104, 1232px wide
- made of: text only (44 characters)
- this section's pixels: #000000 95% (use these for painted or image art instead of inventing colours)

### 02 · card row
![card row](../assets/reference/sections/pricing-01.jpg)
- layout: **columns**, 3 columns; 825px tall; visuals cover 0%; 73 painted elements
- made of: **cards** (3 × 403×661, at 104/466/1232/661); **form** (inputs, at 104/302/1232/825)
- this section's pixels: #010101 89%, #151615 5%, #282828 2% (use these for painted or image art instead of inventing colours)

### 03 · content
![content](../assets/reference/sections/pricing-02.jpg)
- layout: **stacked**; 40px tall; visuals cover 0%; 2 painted elements
- made of: text only (32 characters)
- this section's pixels: #000000 95% (use these for painted or image art instead of inventing colours)

### 04 · content
![content](../assets/reference/sections/pricing-03.jpg)
- layout: **stacked**; 692px tall; visuals cover 0%; 11 painted elements
- heading: “Add-ons” — 36px / 400, at x 208, 1024px wide
- made of: text only (868 characters)
- this section's pixels: #010101 90%, #171717 4%, #272827 3%, #373737 2% (use these for painted or image art instead of inventing colours)

### 05 · call to action
![call to action](../assets/reference/sections/pricing-04.jpg)
- layout: **stacked**; 551px tall; visuals cover 0%; 57 painted elements
- heading: “Sending & receiving” — 36px / 400, at x 208, 1024px wide
- made of: text only (192 characters)
- this section's pixels: #010101 90%, #131416 5% (use these for painted or image art instead of inventing colours)

### 06 · call to action
![call to action](../assets/reference/sections/pricing-05.jpg)
- layout: **stacked**; 331px tall; visuals cover 0%; 32 painted elements
- heading: “Inboxes” — 36px / 400, at x 208, 1024px wide
- made of: text only (201 characters)
- this section's pixels: #010101 87%, #131417 9% (use these for painted or image art instead of inventing colours)

### 07 · content
![content](../assets/reference/sections/pricing-06.jpg)
- layout: **stacked**; 683px tall; visuals cover 0%; 72 painted elements
- heading: “Deliverability & reliability” — 36px / 400, at x 208, 1024px wide
- made of: text only (468 characters)
- this section's pixels: #010101 88%, #131415 5% (use these for painted or image art instead of inventing colours)

### 08 · call to action
![call to action](../assets/reference/sections/pricing-07.jpg)
- layout: **stacked**; 551px tall; visuals cover 0%; 57 painted elements
- heading: “Security & privacy” — 36px / 400, at x 208, 1024px wide
- made of: text only (250 characters)
- this section's pixels: #010101 89%, #131416 5% (use these for painted or image art instead of inventing colours)

### 09 · call to action
![call to action](../assets/reference/sections/pricing-08.jpg)
- layout: **stacked**; 375px tall; visuals cover 0%; 37 painted elements
- heading: “Customer support” — 36px / 400, at x 208, 1024px wide
- made of: text only (145 characters)
- this section's pixels: #010101 88%, #131416 7% (use these for painted or image art instead of inventing colours)

### 10 · call to action
![call to action](../assets/reference/sections/pricing-09.jpg)
- layout: **stacked**; 155px tall; visuals cover 0%; 12 painted elements
- heading: “AI credits” — 36px / 400, at x 208, 1024px wide
- made of: text only (62 characters)
- this section's pixels: #010101 80%, #131315 14%, #232324 2% (use these for painted or image art instead of inventing colours)

### 11 · logo strip
![logo strip](../assets/reference/sections/pricing-10.jpg)
- layout: **stacked**; 230px tall; visuals cover 49%; 1 painted elements
- made of: **logos** (5 marks in a row, at 220/5422/1000/32); **logos** (5 marks in a row, at 220/5514/1000/40)
- this section's pixels: #000000 91% (use these for painted or image art instead of inventing colours)

### 12 · content
![content](../assets/reference/sections/pricing-11.jpg)
- layout: **stacked**; 1213px tall; visuals cover 0%; 47 painted elements
- heading: “Frequently asked questions” — 36px / 400, at x 208, 1024px wide
- made of: text only (754 characters)
- this section's pixels: #020203 49%, #141517 37%, #0e0f11 3%, #363739 2%, #0f1012 2% (use these for painted or image art instead of inventing colours)

**Behaviour** — what this section does while you watch it:
- A layer (viewport rows 90–180px) moves at 0.1× the scroll speed: parallax depth (2 distinct speeds).

### 13 · logo strip
![logo strip](../assets/reference/sections/pricing-12.jpg)
- layout: **columns**, 10 columns; 268px tall; visuals cover 52%; 270 painted elements
- made of: **avatar** (40px, at -3091/7297/40/40); **avatar** (40px, at -3057/7297/40/40); **avatar** (40px, at -2609/7297/40/40); **avatar** (40px, at -2575/7297/40/40); **avatar** (40px, at -2127/7346/40/40); **avatar** (40px, at -2093/7346/40/40); **avatar** (40px, at -1645/7297/40/40); **avatar** (40px, at -1611/7297/40/40); **avatar** (40px, at -1163/7297/40/40); **avatar** (40px, at -1129/7297/40/40); **avatar** (40px, at -681/7284/40/40); **avatar** (40px, at -647/7284/40/40); **avatar** (40px, at -199/7273/40/40); **avatar** (40px, at -165/7273/40/40); **avatar** (40px, at 283/7249/40/40); **avatar** (40px, at 317/7249/40/40); **avatar** (40px, at 765/7273/40/40); **avatar** (40px, at 799/7273/40/40); **avatar** (40px, at 1247/7249/40/40); **avatar** (40px, at 1281/7249/40/40); **avatar** (40px, at 1729/7297/40/40); **avatar** (40px, at 1763/7297/40/40); **avatar** (40px, at 2211/7297/40/40); **avatar** (40px, at 2245/7297/40/40); **avatar** (40px, at 2693/7346/40/40); **avatar** (40px, at 2727/7346/40/40); **avatar** (40px, at 3175/7297/40/40); **avatar** (40px, at 3209/7297/40/40); **avatar** (40px, at 3657/7297/40/40); **avatar** (40px, at 3691/7297/40/40); **avatar** (40px, at 4139/7284/40/40); **avatar** (40px, at 4173/7284/40/40); **avatar** (40px, at 4621/7273/40/40); **avatar** (40px, at 4655/7273/40/40); **avatar** (40px, at 5103/7249/40/40); **avatar** (40px, at 5137/7249/40/40); **avatar** (40px, at 5585/7273/40/40); **avatar** (40px, at 5619/7273/40/40); **avatar** (40px, at 6067/7249/40/40); **avatar** (40px, at 6101/7249/40/40); **avatar** (40px, at 6549/7297/40/40); **avatar** (40px, at 6583/7297/40/40); **avatar** (40px, at 7031/7297/40/40); **avatar** (40px, at 7065/7297/40/40); **avatar** (40px, at 7513/7346/40/40); **avatar** (40px, at 7547/7346/40/40); **avatar** (40px, at 7995/7297/40/40); **avatar** (40px, at 8029/7297/40/40); **avatar** (40px, at 8477/7297/40/40); **avatar** (40px, at 8511/7297/40/40); **avatar** (40px, at 8959/7284/40/40); **avatar** (40px, at 8993/7284/40/40); **avatar** (40px, at 9441/7273/40/40); **avatar** (40px, at 9475/7273/40/40); **avatar** (40px, at 9923/7249/40/40); **avatar** (40px, at 9957/7249/40/40); **avatar** (40px, at 10405/7273/40/40); **avatar** (40px, at 10439/7273/40/40); **avatar** (40px, at 10887/7249/40/40); **avatar** (40px, at 10921/7249/40/40); **logos** (24 marks in a row, at -3091/7297/11642/40); **logos** (6 marks in a row, at -2127/7346/9714/40); **logos** (18 marks in a row, at -681/7273/11160/51); **logos** (12 marks in a row, at 283/7249/10678/40); **testimonial** (10 × 450×219, quotes, at -3124/7146/4788/268); **testimonial** (10 × 450×219, quotes, at 1696/7146/4788/268); **testimonial** (10 × 450×219, quotes, at 6516/7146/4788/268)
- see each block: [testimonial](../assets/reference/sections/pricing-12-testimonial-0.jpg)
- this section's pixels: #020202 88%, #282828 3%, #171717 3%, #383837 3% (use these for painted or image art instead of inventing colours)

**Behaviour** — what this section does while you watch it:
- ul.flex.shrink-0 4788×268 drifts left at ~26px/s, looping (3 copies).

### 14 · call to action
![call to action](../assets/reference/sections/pricing-13.jpg)
- layout: **centered**; 577px tall; visuals cover 0%; 4 painted elements
- heading: “Start sending this afternoon” — 56px / 400, at x 399, 642px wide
- made of: text only (120 characters)
- this section's pixels: #000000 95% (use these for painted or image art instead of inventing colours)

### 15 · footer
![footer](../assets/reference/sections/pricing-14.jpg)
- layout: **stacked**; 596px tall; visuals cover 0%; 41 painted elements
- made of: **avatar** (32px, at 104/8290/32/32); **avatar** (32px, at 152/8290/32/32); **avatar** (32px, at 200/8290/32/32); **avatar** (32px, at 248/8290/32/32)
- this section's pixels: #000000 95% (use these for painted or image art instead of inventing colours)

## status — 1149px, 1 sections, visuals 31%, 67 elements/screen

### 01 · hero + product UI
![hero + product UI](../assets/reference/sections/status-00.jpg)
- layout: **hero**; 1149px tall; visuals cover 31%; 86 painted elements
- made of: **ui-mock** (30 UI labels, 29 icons, ~12 rows, at 386/227/668/745); **ui-mock** (30 UI labels, 29 icons, ~12 rows, at 385/226/670/747)
- see each block: [ui-mock](../assets/reference/sections/status-00-ui-mock-0.jpg) · [ui-mock](../assets/reference/sections/status-00-ui-mock-1.jpg)
- this section's pixels: #161618 78%, #172927 3%, #160e13 3% (use these for painted or image art instead of inventing colours)

## features-automations — 9051px, 10 sections, visuals 39%, 35 elements/screen

### 01 · hero
![hero](../assets/reference/sections/features-automations-00.jpg)
- layout: **hero**; 800px tall; visuals cover 2%; 9 painted elements
- heading: “Automations for modern emails” — 76.8px / 400, at x 454, 533px wide
- made of: **video** (video 150×150, at 645/192/150/150)
- see each block: [video](../assets/reference/sections/features-automations-00-video-0.jpg)
- video quality: 370×370 mp4, 2.47× its on-screen width; flat illustration (limited palette, soft shading); looping. Match this fidelity and pixel density with your own asset.
- video pixels use: #0b0a0b 40%, #181718 20%, #252425 10%, #0d0d11 9%, #170c09 6%, #251918 2%
- this section's pixels: #020202 92% (use these for painted or image art instead of inventing colours)

### 02 · product UI showcase
![product UI showcase](../assets/reference/sections/features-automations-01.jpg)
- layout: **stacked**; 992px tall; visuals cover 100%; 42 painted elements
- made of: **image** (143×129, ×2 (carousel/loop), at 505/1590/143/129); **ui-mock** (9 UI labels (panel), at 176/1032/1144/870); **ui-mock** (11 UI labels (panel), at 104/938/1232/992)
- see each block: [image](../assets/reference/sections/features-automations-01-image-0.jpg) · [ui-mock](../assets/reference/sections/features-automations-01-ui-mock-1.jpg) · [ui-mock](../assets/reference/sections/features-automations-01-ui-mock-2.jpg)
- image quality: 128×117 webp, 0.9× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image pixels use: #150a0b 25%, #0c0505 19%, #1d0e11 12%, #292627 8%, #251a19 7%, #1b1314 4%, #220d12 4%, #363639 3%
- this section's pixels: #040404 83%, #131313 10% (use these for painted or image art instead of inventing colours)

### 03 · product UI showcase
![product UI showcase](../assets/reference/sections/features-automations-02.jpg)
- layout: **stacked**; 752px tall; visuals cover 27%; 69 painted elements
- heading: “Trigger actions via custom events” — 56px / 400, at x 816, 520px wide
- made of: **code** (51 mono lines, at 105/2203/614/252); **ui-mock** (52 UI labels (panel), at 104/2146/616/384); **form** (inputs, at 104/2010/1232/752)
- see each block: [code](../assets/reference/sections/features-automations-02-code-0.jpg) · [ui-mock](../assets/reference/sections/features-automations-02-ui-mock-1.jpg)
- this section's pixels: #000000 93%, #171717 2% (use these for painted or image art instead of inventing colours)

### 04 · card row
![card row](../assets/reference/sections/features-automations-03.jpg)
- layout: **columns**, 3 columns; 724px tall; visuals cover 0%; 25 painted elements
- heading: “Orchestrate every step of your workflow” — 56px / 400, at x 104, 1232px wide
- made of: **cards** (3 × 389×302, at 104/3168/1232/302)
- this section's pixels: #030303 85%, #141414 7%, #282828 3%, #373737 2% (use these for painted or image art instead of inventing colours)

### 05 · product UI showcase
![product UI showcase](../assets/reference/sections/features-automations-04.jpg)
- layout: **centered**; 1502px tall; visuals cover 70%; 97 painted elements
- heading: “Granular visibility of all runs and steps” — 56px / 400, at x 492, 455px wide
- made of: **ui-mock** (21 UI labels, 5 icons, ~15 rows, at 758/4042/562/724); **ui-mock** (68 UI labels, 9 icons, ~41 rows, at 104/3948/1232/1024)
- see each block: [ui-mock](../assets/reference/sections/features-automations-04-ui-mock-0.jpg) · [ui-mock](../assets/reference/sections/features-automations-04-ui-mock-1.jpg)
- this section's pixels: #030303 84%, #141415 11% (use these for painted or image art instead of inventing colours)

### 06 · content
![content](../assets/reference/sections/features-automations-05.jpg)
- layout: **centered**; 581px tall; visuals cover 0%; 3 painted elements
- heading: “Resend Automations turned our hand-built, tangled setup into a clean, reliable w” — 24px / 500, at x 498, 444px wide
- made of: **avatar** (40px, at 700/5274/40/40); **avatar** (40px, at 602/5589/40/40)
- this section's pixels: #000000 95% (use these for painted or image art instead of inventing colours)

### 07 · product UI showcase
![product UI showcase](../assets/reference/sections/features-automations-06.jpg)
- layout: **centered**, 3 columns; 1499px tall; visuals cover 68%; 48 painted elements
- heading: “Start automating your emails” — 56px / 400, at x 520, 399px wide
- made of: **image** (143×129, at 677/6826/143/129); **cards** (3 × 389×149, at 104/6095/1232/149); **ui-mock** (7 UI labels (panel), at 104/6276/1232/992)
- see each block: [image](../assets/reference/sections/features-automations-06-image-0.jpg) · [ui-mock](../assets/reference/sections/features-automations-06-ui-mock-1.jpg)
- image quality: 128×117 webp, 0.9× its on-screen width; flat illustration (limited palette, soft shading). Match this fidelity and pixel density with your own asset.
- image pixels use: #0a0a0a 34%, #161616 9%, #585858 8%, #676767 8%, #787878 8%, #262626 7%, #484848 6%, #868686 6%
- this section's pixels: #030303 86%, #131313 9% (use these for painted or image art instead of inventing colours)

### 08 · call to action
![call to action](../assets/reference/sections/features-automations-07.jpg)
- layout: **stacked**; 383px tall; visuals cover 0%; 11 painted elements
- heading: “Start now $0 / mo” — 56px / 400, at x 305, 383px wide
- made of: text only (114 characters)
- this section's pixels: #000000 94% (use these for painted or image art instead of inventing colours)

### 09 · call to action
![call to action](../assets/reference/sections/features-automations-08.jpg)
- layout: **centered**; 577px tall; visuals cover 0%; 4 painted elements
- heading: “Start sending this afternoon” — 56px / 400, at x 399, 642px wide
- made of: text only (120 characters)
- this section's pixels: #000000 95% (use these for painted or image art instead of inventing colours)

### 10 · footer
![footer](../assets/reference/sections/features-automations-09.jpg)
- layout: **stacked**; 596px tall; visuals cover 0%; 40 painted elements
- made of: **avatar** (32px, at 104/8663/32/32); **avatar** (32px, at 152/8663/32/32); **avatar** (32px, at 200/8663/32/32); **avatar** (32px, at 248/8663/32/32)
- this section's pixels: #000000 95% (use these for painted or image art instead of inventing colours)
