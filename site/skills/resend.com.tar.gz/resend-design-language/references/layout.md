# Layout

## Containers
| viewport | content widths (most used first) | gutter |
|---|---|---|
| desktop | 1280px, 400px, 1024px, 664px | 24px |
| tablet | 786px, 400px, 423px, 520px | 24px |
| mobile | 342px, 320px, 340px, 200px | 24px |

## Breakpoints (from the stylesheets)
- min-width 768px (×10)
- min-width 640px (×8)
- min-width 1024px (×7)
- min-width 1280px (×7)
- min-width 1536px (×5)
- min-width 1920px (×4)
- min-width 1340px (×2)
- min-width 1160px (×2)

## Grids
- 10 equal flex columns, gap 32px (×6)
- 3 cols, gap 32px (×3)
- 5 cols, gap 32px (×3)
- 2 cols, gap 16px (×3)
- 6 cols, gap 16px (×2)
- 2 cols, gap 32px (×2)
- 3 equal flex columns, gap 32px (×2)
- 3 cols, gap 80px (×1)

## Section rhythm
| viewport | section padding-y (common) | median | gap between sections |
|---|---|---|---|
| desktop | 96px, 128px, 112px | 96px | 0px |
| tablet | 96px, 144px, 128px, 64px, 112px | 96px | 1px |
| mobile | 48px, 144px, 80px, 128px, 60px | 48px | 49px |

## Density
- First screen: 40 words, text covers 14.6% of it.
- Home page is 13.7 screens tall at desktop.
